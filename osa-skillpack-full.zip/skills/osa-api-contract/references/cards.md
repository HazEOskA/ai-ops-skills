# Karty: osa-api-contract

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### B01 · Kontrakt API
**Gdy:** nowe API, zmiana endpointu, kształt błędu, paginacja.
**Twarde:** zasoby zamiast czasowników; jeden format błędu na całe API (RFC 9457 + stabilny `code`); paginacja kursorowa, nigdy offset; kwoty jako liczba całkowita w najmniejszej jednostce; czasy ISO-8601 z offsetem; spec jest źródłem prawdy, kod się do niego stosuje.
**Ekspert wie:** Najczęstsze złamanie kontraktu to nie usunięte pole, tylko zmieniona semantyka istniejącego (inna jednostka, strefa czasowa, znaczenie null). Przechodzi każdy test typów, a po cichu psuje klientów — dlatego zmiana znaczenia to zmiana wersji.
**Sprawdź:** `npx @redocly/cli lint openapi.yaml && npx oasdiff breaking old.yaml new.yaml`
**Nie:** `200 OK` z błędem w body; zwracanie surowego rekordu bazy; enum bez zdefiniowanego zachowania klienta na nieznaną wartość.

### B02 · REST vs GraphQL vs gRPC
**Gdy:** wybór stylu API.
**Twarde:** REST domyślnie — cache HTTP, debugowalność, znany wszystkim; GraphQL gdy klientów jest wielu i mają różne potrzeby danych, kosztem złożoności cache i limitu głębokości zapytań; gRPC między własnymi usługami, gdzie liczy się latencja i kontrakt binarny.
**Ekspert wie:** GraphQL przenosi złożoność z klienta na serwer: N+1 w resolverach (potrzebny DataLoader), kontrola kosztu zapytań i autoryzacja per pole. Bez budżetu na to wielu klientów o różnych potrzebach obsłużysz zwykłym REST z parametrem `fields` albo osobnymi endpointami widoków.
**Sprawdź:** czy klient publiczny ma cache po stronie CDN — GraphQL to zabija bez dodatkowej warstwy.
**Nie:** GraphQL dla jednego frontendu; gRPC wystawione publicznie do przeglądarki bez proxy; mieszanie trzech stylów bez uzasadnienia.

### B03 · Wersjonowanie i breaking change
**Gdy:** zmiana istniejącego kontraktu.
**Twarde:** wersja w ścieżce dla API publicznego; dodanie pola opcjonalnego to nie breaking, zmiana typu, zwężenie enuma, usunięcie pola i zmiana domyślnej wartości — tak; nagłówki `Deprecation` i `Sunset` z datą; dwie wersje żyją równolegle przez zadeklarowany okres.
**Ekspert wie:** Wersja w ścieżce rozwiązuje kompatybilność, ale mnoży koszt utrzymania — realnym kosztem jest okres równoległego życia obu wersji. Ustal go datą (`Sunset`), zanim wydasz v2, inaczej v1 zostaje na zawsze.
**Sprawdź:** `npx oasdiff breaking old.yaml new.yaml` — pusta lista albo świadomy bump.
**Nie:** cicha zmiana semantyki pola przy zachowanej nazwie; usunięcie wersji bez okresu przejściowego.

### B12 · Webhooki wychodzące
**Gdy:** wysyłasz zdarzenia do klientów.
**Twarde:** podpisuj payload (HMAC + timestamp) i udokumentuj weryfikację; retry z backoffem i limitem, potem wyłączenie endpointu z powiadomieniem; wysyłka z kolejki, nigdy synchronicznie w żądaniu; wersjonuj payload; wystaw historię dostarczeń i możliwość ręcznego ponowienia.
**Ekspert wie:** Odbiorca zawsze wróci z pytaniem „czemu nie dostałem zdarzenia X” — historia dostarczeń z kodem odpowiedzi i ręcznym ponowieniem oszczędza więcej czasu wsparcia niż jakikolwiek retry. Podpis musi obejmować timestamp, inaczej atakujący odtworzy stary poprawny payload (replay).
**Sprawdź:** logi dostarczeń z kodem odpowiedzi i liczbą prób per subskrypcja.
**Nie:** brak podpisu; nieskończone retry do martwego endpointu; wysyłka blokująca transakcję.

### B14 · Upload plików
**Gdy:** przyjmowanie plików od użytkownika.
**Twarde:** upload bezpośrednio do storage przez presigned URL, nie przez aplikację; limit rozmiaru wymuszony po stronie storage; typ pliku sprawdzaj po zawartości, nie po rozszerzeniu ani po `Content-Type`; skan antywirusowy przed udostępnieniem; nazwy plików generowane, nigdy z wejścia użytkownika.
**Ekspert wie:** Presigned URL bez ograniczenia `Content-Length` i typu pozwala wgrać dowolny plik pod twoimi uprawnieniami — limit i warunki wpisz w politykę podpisu. SVG i HTML serwowane z tej samej domeny co aplikacja to XSS, więc pliki użytkowników idą z osobnej domeny albo z nagłówkiem `Content-Disposition: attachment`.
**Sprawdź:** próba uploadu pliku wykonywalnego przemianowanego na `.jpg` musi zostać odrzucona.
**Nie:** serwowanie uploadów z tej samej domeny co aplikacja (XSS przez SVG/HTML); ścieżka budowana z nazwy pliku (path traversal).

### B20 · Integracja z zewnętrznym API
**Gdy:** podpinasz cudzy serwis.
**Twarde:** owiń w warstwę antykorupcyjną — ich model nie wchodzi do twojej domeny; timeouty, retry, circuit breaker od pierwszego dnia; sandbox i nagrane odpowiedzi w testach; limity i koszty ich API są twoim ograniczeniem projektowym; zapisuj surową odpowiedź do czasu potwierdzenia przetworzenia.
**Ekspert wie:** Zewnętrzne API zmienia się bez ostrzeżenia i ma własne limity oraz okna awarii. Surową odpowiedź zapisuj przed przetworzeniem (odtworzysz ją po naprawie parsera), a nieznaną wartość enuma obsługuj jawnie zamiast wywalać całą operację.
**Sprawdź:** test kontraktowy odtwarzający nagrane odpowiedzi + alert na zmianę schematu.
**Nie:** ich DTO przekazywane w głąb aplikacji; brak obsługi ich `429`; założenie, że sandbox zachowuje się jak produkcja.
