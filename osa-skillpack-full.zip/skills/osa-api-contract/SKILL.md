---
name: "osa-api-contract"
description: "Projekt API i kontrakty: zasoby, kody błędów, wersjonowanie, paginacja, idempotencja, webhooki, kompatybilność wsteczna, dokumentacja OpenAPI. Użyj przy projektowaniu lub zmianie endpointów i integracji. Triggers: API, REST, GraphQL, endpoint, OpenAPI, webhook, versioning, pagination, kontrakt API."
---

# Kontrakt API

## Procedura

1. **Kontrakt przed kodem**: zasoby, metody, wejście, wyjście, błędy zapisane (OpenAPI lub równoważny opis). Kontrakt jest testowalny (`osa-test-strategy`).
2. **Spójne błędy**: właściwy kod HTTP + stały format ciała (kod maszynowy, komunikat, identyfikator żądania). Bez wycieku szczegółów wewnętrznych.
3. **Kompatybilność wsteczna**: dodawanie pól jest bezpieczne, usuwanie/zmiana znaczenia to zmiana łamiąca. Łamiąca = nowa wersja lub okres deprecjacji z datą.
4. **Idempotencja**: zapisy powtarzalne bezpiecznie (klucz idempotencji), zwłaszcza płatności i webhooki.
5. **Paginacja i limity**: kursor zamiast offsetu dla dużych zbiorów; limity rozmiaru i tempa (rate limiting) z czytelnym błędem.
6. **Webhooki**: podpis weryfikowany, retry po stronie nadawcy, odbiorca idempotentny i szybki (potwierdź, przetwórz asynchronicznie).
7. **Autoryzacja w każdym punkcie** (`osa-authz-multitenancy`), walidacja wejścia po stronie serwera (`osa-security-baseline`).
8. **Dowód**: uruchom serwer i wykonaj żądania: poprawne, błędne, brzegowe (`osa-verify-run`).

## Nie

- Zmiany kontraktu bez sprawdzenia konsumentów.
- Zwracania 200 z błędem w ciele.
- Endpointu „wszystko w jednym” bez paginacji.

## Karty (references/cards.md)

- **B01** · Kontrakt API — gdy: nowe API, zmiana endpointu, kształt błędu, paginacja
- **B02** · REST vs GraphQL vs gRPC — gdy: wybór stylu API
- **B03** · Wersjonowanie i breaking change — gdy: zmiana istniejącego kontraktu
- **B12** · Webhooki wychodzące — gdy: wysyłasz zdarzenia do klientów
- **B14** · Upload plików — gdy: przyjmowanie plików od użytkownika
- **B20** · Integracja z zewnętrznym API — gdy: podpinasz cudzy serwis

Wczytaj tylko karty pasujące do zadania (grep po ID).
