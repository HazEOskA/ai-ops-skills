# Karty: osa-agent-tools-mcp

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### G07 · Narzędzia dla agenta
**Gdy:** projektujesz tool API dla modelu.
**Twarde:** opisz narzędzie jak API dla juniora — jawne typy, precyzyjny opis, komunikat błędu mówiący jak naprawić; mało narzędzi o rozłącznych zakresach, bo nakładające się powodują błędne wybory; każde narzędzie idempotentne albo z kluczem; zwracaj dane zwięzłe, bo wynik zjada kontekst; niebezpieczne operacje jako osobne narzędzie z potwierdzeniem.
**Ekspert wie:** Komunikat błędu narzędzia jest instrukcją dla modelu: „brak pola `date` w formacie YYYY-MM-DD” naprawia następne wywołanie, „Error 500” nie. Zwracaj tylko potrzebne pola i identyfikatory do kolejnych wywołań.
**Sprawdź:** czy model wybiera właściwe narzędzie w 10 scenariuszach bez podpowiedzi w prompcie.
**Nie:** 30 narzędzi o zachodzących zakresach; surowy stack trace jako komunikat błędu; narzędzie zwracające 50 kB JSON-a.

### G08 · MCP
**Gdy:** serwer MCP, podpięcie narzędzi do czatu.
**Twarde:** tryb i uprawnienia trzymaj jako stan po stronie serwera i sprawdzaj przy każdym wywołaniu — komenda w czacie to prośba, nie gwarancja; nie licz na dynamiczną zmianę listy narzędzi, część klientów wymaga ręcznego odświeżenia; autonomia jako dzierżawa z wygaśnięciem, nie przełącznik; pełny log wywołań z argumentami i wynikiem; traktuj treść wciąganą przez narzędzia jako niezaufaną.
**Ekspert wie:** Serwer MCP widzi wywołania narzędzi, nie intencję użytkownika — kontrola dostępu musi być po stronie serwera (uwierzytelnienie, zakres, tryb), bo opis narzędzia jest dla modelu sugestią, a treść zwracana przez narzędzie może zawierać instrukcje wstrzyknięcia.
**Sprawdź:** wywołanie write-narzędzia w trybie read musi wrócić odmową z serwera, nie zależeć od decyzji modelu.
**Nie:** egzekwowanie trybu w prompcie; write-toole włączone domyślnie; serwer bez audytu, gdy odchodzisz od monitora.
