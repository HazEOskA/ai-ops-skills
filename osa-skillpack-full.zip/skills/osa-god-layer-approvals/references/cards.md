# Karty: osa-god-layer-approvals

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### Y05 · Governance AI w organizacji
**Gdy:** firma wdraża agentów i modele, polityka użycia AI, audyt.
**Twarde:** rejestr systemów AI (co, gdzie, jakie dane, kto odpowiada, poziom ryzyka); polityka danych dla narzędzi AI (co wolno wklejać); zatwierdzanie działań nieodwracalnych przez człowieka; logi decyzji agentów z możliwością odtworzenia; ocena dostawców (przetwarzanie danych, retencja, region).
**Ekspert wie:** governance działa, gdy jest wbudowane w narzędzia (bramki, logi, uprawnienia), a nie spisane w dokumencie — dokument bez mechanizmu to teatr.
**Sprawdź:** dla losowej decyzji agenta z ostatniego tygodnia: czy da się ustalić wejście, model, wersję promptu i kto zatwierdził.
**Nie:** agenci z uprawnieniami administratora; brak rejestru, gdzie w firmie używany jest AI.
