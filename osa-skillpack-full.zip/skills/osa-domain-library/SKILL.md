---
name: "osa-domain-library"
description: "Biblioteka 13 domen specjalistycznych: mobile, web3, algorytmy, OS, kompilatory, sieci, media, data science, HPC i GPU, metody formalne, ERP, prawo. Użyj do wąskiego pytania z tych domen. Triggers: iOS, Android, Solidity, CUDA, kompilator, BGP, DSP, ERP, EU AI Act, algorytm, kernel, GPU."
---

# Biblioteka domen specjalistycznych

Rzadziej używane domeny, każda w osobnym pliku. **Wczytaj tylko plik pasujący do pytania**, potem grep po ID karty.

## Mapa

| Plik | Domena | Karty |
|---|---|---|
| references/e-mobile.md | E · Mobile (iOS, Android, cross-platform, offline, push, sklep) | E01 Wybór stacku mobilnego, E02 iOS, E03 Android, E04 React Native / Flutter, E05 Offline i synchronizacja, E06 Powiadomienia push, E07 Wydanie w sklepie |
| references/l-web3.md | L · Web3 (kontrakty, klucze, indeksowanie, integracja) | L01 Czy blockchain jest potrzebny, L02 Smart kontrakt, L03 Bezpieczeństwo kontraktu, L04 Klucze i portfele, L05 Indeksowanie danych z łańcucha, L06 Integracja z aplikacją |
| references/n-lowlevel.md | N · Systemy niskopoziomowe (pamięć, wątki, I/O, embedded, protokoły) | N01 Pamięć, N02 Współbieżność niskopoziomowa, N03 I/O i sieć, N05 Embedded, N06 Protokoły binarne |
| references/o-algorithms.md | O · Algorytmy i teoria | O01 Złożoność w praktyce, O02 Dobór struktury danych, O03 Algorytmy grafowe, O04 Problemy NP-trudne w produkcji, O05 Struktury probabilistyczne, O06 Numeryka |
| references/q-os.md | Q · Systemy operacyjne (pamięć wirtualna, dyski) | Q03 Pamięć wirtualna, Q06 System plików i dyski |
| references/r-languages.md | R · Języki, parsery, typy, GC, WebAssembly | R01 Projekt DSL, R02 Parsery, R03 Systemy typów, R05 GC i zarządzanie pamięcią w runtime, R06 WebAssembly |
| references/s-networking.md | S · Sieci zaawansowane (LB, HTTP/3, BGP, mesh, IPv6) | S01 Load balancing, S02 HTTP/2, HTTP/3, QUIC, S03 Routing i BGP, S05 Service mesh, S06 IPv6 |
| references/t-media.md | T · Kodeki, audio/DSP, obraz | T03 Kodeki i strumieniowanie, T04 Audio i DSP, T05 Przetwarzanie obrazu |
| references/u-data-science.md | U · Data science, statystyka, klasyczne ML | U01 Eksperymenty A/B, U02 Przyczynowość, U03 Prognozowanie szeregów czasowych, U04 Metryki i ich pułapki, U05 Bias i uczciwość modeli, G13 Klasyczne ML |
| references/v-hpc-gpu.md | V · HPC i GPU | V01 Kiedy GPU, V02 Pamięć GPU, V03 Wzorce równoległe, V04 Obliczenia rozproszone |
| references/w-formal.md | W · Metody formalne | W01 Kiedy metody formalne, W04 Model checking i TLA+ |
| references/x-enterprise.md | X · Integracja korporacyjna (ERP, EDI, gateway, iPaaS) | X01 Wzorce integracji, X02 ERP i systemy legacy, X03 API gateway i zarządzanie API, X04 EDI i formaty branżowe, X05 iPaaS, low-code, automatyzacje |
| references/y-legal.md | Y · Prawo, licencje, EU AI Act, NIS2 (orientacja, nie porada prawna) | Y01 Licencje open source, Y02 EU AI Act, Y03 NIS2 i cyberbezpieczeństwo w UE, Y04 Własność kodu, danych i wyników AI |

## Procedura

1. Dobierz plik z tabeli po nazwie domeny. Pytanie dotyczy dwóch domen: wczytaj oba pliki, nie inne.
2. W pliku `grep -n "^### <ID>" references/<plik>` → zakres linii → czytaj kartę.
3. Karta mówi, co ekspert sprawdza w pierwszej kolejności (Gdy / Twarde / Ekspert wie / Sprawdź / Nie). Nie zastępuje myślenia ani aktualnej dokumentacji.
4. Zadanie budowy? Najpierw `osa-build-gate`. Karty domenowe wspierają decyzje, nie omijają bramki.

## Uwaga o statusie

Karty O–Z (algorytmy, sieci, HPC, prawo itd.) pochodzą z osa-godmode v2 z polem „Ekspert wie”. Karty E, L, N, Q, R, S, T, U (G13) i W (W01, W04) miały to pole dopisane 2026-09-29 i **nie zostały zweryfikowane wykonaniem**. Prawo (Y) to orientacja, nie porada prawna. Wersje bibliotek, limity i ceny sprawdzaj w źródle.

## Nie

- Odpowiedzi z karty bez sprawdzenia wersji i dokumentacji, gdy zależy od nich wynik.
- Ładowania wszystkich 13 plików naraz.
