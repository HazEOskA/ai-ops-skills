# V · HPC i GPU

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### V01 · Kiedy GPU
**Gdy:** „przyspieszmy na GPU”, trening, inferencja, symulacja.
**Twarde:** GPU wygrywa przy masywnej równoległości danych i wysokiej intensywności arytmetycznej; przegrywa przy rozgałęzieniach, małych zadaniach i dużym transferze CPU↔GPU; najpierw zmierz, czy problem jest ograniczony obliczeniami, czy pamięcią (model roofline).
**Ekspert wie:** transfer przez PCIe potrafi zjeść cały zysk — dane muszą zostać na GPU przez wiele operacji; większość „wolnego GPU” to niedożywione GPU (czeka na dane z CPU/dysku).
**Sprawdź:** `nvidia-smi dmon` (wykorzystanie SM i pamięci) + profil Nsight Systems.
**Nie:** GPU dla zadania z jedną małą operacją; mierzenie bez synchronizacji (asynchroniczne jądra kłamią o czasie).

### V02 · Pamięć GPU
**Gdy:** OOM na GPU, wolne jądra, trening dużych modeli.
**Twarde:** dostęp do pamięci globalnej łączony (coalesced) — sąsiednie wątki czytają sąsiednie adresy; pamięć współdzielona jako ręczny cache; przy treningu pamięć = wagi + gradienty + stany optymalizatora (Adam ×2) + aktywacje; mixed precision (bf16) i gradient checkpointing obniżają ją kosztem obliczeń.
**Ekspert wie:** fragmentacja alokatora GPU daje OOM mimo wolnej sumarycznej pamięci — stałe rozmiary batchy i prealokacja pomagają bardziej niż mniejszy model.
**Sprawdź:** `torch.cuda.memory_summary()` / Nsight Compute dla efektywności dostępu.
**Nie:** fp32 domyślnie przy treningu dużych modeli; rozmiar batcha dobierany do OOM zamiast do zbieżności.

### V03 · Wzorce równoległe
**Gdy:** zrównoleglenie pętli, przetwarzanie wsadowe, wielordzeniowe CPU.
**Twarde:** prawo Amdahla — część sekwencyjna ogranicza przyspieszenie (5% sekwencyjnie = max 20×); wzorce: map, reduce, scan, stencil, pipeline; unikaj współdzielonych zapisów (false sharing na liniach cache); wektoryzacja SIMD przez układ danych struktura-tablic zamiast tablica-struktur.
**Ekspert wie:** false sharing potrafi sprawić, że wersja wielowątkowa jest wolniejsza od jednowątkowej — liczniki per wątek wyrównane do linii cache.
**Sprawdź:** przyspieszenie przy 1, 2, 4, 8 wątkach — krzywa pokazuje wąskie gardło.
**Nie:** więcej wątków niż rdzeni do zadań obliczeniowych; blokada w pętli wewnętrznej.

### V04 · Obliczenia rozproszone
**Gdy:** trening na wielu GPU, MPI, Spark/Ray, klastry.
**Twarde:** komunikacja (all-reduce) staje się wąskim gardłem przy skalowaniu — mierz stosunek obliczeń do komunikacji; data parallel najprostszy, model/pipeline/tensor parallel gdy model nie mieści się na jednym GPU; checkpointy, bo przy setkach węzłów awaria jest pewna; Ray/Dask dla Pythona zanim sięgniesz po MPI.
**Ekspert wie:** skalowanie słabe (więcej danych na więcej węzłów) i silne (to samo zadanie szybciej) to różne cele — podaj, o które chodzi.
**Sprawdź:** efektywność skalowania: czas(1 węzeł) / (N × czas(N węzłów)).
**Nie:** klaster dla zadania, które zmieści się na jednej mocnej maszynie; brak checkpointów w długim treningu.
