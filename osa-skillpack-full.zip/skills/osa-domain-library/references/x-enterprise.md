# X · Integracja korporacyjna (ERP, EDI, gateway, iPaaS)

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### X01 · Wzorce integracji
**Gdy:** łączenie systemów, synchronizacja danych, „dwa systemy się rozjeżdżają”.
**Twarde:** wybierz styl: plik wsadowy (prosty, opóźniony), wspólna baza (unikać — sprzężenie), RPC/API (synchroniczne, kruche przy awarii), wiadomości/zdarzenia (luźne sprzężenie, ostateczna spójność); jeden system jest źródłem prawdy per encja — nazwij go; kanoniczny model danych przy wielu systemach zamiast N×N mapowań; każda integracja ma DLQ i uzgadnianie (reconciliation).
**Ekspert wie:** każda integracja się rozjedzie — pytanie tylko, czy masz nocny proces uzgadniania, który to wykryje, zanim zrobi to klient.
**Sprawdź:** raport uzgodnienia: liczba i suma rekordów po obu stronach za ostatnią dobę.
**Nie:** dwukierunkowa synchronizacja bez reguły rozstrzygania konfliktów; integracja przez bezpośredni zapis do cudzej bazy.

### X02 · ERP i systemy legacy
**Gdy:** SAP, Dynamics, stare systemy produkcyjne, mainframe, „nie ma API”.
**Twarde:** nie modyfikuj rdzenia ERP — rozszerzenia i warstwa integracyjna obok; odczyt przez oficjalne API/BAPI/OData, a gdy go brak — przez replikę lub eksport, nie przez produkcyjną bazę; strangler fig do wygaszania legacy; dokumentuj zachowania, na których ktoś polega, zanim je zmienisz.
**Ekspert wie:** w systemach legacy dokumentacją jest zachowanie — testy charakteryzujące (nagraj wejście i wyjście z produkcji) są jedynym bezpiecznym punktem startu.
**Sprawdź:** lista konsumentów danych systemu (kto czyta, co i jak często) przed zmianą.
**Nie:** zapis bezpośrednio do tabel ERP; wygaszanie legacy big-bang.

### X03 · API gateway i zarządzanie API
**Gdy:** wiele API, partnerzy zewnętrzni, klucze, limity, monetyzacja API.
**Twarde:** gateway robi przekrojowe rzeczy (uwierzytelnianie, limity, logowanie, wersje), nie logikę biznesową; klucze per konsument z możliwością rotacji i odwołania; portal dla deweloperów z dokumentacją i sandboxem; metryki per konsument (użycie, błędy, latencja).
**Ekspert wie:** logika biznesowa w gatewayu (transformacje, orkiestracja) zamienia go w monolit, którego nikt nie umie testować.
**Sprawdź:** czy da się odciąć jednego konsumenta bez wpływu na innych.
**Nie:** jeden klucz API dla wszystkich partnerów; gateway jako miejsce na reguły biznesowe.

### X04 · EDI i formaty branżowe
**Gdy:** zamówienia B2B, logistyka, faktury elektroniczne, przemysł.
**Twarde:** formaty (EDIFACT, X12, UBL/Peppol, KSeF w Polsce, e-faktury w UE) mają standard i lokalne odmiany partnerów — mapowanie per partner jest normą; walidacja schematu i reguł biznesowych przed przetworzeniem; potwierdzenia (ACK/functional acknowledgment) śledzone; archiwum oryginałów przez wymagany okres.
**Ekspert wie:** wdrożenie EDI to w 80% testy z partnerem i uzgadnianie wyjątków, w 20% kod.
**Sprawdź:** walidacja pliku przykładowego od partnera + test odrzucenia błędnego dokumentu.
**Nie:** parser EDI pisany od zera, gdy istnieje dojrzała biblioteka; brak archiwum oryginalnych komunikatów.

### X05 · iPaaS, low-code, automatyzacje
**Gdy:** Zapier, Make, n8n, Power Automate, „szybka automatyzacja”.
**Twarde:** świetne do prototypu i procesów o niskiej stawce; każdy przepływ ma właściciela, monitoring błędów i dokumentację; sekrety w menedżerze platformy, nie w krokach; gdy przepływ ma > 20 kroków, rozgałęzienia i retry — to już aplikacja i powinien być kodem z testami.
**Ekspert wie:** automatyzacje low-code psują się cicho (zmiana pola w źródle) — bez alertu na błędy i bez uzgodnienia wyników nikt nie wie, że przestały działać.
**Sprawdź:** lista przepływów z datą ostatniego udanego wykonania i właścicielem.
**Nie:** krytyczny proces finansowy w low-code bez monitoringu; kopiowane kroki zamiast wspólnego podprzepływu.
