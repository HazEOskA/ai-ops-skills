# U · Data science, statystyka, klasyczne ML

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### U01 · Eksperymenty A/B
**Gdy:** „czy zmiana pomogła”, testy funkcji, cennik.
**Twarde:** metryka główna, minimalny wykrywalny efekt i wielkość próby ustalone przed startem; losowanie po jednostce, która widzi efekt (użytkownik, nie sesja); czas trwania pełnymi tygodniami; zakaz podglądania i zatrzymywania „gdy wyjdzie istotne” (albo metoda sekwencyjna); sprawdź SRM (niezgodność proporcji grup) przed analizą.
**Ekspert wie:** przy wielu metrykach jedna wyjdzie istotna przypadkiem — korekta na porównania wielokrotne albo jedna metryka decyzyjna; efekt nowości zanika po tygodniach.
**Sprawdź:** kalkulator mocy przed startem + test chi² dla SRM.
**Nie:** kończenie testu po trzech dniach; zmiana metryki głównej po zobaczeniu wyników.

### U02 · Przyczynowość
**Gdy:** „X powoduje Y?”, analiza bez eksperymentu, wnioski z danych historycznych.
**Twarde:** korelacja w danych obserwacyjnych jest skażona zmiennymi zakłócającymi i selekcją; narysuj graf przyczynowy (DAG) zanim wybierzesz zmienne kontrolne — kontrolowanie zmiennej pośredniczącej lub kolidera psuje wynik; metody: różnica w różnicach, regresja nieciągła, zmienne instrumentalne, dopasowanie.
**Ekspert wie:** paradoks Simpsona — trend w całości może być odwrotny niż w każdej podgrupie; zawsze sprawdź wynik w segmentach.
**Sprawdź:** czy wniosek przeżywa test placebo (fałszywa data zmiany nie daje efektu).
**Nie:** „użytkownicy funkcji X zostają dłużej, więc X zwiększa retencję” bez kontroli selekcji.

### U03 · Prognozowanie szeregów czasowych
**Gdy:** popyt, obciążenie, przychód, pojemność.
**Twarde:** baseline: ostatnia wartość i ta sama wartość sezonowo (tydzień temu) — model musi je pobić; walidacja kroczącym oknem w czasie, nigdy losowo; prognoza z przedziałem, nie punktem; sezonowość wielokrotna (dzień, tydzień, rok) i święta jawnie.
**Ekspert wie:** proste modele (ETS, regresja z cechami kalendarzowymi, gradient boosting na opóźnieniach) zwykle wygrywają z sieciami na danych biznesowych; zmiana reżimu (pandemia, nowy produkt) unieważnia historię — wykrywaj ją.
**Sprawdź:** MAPE/MASE vs baseline sezonowy na kilku oknach testowych.
**Nie:** prognoza bez przedziału niepewności; walidacja na losowym podziale.

### U04 · Metryki i ich pułapki
**Gdy:** definiowanie KPI, dashboardy, raporty.
**Twarde:** każda metryka ma definicję (licznik, mianownik, okno, filtr) spisaną jednym zdaniem; średnia przy rozkładach skośnych kłamie — percentyle i mediana; współczynniki porównuj z przedziałami ufności; prawo Goodharta: metryka zamieniona w cel przestaje mierzyć.
**Ekspert wie:** zmiana definicji zdarzenia lub instrumentacji wygląda na wykresie jak zmiana biznesu — każdy skok sprawdź najpierw w logu wdrożeń.
**Sprawdź:** ta sama metryka policzona dwiema niezależnymi ścieżkami daje ten sam wynik.
**Nie:** średni czas odpowiedzi jako SLO; odsetki bez liczebności.

### U05 · Bias i uczciwość modeli
**Gdy:** model decyduje o ludziach (rekrutacja, kredyt, scoring, moderacja).
**Twarde:** mierz jakość osobno per grupa, nie tylko średnio; usunięcie cechy chronionej nie usuwa biasu (proxy: kod pocztowy, szkoła, przerwy w CV); zdefiniuj, którą definicję uczciwości przyjmujesz — różne są wzajemnie sprzeczne; człowiek w pętli dla decyzji o wysokiej stawce; zapis uzasadnienia decyzji.
**Ekspert wie:** w rekrutacji dane historyczne kodują dawne decyzje ludzi — model uczony na nich je powtarza; EU AI Act klasyfikuje systemy rekrutacyjne jako wysokiego ryzyka (patrz Y02).
**Sprawdź:** tabela metryk (precyzja, czułość, odsetek pozytywnych) per grupa.
**Nie:** „model nie widzi płci, więc jest uczciwy”; automatyczne odrzucanie bez przeglądu człowieka.

### G13 · Klasyczne ML
**Gdy:** predykcja, klasyfikacja, scoring, dane tabelaryczne.
**Twarde:** gradient boosting na danych tabelarycznych bije sieci w większości przypadków — zacznij tam; baseline trywialny (najczęstsza klasa, ostatnia wartość) jest obowiązkowy jako punkt odniesienia; podział train/test po czasie, nie losowo, gdy dane mają wymiar czasowy; wyciek cechy z przyszłości to najczęstszy powód „świetnych" wyników; metryka dobrana do kosztu błędu, nie accuracy przy niezbalansowanych klasach.
**Ekspert wie:** Wyciek danych objawia się zbyt dobrym wynikiem — szukaj cech, które nie istniałyby w chwili predykcji (status po fakcie, identyfikatory skorelowane z etykietą). Walidacja po czasie zwykle obniża wynik o to, co wyciekło.
**Sprawdź:** wynik modelu przeciw baseline'owi trywialnemu i test na danych z okresu późniejszego niż trening.
**Nie:** losowy podział danych szeregów czasowych; accuracy przy 2% klasie pozytywnej; cechy liczone na całym zbiorze przed podziałem.
