# R · Języki, parsery, typy, GC, WebAssembly

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### R01 · Projekt DSL
**Gdy:** własny język konfiguracji, reguł, workflow, „język ludzki jako interfejs”.
**Twarde:** najpierw sprawdź, czy wystarczy JSON/YAML ze schematem albo biblioteka w istniejącym języku (embedded DSL) — zewnętrzny DSL to parser, komunikaty błędów, narzędzia i dokumentacja na zawsze; semantykę zdefiniuj precyzyjnie przed składnią; błąd użytkownika musi wskazywać linię, kolumnę i propozycję poprawki.
**Ekspert wie:** koszt DSL to nie kompilator, tylko ekosystem: podświetlanie składni, LSP, formatter, debugger, migracje wersji języka — bez nich użytkownicy wracają do kodu.
**Sprawdź:** czy osoba spoza projektu napisze poprawny program po 15 minutach z dokumentacją.
**Nie:** DSL bez wersji języka; semantyka wynikająca z implementacji zamiast ze specyfikacji; Turing-zupełność „przy okazji” w języku konfiguracji.

### R02 · Parsery
**Gdy:** parsowanie formatu, języka, logów, wejścia użytkownika.
**Twarde:** regex tylko dla języków regularnych — zagnieżdżenia wymagają parsera; wybór: ręczny recursive descent (najlepsze błędy, pełna kontrola), generator (ANTLR, tree-sitter — szybko, gorsze błędy), kombinatory parserów (w kodzie, czytelne); gramatyka z testami na przypadkach brzegowych i niepoprawnych; odzyskiwanie po błędzie, żeby raportować wiele błędów naraz.
**Ekspert wie:** parser wejścia z zewnątrz to powierzchnia ataku — limity głębokości zagnieżdżenia i rozmiaru, inaczej stack overflow albo ReDoS przy katastrofalnym backtrackingu.
**Sprawdź:** fuzzing parsera + test na wejściu 10 MB i zagnieżdżeniu 10 000 poziomów.
**Nie:** HTML albo JSON parsowany regexem; regex z zagnieżdżonymi kwantyfikatorami na niezaufanym wejściu.

### R03 · Systemy typów
**Gdy:** projekt API w kodzie, TypeScript, błędy w runtime, modelowanie domeny.
**Twarde:** niepoprawne stany mają być niereprezentowalne (unie dyskryminowane zamiast pól opcjonalnych); typy nominalne/branded dla identyfikatorów (UserId ≠ OrderId); parsuj na granicy, nie waliduj w środku — po parsowaniu dane mają typ, który gwarantuje poprawność; `any` i rzutowania to dziury do zaznaczania w review.
**Ekspert wie:** typy statyczne kończą się na granicy procesu — JSON z sieci, baza, zmienne środowiskowe wymagają walidacji w runtime (zod, pydantic), inaczej typ kłamie.
**Sprawdź:** `tsc --noEmit --strict` / `mypy --strict`; lista `any`/`as` w diffie.
**Nie:** `as` zamiast walidacji; typ zbyt ogólny „na przyszłość”; wyłączony strict.

### R05 · GC i zarządzanie pamięcią w runtime
**Gdy:** pauzy, skoki latencji, rosnąca pamięć w językach z GC.
**Twarde:** pauzy GC rosną z rozmiarem żywego heapu i tempem alokacji — najpierw zmniejsz alokacje, potem stroj GC; obiekty krótkotrwałe są tanie (młoda generacja), średnio żyjące najdroższe; wycieki w językach z GC to referencje: cache bez limitu, listenery bez odpięcia, domknięcia.
**Ekspert wie:** p99 latencji w serwisach JVM/Go/.NET to często GC — koreluj logi GC z histogramem latencji zanim zaczniesz optymalizować kod.
**Sprawdź:** logi GC (`-Xlog:gc`, `GODEBUG=gctrace=1`, `--trace-gc`) + heap snapshot porównany w odstępie czasu.
**Nie:** ręczne wywoływanie GC; zwiększanie heapu jako naprawa wycieku.

### R06 · WebAssembly
**Gdy:** kod natywny w przeglądarce, sandbox pluginów, przenośne moduły.
**Twarde:** Wasm daje izolację pamięci i przenośność, ale granica JS↔Wasm kosztuje — przekazuj duże bloki, nie wiele małych wywołań; WASI dla uruchamiania poza przeglądarką; sandbox pluginów przez Wasm z limitem paliwa (fuel) i pamięci jest dojrzałym wzorcem.
**Ekspert wie:** rozmiar binarki (i czas kompilacji w przeglądarce) to częsty ukryty koszt — optymalizuj pod rozmiar i strumieniuj kompilację.
**Sprawdź:** rozmiar `.wasm` po `wasm-opt -Oz` + profil czasu na granicy JS↔Wasm.
**Nie:** Wasm dla kodu, który jest ograniczony przez DOM; kopiowanie danych przez granicę w każdej klatce.
