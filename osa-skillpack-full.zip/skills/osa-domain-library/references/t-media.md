# T · Kodeki, audio/DSP, obraz

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### T03 · Kodeki i strumieniowanie
**Gdy:** wideo w aplikacji, transmisja, nagrywanie, przetwarzanie ffmpegiem.
**Twarde:** kodek (H.264 zgodność, H.265/AV1 wydajność, licencje) ≠ kontener (MP4, WebM, MKV); streaming adaptacyjny HLS/DASH z drabiną bitrate'ów; latencja: HLS klasyczny 10–30 s, LL-HLS ~2–5 s, WebRTC < 1 s; kodowanie sprzętowe tańsze, programowe lepsze jakościowo przy tym samym bitrate.
**Ekspert wie:** jakość mierz metryką percepcyjną (VMAF), nie bitrate'em — ta sama jakość przy różnym bitrate zależy od treści.
**Sprawdź:** `ffprobe -show_streams plik`; VMAF dla wariantów drabiny.
**Nie:** jeden plik wideo serwowany wszystkim; transkodowanie w ścieżce żądania.

### T04 · Audio i DSP
**Gdy:** przetwarzanie dźwięku, rozpoznawanie mowy, efekty, analiza sygnału.
**Twarde:** częstotliwość próbkowania ≥ 2× najwyższej częstotliwości (Nyquist) — filtr antyaliasingowy przed decymacją; wątek audio w czasie rzeczywistym bez alokacji, blokad i I/O; bufor to kompromis latencja vs ryzyko trzasków; FFT z oknem (Hann), bo bez niego widmo przecieka.
**Ekspert wie:** trzaski i przerwy to prawie zawsze niedotrzymanie terminu wypełnienia bufora (alokacja, lock, GC w wątku audio), nie „słaby sprzęt”.
**Sprawdź:** pomiar czasu callbacku audio vs budżet (rozmiar bufora / częstotliwość).
**Nie:** zmiana częstotliwości próbkowania bez filtra; logowanie z wątku audio.

### T05 · Przetwarzanie obrazu
**Gdy:** miniatury, OCR, analiza zdjęć, wizja komputerowa.
**Twarde:** orientacja z EXIF przed jakąkolwiek operacją; skalowanie w dół z filtrem (Lanczos) w przestrzeni liniowej; usuń metadane (lokalizacja!) przed publikacją; dla CV zacznij od gotowego modelu i sprawdź go na własnych danych przed treningiem.
**Ekspert wie:** „model słabo działa u klienta” w wizji to zwykle różnica rozkładu: oświetlenie, kamera, kompresja, kadrowanie — nie architektura sieci.
**Sprawdź:** metryki na próbce z realnego źródła klienta, nie z publicznego zbioru.
**Nie:** przetwarzanie obrazów w wątku żądania; publikacja zdjęć z GPS w EXIF.
