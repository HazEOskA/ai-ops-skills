# O · Algorytmy i teoria

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### O01 · Złożoność w praktyce
**Gdy:** „czy to się przeskaluje”, wolna pętla, duże n.
**Twarde:** policz n realnie (dziś, za rok, najgorszy klient) zanim wybierzesz algorytm; O(n²) przy n=10⁴ to 10⁸ operacji, czyli sekundy — przy n=10⁶ to godziny; stała i lokalność pamięci biją asymptotykę do n rzędu 10⁴–10⁵; koszt zamortyzowany ≠ najgorszy przypadek (rehash, resize, GC) — liczy się tam, gdzie jest p99.
**Ekspert wie:** ukryte O(n²) siedzi w bibliotekach: `list.remove`, `in` na liście, konkatenacja stringów w pętli, `Array.shift`, zapytanie SQL w pętli (to jest O(n) round-tripów).
**Sprawdź:** pomiar dla n, 2n, 4n — stosunek czasów mówi o wykładniku szybciej niż analiza kodu.
**Nie:** optymalizacja asymptotyki przy n=200; benchmark na małych danych ekstrapolowany liniowo.

### O02 · Dobór struktury danych
**Gdy:** projekt modułu, wolne wyszukiwanie, dużo pamięci.
**Twarde:** zacznij od operacji dominującej (wstaw / szukaj / zakres / min / kolejność) i jej częstości; hash dla równości, drzewo zrównoważone lub skip-lista dla zakresów i porządku, kopiec dla top-k i kolejek priorytetowych, trie dla prefiksów, union-find dla spójności; tablica ciągła bije struktury wskaźnikowe dzięki cache CPU.
**Ekspert wie:** top-k z n elementów to kopiec rozmiaru k (O(n log k)), nie sortowanie całości; LRU to hash + lista dwukierunkowa; niezmienność struktur (persistent) ułatwia współbieżność kosztem alokacji.
**Sprawdź:** profil alokacji i czasu na realnym rozkładzie danych, nie jednorodnym.
**Nie:** mapa tam, gdzie klucze to gęste liczby (tablica); lista jako kolejka FIFO z usuwaniem z przodu.

### O03 · Algorytmy grafowe
**Gdy:** zależności, trasy, sieci, rekomendacje, uprawnienia dziedziczone.
**Twarde:** najpierw nazwij problem kanoniczny: najkrótsza ścieżka (BFS bez wag, Dijkstra nieujemne, Bellman-Ford z ujemnymi), sortowanie topologiczne (DAG, wykrywanie cykli), silnie spójne składowe (Tarjan/Kosaraju), minimalne drzewo rozpinające, przepływ i skojarzenie (max-flow/min-cut); reprezentacja: lista sąsiedztwa przy grafach rzadkich, macierz tylko przy gęstych i małych.
**Ekspert wie:** większość „dziwnych” problemów biznesowych (przydział zadań, harmonogram z zależnościami, wykrywanie oszustw w sieci transakcji) redukuje się do znanego problemu grafowego — redukcja jest pracą, algorytm jest z półki.
**Sprawdź:** test na grafie z cyklem, grafie niespójnym i grafie o jednym wierzchołku.
**Nie:** rekurencyjne DFS na głębokich grafach bez limitu stosu; baza grafowa dla problemu, który rozwiązuje jedno zapytanie rekurencyjne CTE.

### O04 · Problemy NP-trudne w produkcji
**Gdy:** harmonogramowanie, trasowanie, pakowanie, przydział z ograniczeniami.
**Twarde:** rozpoznaj trudność zanim obiecasz optimum; dla realnych rozmiarów używaj solverów (MILP, CP-SAT, SAT/SMT) zamiast własnej heurystyki; zdefiniuj jakość jako lukę do dolnej granicy, nie „wygląda dobrze”; limit czasu solvera + najlepsze znalezione rozwiązanie to standardowy kontrakt.
**Ekspert wie:** sformułowanie modelu (zmienne, symetrie, ograniczenia redundantne) zmienia czas rozwiązania o rzędy wielkości bardziej niż wybór solvera.
**Sprawdź:** luka optymalności raportowana przez solver + czas na instancji o docelowym rozmiarze.
**Nie:** przeszukiwanie wyczerpujące „bo danych jest mało” bez policzenia, ile to kombinacji; zachłanny algorytm sprzedawany jako optymalny.

### O05 · Struktury probabilistyczne
**Gdy:** ogromne strumienie, liczenie unikatów, deduplikacja, „czy widziałem to już”.
**Twarde:** Bloom filter — przynależność bez fałszywych negatywów, z kontrolowanym odsetkiem fałszywych pozytywów; HyperLogLog — liczba unikatów z błędem ~1% w kilobajtach; Count-Min Sketch — częstości z przeszacowaniem; MinHash/LSH — podobieństwo zbiorów; parametry dobierasz z wymaganego błędu, nie na oko.
**Ekspert wie:** Bloom filter nie obsługuje usuwania (potrzebny counting Bloom albo cuckoo filter); HLL da się łączyć między shardami bez utraty dokładności.
**Sprawdź:** zmierzony błąd na próbce z prawdą dokładną vs deklarowany.
**Nie:** struktura probabilistyczna tam, gdzie błąd ma konsekwencję prawną lub finansową.

### O06 · Numeryka
**Gdy:** pieniądze, sumy, statystyki, symulacje, porównywanie liczb.
**Twarde:** pieniądze nigdy we float — liczba całkowita w najmniejszej jednostce albo decimal; porównanie float z tolerancją względną; sumowanie wielu wartości: Kahan albo sortowanie rosnąco; odejmowanie bliskich wartości niszczy precyzję (katastrofalna utrata cyfr); deterministyczność float zależy od kolejności operacji — równoległość zmienia wynik.
**Ekspert wie:** średnia i wariancja „w jednym przebiegu” naiwnym wzorem są niestabilne — używaj algorytmu Welforda; `0.1 + 0.2 != 0.3` to nie błąd języka, tylko reprezentacji.
**Sprawdź:** porównanie wyniku z obliczeniem w wyższej precyzji na próbce.
**Nie:** zaokrąglanie w środku obliczeń; float jako klucz mapy; testy równości floatów przez `==`.
