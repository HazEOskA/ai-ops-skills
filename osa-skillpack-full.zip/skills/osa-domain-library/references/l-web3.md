# L · Web3 (kontrakty, klucze, indeksowanie, integracja)

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### L01 · Czy blockchain jest potrzebny
**Gdy:** „zróbmy to on-chain".
**Twarde:** uzasadnienie musi wskazywać brak zaufanej strony trzeciej albo wymóg publicznej weryfikowalności — jeśli jest zaufany operator, baza danych jest lepsza pod każdym względem; koszt transakcji i finalność są ograniczeniami produktowymi, nie technicznymi szczegółami; dane on-chain są publiczne i trwałe, także te, które nie powinny być.
**Ekspert wie:** Jeśli jest zaufana strona trzecia, baza danych wygrywa; on-chain uzasadnia brak zaufania między stronami albo publiczna weryfikowalność. Wszystko, co zapiszesz, jest publiczne i nieusuwalne — dane osobowe nigdy tam nie trafiają, nawet zaszyfrowane (klucz kiedyś się zdezaktualizuje).
**Sprawdź:** opisz to samo rozwiązanie bez łańcucha i porównaj koszt oraz złożoność.
**Nie:** blockchain jako element marketingowy; dane osobowe on-chain; założenie, że transakcja jest natychmiastowa i darmowa.

### L02 · Smart kontrakt
**Gdy:** piszesz kontrakt.
**Twarde:** kod jest niezmienny po wdrożeniu — wzorzec aktualizacji albo świadoma decyzja o braku, podjęta przed wdrożeniem, nie po; checks-effects-interactions jako domyślna kolejność; zewnętrzne wywołanie to oddanie kontroli, zakładaj reentrancy; limit gazu kształtuje algorytmy (pętle po tablicach rosnących bez ograniczenia są bombą); testy na forku sieci głównej z realnym stanem.
**Ekspert wie:** Aktualizowalność przez proxy to zaufanie do administratora (klucz plus timelock); kontrakt niezmienny to brak możliwości naprawy błędu — obie ścieżki są decyzją projektową. Pętla po rosnącej tablicy to podatność DoS, bo gaz ma limit.
**Sprawdź:** pokrycie testami ścieżek awaryjnych + test na forku + analiza statyczna (slither).
**Nie:** pętla po nieograniczonej tablicy; zaufanie do zwracanej wartości bez sprawdzenia; wdrożenie bez planu na błąd w kodzie.

### L03 · Bezpieczeństwo kontraktu
**Gdy:** przed wdrożeniem, audyt.
**Twarde:** najczęstsze klasy: reentrancy, manipulacja ceną oracle, błędna kontrola dostępu, arytmetyka i zaokrąglenia na niekorzyść protokołu, front-running; oracle z jednego źródła to pojedynczy punkt awarii; audyt zewnętrzny to nie gwarancja, tylko redukcja ryzyka; wdrażaj z limitem wartości i podnoś go stopniowo.
**Ekspert wie:** Większość strat pochodzi z logiki ekonomicznej i zaufania do oracle (manipulacja ceną flash loanem w jednej transakcji), nie z błędów kompilatora. Cena z jednej puli spot w tym samym bloku jest manipulowalna — stosuj TWAP albo oracle odporny na manipulację.
**Sprawdź:** slither + testy fuzz + scenariusze ataku spisane jako testy.
**Nie:** wdrożenie całej płynności od pierwszego dnia; oracle bez ochrony przed manipulacją; uprawnienia administratora bez timelocka i multisigu.

### L04 · Klucze i portfele
**Gdy:** obsługa kluczy, podpisy, dostęp użytkownika.
**Twarde:** klucz prywatny nigdy nie trafia na serwer ani do logów; operacje o dużej wartości za multisigiem z progiem i timelockiem; podpisywanie wiadomości musi jasno pokazywać, co użytkownik podpisuje (ślepy podpis to wektor kradzieży); klucze operacyjne oddzielone od kluczy skarbca.
**Ekspert wie:** Podpis wiadomości „na ślepo” (bez czytelnego opisu) oddaje pełną kontrolę; EIP-712 pokazuje strukturę. Klucz skarbca w multisigu z timelockiem i osobne klucze operacyjne ograniczają zasięg jednego wycieku.
**Sprawdź:** przegląd, gdzie w systemie mógłby pojawić się klucz prywatny (logi, telemetria, kopie zapasowe).
**Nie:** jeden klucz do wszystkiego; klucz w zmiennej środowiskowej na współdzielonym serwerze; podpis żądania nieczytelnego dla użytkownika.

### L05 · Indeksowanie danych z łańcucha
**Gdy:** aplikacja czyta historię, salda, zdarzenia.
**Twarde:** nie odpytuj węzła per żądanie użytkownika — indeksuj do własnej bazy; reorganizacje łańcucha są normalne, więc indekser musi umieć cofnąć bloki; śledź wysokość ostatniego przetworzonego bloku i opóźnienie względem czoła łańcucha; zdarzenia to kontrakt, więc zmiana kontraktu to migracja indeksera.
**Ekspert wie:** Reorganizacje łańcucha unieważniają ostatnie bloki — indekser zapisuje hash bloku i cofa dane przy niezgodności rodzica. Finalność różni się między łańcuchami, więc próg „bezpieczne” jest parametrem konfiguracji.
**Sprawdź:** opóźnienie indeksera w blokach + test obsługi reorganizacji.
**Nie:** odczyt bezpośrednio z węzła w ścieżce żądania; założenie, że bloki są ostateczne od razu; brak obsługi cofnięcia.

### L06 · Integracja z aplikacją
**Gdy:** front łączy się z portfelem, transakcje w UI.
**Twarde:** transakcja ma trzy stany widoczne dla użytkownika: wysłana, potwierdzona, nieudana — zaprojektuj wszystkie; szacowanie kosztu pokazane przed podpisem; obsłuż odrzucenie w portfelu, zmianę sieci i zmianę konta w trakcie sesji; nigdy nie zakładaj, że użytkownik jest w oczekiwanej sieci.
**Ekspert wie:** Transakcja może zostać zastąpiona (ten sam nonce z wyższą opłatą) albo utknąć — UI śledzi hash i nonce. Odrzucenie w portfelu to normalny przepływ, nie błąd, a zmiana sieci lub konta w trakcie sesji musi resetować stan.
**Sprawdź:** przejdź ścieżkę z odrzuceniem podpisu, ze zmianą sieci i z transakcją, która utknęła.
**Nie:** UI zakładające natychmiastowe potwierdzenie; brak obsługi zmiany konta; koszt pokazany dopiero po podpisie.
