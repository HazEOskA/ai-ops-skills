# E · Mobile (iOS, Android, cross-platform, offline, push, sklep)

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### E01 · Wybór stacku mobilnego
**Gdy:** „w czym pisać apkę".
**Twarde:** natywnie gdy liczy się integracja z systemem, wydajność grafiki i długie życie produktu; cross-platform gdy zespół jest mały, a UI jest głównie formularzami i listami; jeden zespół nie utrzyma dwóch natywnych aplikacji; policz koszt utrzymania na 3 lata, nie koszt startu.
**Ekspert wie:** Decyduje nie wydajność, tylko dostęp do API systemowych i koszt utrzymania zespołu: funkcja wymagająca nowego API systemu w cross-platform czeka na wtyczkę albo wymaga kodu natywnego. Wypisz takie funkcje przed wyborem stacku.
**Sprawdź:** wypisz funkcje wymagające API systemowego i sprawdź dostępność w wybranym frameworku.
**Nie:** cross-platform dla aplikacji opartej o kamerę, AR albo ciężką grafikę; dwa natywne kody przy jednym programiście.

### E02 · iOS
**Gdy:** Swift, SwiftUI, UIKit.
**Twarde:** SwiftUI dla nowego UI, UIKit gdzie SwiftUI nie wystarcza — mieszanie jest normalne; cykl życia widoku i `@State` vs `@StateObject` to najczęstsze źródło błędów; praca w tle jest ściśle limitowana przez system, nie planuj długich zadań; uprawnienia proś w kontekście, nie na starcie; pamiętaj o cyklach referencji w domknięciach.
**Ekspert wie:** Praca w tle na iOS jest przyznawana przez system i może nie nastąpić — background fetch i ciche powiadomienia to prośby, nie harmonogram. Cykl życia (zabicie aplikacji, brak sieci, tryb niskiego poboru) testuj na urządzeniu.
**Sprawdź:** Instruments (Leaks, Time Profiler) na realnym urządzeniu, nie w symulatorze.
**Nie:** blokowanie głównego wątku I/O; założenie, że aplikacja żyje w tle; testowanie wydajności wyłącznie w symulatorze.

### E03 · Android
**Gdy:** Kotlin, Compose, Android SDK.
**Twarde:** Compose dla nowego UI; cykl życia i zmiany konfiguracji muszą przetrwać obrót ekranu i zabicie procesu; praca w tle przez WorkManager, nie przez wątki; ograniczenia baterii (Doze, standby) łamią naiwne harmonogramy; fragmentacja urządzeń jest realna — testuj na słabym telefonie.
**Ekspert wie:** Producenci urządzeń dokładają własne agresywne oszczędzanie baterii poza standardowym Doze, więc zadania w tle zachowują się różnie na różnych markach. WorkManager z ograniczeniami jest kontraktem; własny serwis pierwszoplanowy wymaga powiadomienia i uzasadnienia w sklepie.
**Sprawdź:** wymuś zabicie procesu w tle (Developer options) i sprawdź odtworzenie stanu; StrictMode na dev.
**Nie:** stan trzymany tylko w pamięci Activity; własny scheduler zamiast WorkManagera; testowanie tylko na flagowcu.

### E04 · React Native / Flutter
**Gdy:** cross-platform.
**Twarde:** most/kanał do natywnego to wąskie gardło — minimalizuj przepływ danych przez niego; listy wirtualizowane obowiązkowo; obrazy z cache i rozmiarem docelowym; aktualizacje OTA tylko dla warstwy JS/Dart i zgodnie z regulaminem sklepu; wersje bibliotek natywnych to najczęstsze źródło problemów przy aktualizacji.
**Ekspert wie:** Aktualizacje OTA w RN/Flutter obejmują tylko warstwę skryptową; zmiana natywna wymaga wydania w sklepie. Pilnuj zgodności wersji między JS a natywnym, bo niezgodność objawia się awarią tylko u części użytkowników.
**Sprawdź:** profiler frameworka na liście z 500 elementami na słabym urządzeniu.
**Nie:** animacje sterowane z warstwy JS zamiast natywnie; przekazywanie dużych obiektów przez most co klatkę; zależność od biblioteki bez commitów od roku.

### E05 · Offline i synchronizacja
**Gdy:** aplikacja ma działać bez sieci.
**Twarde:** lokalna baza jako źródło prawdy dla UI, synchronizacja w tle; każda zmiana lokalna ma identyfikator i znacznik wersji; konflikt rozstrzygaj świadomie (ostatni wygrywa, scalanie, pytanie użytkownika) — brak decyzji to cicha utrata danych; kolejka operacji przetrwa restart aplikacji.
**Ekspert wie:** Konflikty są nieuniknione, a „ostatni wygrywa” według zegara urządzenia gubi dane przy rozjechanym zegarze. Używaj wersji lub zegara serwera, a operacje modeluj jako zdarzenia z idempotentnym identyfikatorem, nie jako nadpisania stanu.
**Sprawdź:** wykonaj zmiany offline na dwóch urządzeniach, połącz i sprawdź wynik.
**Nie:** synchronizacja tylko przy starcie aplikacji; brak strategii konfliktu; kolejka trzymana w pamięci.

### E06 · Powiadomienia push
**Gdy:** push, deep link.
**Twarde:** push jest zawodny z definicji — nie może być jedynym kanałem dostarczenia informacji; token odświeżany i unieważniany po wylogowaniu; deep link prowadzi do sensownego ekranu także przy zimnym starcie i przy braku uprawnień; ładunek bez danych wrażliwych; zgoda proszona w kontekście.
**Ekspert wie:** Token push wygasa, zmienia się po reinstalacji i jest per aplikacja i urządzenie. Zapisuj go z czasem ostatniego użycia i usuwaj po błędzie „unregistered” — bez tego wysyłasz w próżnię i psujesz reputację nadawcy.
**Sprawdź:** push przy zabitej aplikacji, przy wyłączonych powiadomieniach i po ponownej instalacji.
**Nie:** push jako gwarantowany transport; token przypisany do urządzenia bez powiązania z sesją; deep link wymagający aktywnej sesji bez ścieżki logowania.

### E07 · Wydanie w sklepie
**Gdy:** publikacja, aktualizacja.
**Twarde:** stopniowe wdrożenie procentowe z monitoringiem awarii; wersje starsze żyją miesiącami — API musi być wstecznie kompatybilne; wymuszona aktualizacja jako mechanizm awaryjny, przygotowany zawczasu; review sklepu potrafi trwać, planuj bufor; zbieranie raportów awarii od pierwszej wersji.
**Ekspert wie:** Wymuszona aktualizacja musi być zaplanowana w pierwszej wersji (endpoint minimalnej wersji): dodana później nie dosięgnie starych instalacji, a to właśnie one mają błąd. Stopniowe wdrożenie z metryką sesji bez awarii to jedyna reakcja przed 100%.
**Sprawdź:** wskaźnik sesji bez awarii per wersja przed zwiększeniem procentu wdrożenia.
**Nie:** wdrożenie na 100% od razu; API łamiące starą wersję aplikacji; brak mechanizmu wymuszonej aktualizacji.
