# Y · Prawo, licencje, EU AI Act, NIS2 (orientacja, nie porada prawna)

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### Y01 · Licencje open source
**Gdy:** dodajesz zależność, publikujesz kod, sprzedajesz produkt z OSS.
**Twarde:** permisywne (MIT, BSD, Apache-2.0 — z klauzulą patentową) pozwalają na zamknięty produkt z zachowaniem informacji o licencji; copyleft słaby (LGPL, MPL — per plik/biblioteka) i silny (GPL — dzieło pochodne); AGPL obejmuje udostępnianie przez sieć — kluczowe dla SaaS; licencje „source-available” (BSL, SSPL, Elastic) to nie open source; zgodność licencji sprawdzana automatycznie w CI.
**Ekspert wie:** kod wygenerowany przez model może odtwarzać fragmenty kodu na licencji copyleft — przy dłuższych, charakterystycznych fragmentach sprawdzaj pochodzenie.
**Sprawdź:** `npx license-checker --summary` / `pip-licenses` / `syft` + polityka dozwolonych licencji.
**Nie:** AGPL w zamkniętym SaaS bez analizy; usuwanie nagłówków licencyjnych; brak pliku z atrybucjami w dystrybucji.

### Y02 · EU AI Act
**Gdy:** budujesz lub wdrażasz system AI w UE (w tym NL/PL).
**Twarde:** podejście oparte na ryzyku: praktyki zakazane, systemy wysokiego ryzyka (m.in. rekrutacja i ocena pracowników, edukacja, dostęp do usług, infrastruktura krytyczna), obowiązki przejrzystości (chatboty, treści generowane), modele ogólnego przeznaczenia; wysokie ryzyko wymaga m.in. zarządzania ryzykiem, jakości danych, dokumentacji technicznej, logowania, nadzoru człowieka i dokładności; obowiązki wchodzą etapami w latach 2025–2027 — sprawdź aktualny harmonogram.
**Ekspert wie:** narzędzie rekrutacyjne ze scoringiem kandydatów jest w kategorii wysokiego ryzyka — logowanie decyzji i nadzór człowieka warto zaprojektować od pierwszej wersji, bo dołożenie później to przebudowa.
**Sprawdź:** klasyfikacja systemu (kategoria ryzyka + rola: dostawca czy podmiot wdrażający) spisana w repo.
**Nie:** założenie, że „to tylko MVP” zwalnia z obowiązków; brak oznaczenia, że użytkownik rozmawia z AI.

### Y03 · NIS2 i cyberbezpieczeństwo w UE
**Gdy:** klient z sektora kluczowego/ważnego (energia, transport, produkcja, zdrowie, cyfrowe), dostawca dla takiego klienta.
**Twarde:** NIS2 nakłada zarządzanie ryzykiem, zgłaszanie incydentów w krótkich terminach (wczesne ostrzeżenie w ciągu 24 h) i odpowiedzialność zarządu; bezpieczeństwo łańcucha dostaw oznacza, że klienci będą wymagać tego od dostawców; Cyber Resilience Act dotyczy produktów z elementami cyfrowymi (SBOM, obsługa podatności).
**Ekspert wie:** dla małego dostawcy realny skutek NIS2 to ankiety bezpieczeństwa od klientów — gotowy pakiet (polityki, SBOM, proces zgłaszania podatności, MFA, backup) skraca sprzedaż.
**Sprawdź:** czy masz proces: wykrycie → ocena → zgłoszenie w 24 h, przećwiczony.
**Nie:** brak kontaktu do zgłaszania podatności (`security.txt`); brak SBOM przy produkcie dla przemysłu.

### Y04 · Własność kodu, danych i wyników AI
**Gdy:** praca dla klienta, współpraca, kod generowany przez AI, dane treningowe.
**Twarde:** umowa określa, kto ma prawa do kodu (przeniesienie vs licencja) — bez niej domyślne reguły różnią się między krajami; komponenty wielokrotnego użytku wyłącz z przeniesienia jawnie; dane klienta tylko w celu z umowy; warunki dostawcy modelu określają prawa do wyników i użycie danych do treningu.
**Ekspert wie:** solo builder, który przenosi na klienta „wszystkie prawa do wszystkiego”, traci prawo do własnych bibliotek i szablonów użytych w projekcie.
**Sprawdź:** klauzula IP w umowie + lista komponentów wyłączonych.
**Nie:** praca bez umowy; wrzucanie danych klienta do narzędzi AI bez sprawdzenia warunków przetwarzania.
