# S · Sieci zaawansowane (LB, HTTP/3, BGP, mesh, IPv6)

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### S01 · Load balancing
**Gdy:** wiele instancji, nierówne obciążenie, sticky sessions.
**Twarde:** L4 (TCP/UDP, szybki, nie widzi HTTP) vs L7 (routing po ścieżce/nagłówku, TLS termination, retry); algorytm: least-connections albo power-of-two-choices bije round-robin przy nierównych żądaniach; health checki rozróżniają liveness od gotowości; drenaż połączeń przy wyłączaniu instancji.
**Ekspert wie:** długie połączenia (WebSocket, gRPC, HTTP/2) psują równoważenie — nowe instancje nie dostają ruchu, dopóki klienci się nie połączą ponownie; potrzebny okresowy reconnect albo balansowanie per żądanie.
**Sprawdź:** rozkład żądań i połączeń per instancja po skalowaniu w górę.
**Nie:** sticky sessions zamiast stanu na zewnątrz; health check sprawdzający zależności zewnętrzne.

### S02 · HTTP/2, HTTP/3, QUIC
**Gdy:** wydajność sieciowa, mobile, streaming.
**Twarde:** HTTP/2 multipleksuje na jednym TCP — utrata pakietu blokuje wszystkie strumienie (head-of-line na TCP); HTTP/3 na QUIC (UDP) to rozwiązuje i przyspiesza nawiązanie połączenia; w sieciach korporacyjnych UDP bywa blokowane — fallback konieczny; server push jest martwy, preload i 103 Early Hints żyją.
**Ekspert wie:** zysk z HTTP/3 jest duży na sieciach mobilnych ze stratami i znikomy na stabilnym łączu w centrum danych.
**Sprawdź:** `curl --http3 -I $URL`; porównanie TTFB z throttlingiem i utratą pakietów.
**Nie:** domain sharding przy HTTP/2 (szkodzi); zakładanie, że HTTP/3 przejdzie przez każdą zaporę.

### S03 · Routing i BGP
**Gdy:** własne IP, anycast, multi-homing, „internet nie widzi naszej sieci”.
**Twarde:** BGP to zaufanie między operatorami — ogłoszenia filtruj (prefix lists, max-prefix), podpisuj RPKI (ROA); anycast daje bliskość i odporność na DDoS, ale utrudnia stanowe połączenia; zmiana trasy propaguje się minutami.
**Ekspert wie:** duże awarie internetu to zwykle błędne ogłoszenie BGP albo wycofanie tras (w tym własnych adresów DNS) — procedura zmiany wymaga przeglądu i ścieżki powrotu niezależnej od zmienianej sieci.
**Sprawdź:** looking glass / `bgp.tools` dla prefiksu + walidacja RPKI.
**Nie:** zmiany BGP bez dostępu out-of-band; brak filtrów na sesjach z klientami.

### S05 · Service mesh
**Gdy:** mTLS między usługami, polityki ruchu, obserwowalność sieci.
**Twarde:** mesh (Istio, Linkerd, Cilium) daje mTLS, retry, timeouty i telemetrię bez zmian w kodzie — kosztem złożoności, latencji i zasobów; opłaca się przy dziesiątkach usług i wymaganiu mTLS, nie przy pięciu; retry w meshu plus retry w kodzie = mnożenie ruchu.
**Ekspert wie:** awaria control plane meshu nie powinna zatrzymać ruchu — sprawdź, jak zachowują się sidecary bez niego, zanim zdarzy się to na produkcji.
**Sprawdź:** narzut latencji p99 z meshem i bez + test z wyłączonym control plane.
**Nie:** mesh dla małego systemu; polityki retry w dwóch warstwach.

### S06 · IPv6
**Gdy:** nowe sieci, mobile, koszty IPv4, „nie działa u części użytkowników”.
**Twarde:** dual-stack jako standard; adresy IPv4 kosztują w chmurze (publiczne IP płatne) — IPv6 często obniża rachunek; limity i blokady po IP muszą rozumieć prefiksy /64 (jeden klient ma ich miliony adresów); zapory i security groups osobno dla v6.
**Ekspert wie:** „aplikacja nie działa u niektórych” bywa zepsutym IPv6 (AAAA wskazuje na nieobsługiwany endpoint) — przeglądarka próbuje v6 pierwsza.
**Sprawdź:** `curl -6 -I $URL` i `dig AAAA domena`.
**Nie:** rate limiting po pełnym adresie IPv6; rekord AAAA bez obsługi v6 na serwerze.
