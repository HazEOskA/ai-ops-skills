# W · Metody formalne

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### W01 · Kiedy metody formalne
**Gdy:** protokół rozproszony, kontrakt z pieniędzmi, kryptografia, logika uprawnień, systemy krytyczne.
**Twarde:** metody formalne opłacają się tam, gdzie błąd jest drogi, a przestrzeń stanów za duża na testy; drabina kosztu: typy → asercje i kontrakty → property-based → model checking (TLA+, Alloy) → dowód (Coq, Lean, Dafny); modeluj projekt, nie cały kod.
**Ekspert wie:** największy zysk z TLA+ przychodzi przed napisaniem kodu — model protokołu z 200 linii znajduje błędy współbieżności, których testy nie znajdą nigdy.
**Sprawdź:** czy niezmienniki systemu są spisane jako zdania „zawsze prawda, że…”.
**Nie:** formalizacja CRUD-a; dowód poprawności kodu, którego specyfikacja jest nieustalona.

### W04 · Model checking i TLA+
**Gdy:** projekt protokołu, konsensus, przepływ z wieloma aktorami, workflow z retry.
**Twarde:** modeluj stany i przejścia, nie kod; sprawdzaj bezpieczeństwo (nic złego się nie dzieje) i żywotność (coś dobrego w końcu się dzieje); małe konfiguracje (2–3 procesy, 2–3 wiadomości) znajdują większość błędów; model wersjonowany obok kodu.
**Ekspert wie:** błędy znajdowane przez TLC to zwykle ścieżki 20–40 kroków — żaden człowiek nie wymyśli ich jako przypadku testowego.
**Sprawdź:** TLC bez naruszeń niezmienników + ślad naruszenia, gdy wprowadzisz znany błąd (dowód, że model coś sprawdza).
**Nie:** model tak szczegółowy, że eksploduje przestrzeń stanów; model nieaktualizowany po zmianie projektu.
