# Q · Systemy operacyjne (pamięć wirtualna, dyski)

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### Q03 · Pamięć wirtualna
**Gdy:** OOM, swap, „pamięć rośnie”, limity kontenerów.
**Twarde:** RSS ≠ zużycie „prawdziwe” (pamięć współdzielona, page cache); page cache wypełnia wolny RAM celowo i oddaje go na żądanie; OOM killer wybiera po `oom_score`; limity cgroup liczą też page cache procesu — kontener może dostać OOM przy „małym” heapie; overcommit pozwala alokować więcej niż jest.
**Ekspert wie:** JVM/Node/Go widzą limit kontenera tylko w nowszych wersjach i tylko gdy odczytują cgroup — starsze runtime'y ustawiają heap od pamięci hosta i dostają OOMKilled.
**Sprawdź:** `cat /sys/fs/cgroup/memory.max`, `memory.stat` (anon vs file), `smem` albo `/proc/<pid>/smaps_rollup`.
**Nie:** wyłączanie swapu i OOM killera „dla stabilności”; heap ustawiony na 100% limitu kontenera.

### Q06 · System plików i dyski
**Gdy:** utrata danych po awarii, wolny zapis, pełny dysk.
**Twarde:** `write()` nie znaczy trwałe — trwałość to `fsync` pliku i katalogu; atomowa podmiana pliku = zapis do tymczasowego + fsync + `rename`; alert na zapełnienie dysku przy 80%, bo przy 100% padają logi, bazy i sam alerting; inody kończą się niezależnie od miejsca.
**Ekspert wie:** pełny dysk najczęściej robią logi bez rotacji albo usunięte pliki trzymane otwarte przez proces (`lsof +L1`) — `df` pokazuje pełny, `du` nie widzi.
**Sprawdź:** `df -h; df -i; lsof +L1 | head`.
**Nie:** zapis konfiguracji przez nadpisanie pliku w miejscu; brak rotacji logów.
