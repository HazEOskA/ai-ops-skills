# N · Systemy niskopoziomowe (pamięć, wątki, I/O, embedded, protokoły)

Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).

### N01 · Pamięć
**Gdy:** wyciek, OOM, fragmentacja, Rust/C/C++.
**Twarde:** własność i czas życia zdefiniowane zanim napiszesz kod; alokacja w gorącej pętli to najczęstsza przyczyna nierównej wydajności — pule i bufory wielokrotnego użytku; wzrost pamięci bywa cache'em, nie wyciekiem — sprawdź, czy się stabilizuje; fragmentacja wygląda jak wyciek, ale nią nie jest; mierz RSS i sterty osobno.
**Ekspert wie:** Wzrost RSS bywa fragmentacją alokatora lub cache’em, nie wyciekiem — porównaj stertę logiczną (użytą) z RSS. Wyciek pokazuje się jako monotoniczny wzrost przy stałym obciążeniu i mierzysz go różnicą profili sterty w czasie.
**Sprawdź:** `valgrind --leak-check=full`, sanitizer adresów, wykres RSS w czasie przy stałym obciążeniu.
**Nie:** wniosek o wycieku po pięciu minutach obserwacji; ręczne zarządzanie tam, gdzie wystarczy RAII/ownership; optymalizacja alokacji bez profilu.

### N02 · Współbieżność niskopoziomowa
**Gdy:** wątki, blokady, atomiki, deadlock.
**Twarde:** współdzielony stan minimalizuj, zanim zaczniesz go chronić; jedna globalna kolejność zakładania blokad; sekcja krytyczna jak najkrótsza, bez I/O; atomiki wymagają rozumienia modelu pamięci — domyślnie sekwencyjna spójność, luźniejsze porządki tylko z dowodem potrzeby; kanały i przekazywanie własności zamiast współdzielonej pamięci, gdy język to umożliwia.
**Ekspert wie:** Data race to nie tylko uszkodzone dane — w językach z modelem pamięci to niezdefiniowane zachowanie. Kompilator i CPU przestawiają operacje, więc test przechodzący na x86 (silniejszy model pamięci) może padać na ARM.
**Sprawdź:** sanitizer wątków, test obciążeniowy z losowymi opóźnieniami, wykrywanie deadlocków w CI.
**Nie:** `volatile` jako synchronizacja; blokada trzymana przez wywołanie zewnętrzne; własna implementacja lock-free bez formalnego uzasadnienia.

### N03 · I/O i sieć
**Gdy:** gniazda, bufory, wydajność transmisji.
**Twarde:** TCP to strumień, nie wiadomości — potrzebujesz ramkowania; częściowy zapis i odczyt to norma, obsłuż je; timeouty na każdej operacji; wykrywanie zerwanego połączenia wymaga keepalive albo warstwy aplikacyjnej, bo zerwane TCP potrafi wisieć długo; rozmiar bufora dopasowany do przepustowości i opóźnienia, nie do gustu.
**Ekspert wie:** Backpressure jest obowiązkowy: producent szybszy niż konsument bez limitu bufora kończy w OOM. `epoll` i `io_uring` obsługują wiele połączeń, ale jedno blokujące wywołanie w pętli zdarzeń zatrzymuje wszystkie.
**Sprawdź:** `ss -tin`, `tcpdump` na krótkim oknie, test przy sztucznym opóźnieniu i utracie pakietów (`tc netem`).
**Nie:** założenie, że jeden `send` to jedna wiadomość; brak timeoutu na odczyt; ignorowanie zwróconej liczby zapisanych bajtów.

### N05 · Embedded
**Gdy:** mikrokontroler, ograniczone zasoby, sprzęt.
**Twarde:** brak alokacji dynamicznej w czasie działania — wszystko statycznie, rozmiary znane przy kompilacji; przerwania krótkie, ciężka praca poza nimi, dane dzielone z przerwaniem oznaczone i chronione; watchdog skonfigurowany i realnie karmiony we właściwym miejscu; budżet energetyczny to wymóg projektowy; aktualizacja oprogramowania z możliwością wycofania na urządzeniu, do którego nie masz fizycznego dostępu.
**Ekspert wie:** Stos w embedded ma stały rozmiar, a jego przepełnienie to ciche uszkodzenie pamięci, nie wyjątek — zmierz zużycie w najgorszym przypadku (wypełnienie wzorcem i sprawdzenie). Watchdog karmiony z przerwania maskuje zawieszenie głównej pętli.
**Sprawdź:** zużycie stosu w najgorszym przypadku, test watchdoga, pomiar poboru prądu w każdym trybie.
**Nie:** `malloc` w pętli głównej; długa praca w obsłudze przerwania; aktualizacja bez obrazu zapasowego.

### N06 · Protokoły binarne
**Gdy:** własny format, serializacja, wymiana danych.
**Twarde:** wersja w nagłówku od pierwszej wersji; kolejność bajtów ustalona jawnie; długość przed danymi i sprawdzana przed alokacją (inaczej masz podatność); pola opcjonalne zaprojektowane od początku, bo dokładanie ich później łamie kompatybilność; wybieraj istniejący format (protobuf, CBOR) zamiast własnego, chyba że masz twardy powód.
**Ekspert wie:** Kompatybilność wsteczna wymaga numerów pól i reguł ignorowania nieznanych (jak w protobuf), nie pozycji w strukturze. Długość z wejścia sprawdzaj względem limitu przed alokacją — to klasyczna droga do DoS i przepełnień.
**Sprawdź:** test parsowania celowo uszkodzonych i skrajnych danych (fuzzing).
**Nie:** alokacja bufora według długości podanej w danych wejściowych bez limitu; format bez wersji; własny protokół „bo prostszy".
