#!/usr/bin/env python3
"""Uruchamia komendę i drukuje blok dowodowy. Exit = exit komendy (124 przy timeout).

Użycie: python3 verify.py --label "opis" [--timeout 300] [--log evidence.jsonl] -- komenda arg ...
"""
import argparse, json, subprocess, sys, time, datetime


def main():
    if "--" not in sys.argv:
        print("Użycie: verify.py --label OPIS [--timeout S] [--log PLIK] -- komenda ...", file=sys.stderr)
        sys.exit(2)
    i = sys.argv.index("--")
    ap = argparse.ArgumentParser()
    ap.add_argument("--label", required=True)
    ap.add_argument("--timeout", type=int, default=300)
    ap.add_argument("--log", default="evidence.jsonl")
    a = ap.parse_args(sys.argv[1:i])
    cmd = sys.argv[i + 1:]
    if not cmd:
        print("BŁĄD: brak komendy po --", file=sys.stderr)
        sys.exit(2)
    t0 = time.time()
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=a.timeout)
        code, out = r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired as e:
        code, out = 124, f"TIMEOUT po {a.timeout}s\n" + str(e.stdout or "")[-500:]
    except FileNotFoundError as e:
        code, out = 127, f"nie znaleziono komendy: {e}"
    dt = round(time.time() - t0, 2)
    level = "MECHANICALLY_VERIFIED" if code == 0 else "FAILED"
    tail = "\n".join(out.strip().splitlines()[-15:])
    print("--- DOWÓD ---")
    print(f"etykieta: {a.label}")
    print(f"komenda:  {' '.join(cmd)}")
    print(f"exit:     {code}   czas: {dt}s")
    print(f"poziom:   {level}")
    print("ogon wyjścia:")
    print(tail if tail else "(puste)")
    print("--- KONIEC DOWODU ---")
    rec = {"ts": datetime.datetime.now().isoformat(timespec="seconds"), "label": a.label,
           "cmd": cmd, "exit": code, "seconds": dt, "level": level, "tail": tail[-1500:]}
    with open(a.log, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    sys.exit(code)


if __name__ == "__main__":
    main()
