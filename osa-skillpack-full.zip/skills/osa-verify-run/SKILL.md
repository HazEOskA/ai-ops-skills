---
name: "osa-verify-run"
description: "Uruchomienie z dowodem: komenda, exit code, wynik i poziom na drabinie dowodów zapisane jako blok dowodowy. Użyj zawsze, gdy chcesz napisać, że coś działa, przechodzi albo jest naprawione. Triggers: verify, prove, run tests, exit code, evidence, sprawdź, udowodnij."
---

# Uruchomienie z dowodem

Zasada: nie ma dowodu z uruchomienia, nie ma „działa”. Pisz `nieuruchomione`.

## Procedura

1. Zdecyduj, **jaka komenda** udowodni każdy czasownik rdzenia (`osa-build-gate`). Realne wejście użytkownika, nie sztuczny przykład.
2. Uruchom przez opakowanie, które zapisuje dowód:
   `python3 scripts/verify.py --label "testy jednostkowe" -- <komenda> <argumenty>`
   Opcje: `--timeout 300`, `--log evidence.jsonl` (domyślnie dopisuje rekord JSON).
3. Wklej do odpowiedzi blok, który skrypt drukuje (komenda, exit, czas, ogon wyjścia, poziom).
4. Poziomy:
   - exit 0 → `MECHANICALLY_VERIFIED`
   - exit ≠ 0 → `FAILED` (napraw, nie raportuj „prawie”)
   - `INDEPENDENTLY_VERIFIED` tylko po uruchomieniu w czystym środowisku (świeży klon, kontener, CI). Skrypt tego nie nadaje: dopisz ręcznie z artefaktem.
5. Puste testy (0 testów uruchomionych) to nie dowód. Sprawdź w ogonie wyjścia, że testy faktycznie się wykonały.

## Ograniczenia (uczciwie)

- exit 0 dowodzi tylko tego, co komenda sprawdza. Słaby test daje słaby dowód.
- Skrypt nie ocenia jakości komendy. To Twoja odpowiedzialność (`osa-test-strategy`).
