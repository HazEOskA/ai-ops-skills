# Karty: osa-rag

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### G04 · RAG
**Gdy:** pytania do dokumentów, „model nie zna naszych danych".
**Twarde:** przy małym stabilnym korpusie wklej dokumenty zamiast budować RAG; jakość zaczyna się przy parsowaniu — źle sparsowany PDF sabotuje wszystko dalej; chunking po strukturze, nie po liczbie znaków; wyszukiwanie hybrydowe (BM25 + wektory), bo same wektory gubią nazwy własne i kody; rerank to najtańsza duża wygrana; uprawnienia filtruj przed wyszukiwaniem; cytowania z identyfikatorem fragmentu.
**Ekspert wie:** Najczęstszą przyczyną złych odpowiedzi jest złe wyszukanie, nie zły model — mierz recall@k osobno. Przy tabelach, kodzie i dokumentach z nagłówkami chunking po strukturze wygrywa z oknem o stałej długości.
**Sprawdź:** recall@k mierzone osobno od jakości odpowiedzi, na zestawie z oczekiwanymi źródłami.
**Nie:** ocena „popatrzyliśmy na kilka odpowiedzi"; filtrowanie uprawnień po wyszukiwaniu; brak zdefiniowanego zachowania przy braku trafienia.

### G05 · Embeddingi i baza wektorowa
**Gdy:** podobieństwo, wyszukiwanie semantyczne, deduplikacja.
**Twarde:** wektory z różnych modeli są nieporównywalne — zmiana modelu to pełna reindeksacja, zaplanuj ją; normalizacja i miara podobieństwa muszą być spójne w indeksie i zapytaniu; `pgvector` wystarcza do milionów wektorów, osobna baza to osobny system do utrzymania; metadane do filtrowania w indeksie, nie po fakcie.
**Ekspert wie:** Zmiana modelu embeddingów to pełna reindeksacja i często zmiana wymiaru. Indeks przybliżony (HNSW) ma parametry (`ef_search`) wymieniające recall na czas — mierz recall względem wyszukiwania dokładnego, nie zakładaj.
**Sprawdź:** czas zapytania i recall przy docelowym wolumenie, nie na tysiącu wektorów.
**Nie:** osobna baza wektorowa przy 50 tys. dokumentów; mieszanie wektorów z dwóch modeli w jednym indeksie; brak planu reindeksacji.

### B15 · Wyszukiwanie w aplikacji
**Gdy:** szukajka, filtrowanie, podpowiedzi.
**Twarde:** zacznij od możliwości bazy (Postgres full-text + trigram) zanim postawisz Elasticsearch; osobny silnik to osobne źródło prawdy i osobny problem synchronizacji; indeksuj przez outbox, nie przez podwójny zapis; zdefiniuj zachowanie przy zerze wyników.
**Ekspert wie:** Największym kosztem osobnego silnika wyszukiwania jest synchronizacja i jej awarie (indeks po cichu zostaje w tyle). Postgres z `tsvector` + GIN i `pg_trgm` wystarcza do setek tysięcy rekordów i ma zaletę: zapytanie i filtr uprawnień działają w jednej transakcji.
**Sprawdź:** czas odpowiedzi przy realnym wolumenie i rozjazd indeksu vs baza po 24 h.
**Nie:** Elasticsearch dla 50 tys. rekordów; podwójny zapis do bazy i indeksu w jednej transakcji aplikacyjnej; brak monitoringu opóźnienia indeksowania.
