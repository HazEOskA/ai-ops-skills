---
name: "osa-rag"
description: "Systemy RAG i wyszukiwanie: chunkowanie, embeddingi, wyszukiwanie hybrydowe, reranking, cytowanie, ewaluacja retrieval osobno od generacji. Użyj przy budowie RAG, bazy wiedzy, wyszukiwarki semantycznej. Triggers: RAG, retrieval, embeddings, vector search, chunking, rerank, knowledge base, wyszukiwanie."
---

# RAG

## Procedura

1. **Zacznij od pytań użytkownika**: zbierz realne pytania i oczekiwane fragmenty źródeł. To zestaw ewaluacyjny (`osa-evals`).
2. **Oceń retrieval osobno od generacji**: recall@k (czy właściwy fragment jest w top-k) przed jakością odpowiedzi. Zły retrieval = zła odpowiedź, którą prompt nie naprawi.
3. **Chunkowanie** według struktury dokumentu (nagłówki, sekcje), z zachowaniem kontekstu (tytuł, ścieżka). Rozmiar dobierz pomiarem na własnych danych.
4. **Wyszukiwanie hybrydowe** (słowa kluczowe + wektory) zwykle bije samo wektorowe dla kodu, identyfikatorów i nazw: sprawdź na swoim zestawie. Rerank przed generacją, jeśli recall wysoki, a precyzja niska.
5. **Cytowanie**: odpowiedź wskazuje źródło (dokument, fragment). Brak dopasowania: „nie wiem / brak w źródłach”, nie wymyślona odpowiedź.
6. **Świeżość i uprawnienia**: reindeksacja przy zmianie źródła; filtrowanie po uprawnieniach użytkownika w zapytaniu, nie po fakcie (`osa-authz-multitenancy`).
7. **Wstrzyknięcie z dokumentów**: treść źródeł jest niezaufana (`osa-ai-guardrails-sandbox`).
8. Koszt i opóźnienie: pomiar, nie założenie (`osa-llm-system-design`).

## Nie

- Zakładania, że większy kontekst zastępuje retrieval.
- Wyboru bazy wektorowej przed pomiarem, czy wystarczy Postgres z rozszerzeniem lub indeks pełnotekstowy (`osa-postgres-data`).
- Oceny „na oko” na 5 pytaniach.

## Karty (references/cards.md)

- **G04** · RAG — gdy: pytania do dokumentów, „model nie zna naszych danych"
- **G05** · Embeddingi i baza wektorowa — gdy: podobieństwo, wyszukiwanie semantyczne, deduplikacja
- **B15** · Wyszukiwanie w aplikacji — gdy: szukajka, filtrowanie, podpowiedzi

Wczytaj tylko karty pasujące do zadania (grep po ID).
