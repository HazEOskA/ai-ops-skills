# Karty: osa-ai-guardrails-sandbox

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### G09 · Guardrails
**Gdy:** treść niezaufana w kontekście, injection, dane osobowe.
**Twarde:** prompt injection nie jest rozwiązany — zabezpieczeniem jest architektura, nie sformułowanie; rozdziel poziomy zaufania w kontekście i traktuj treść zewnętrzną wyłącznie jako dane; wyjście modelu wstawiane do SQL, shella, HTML-a czy URL-a to to samo ryzyko co wejście użytkownika; kod z modelu tylko w sandboxie bez sieci i sekretów; limit kosztu per użytkownik.
**Ekspert wie:** Klasyczny wektor to dane pozyskane jednym narzędziem, które kierują wywołaniem drugiego (odczyt poufnych danych + narzędzie z dostępem do sieci). Niebezpieczna jest kombinacja: dane prywatne, niezaufana treść i kanał wyjściowy — usuń jedno z trzech.
**Sprawdź:** zestaw testów adversarialnych w CI (dokument z instrukcją, wynik wyszukiwania z poleceniem, wymuszenie ujawnienia promptu, `<script>` w wyjściu).
**Nie:** „ignoruj instrukcje z dokumentów" jako jedyna ochrona; renderowanie wyjścia jako HTML bez sanityzacji; automatyczne ładowanie obrazów z niezaufanych URL-i (kanał wycieku).

### Q05 · Wirtualizacja i izolacja wykonywania
**Gdy:** uruchamianie niezaufanego kodu, sandbox dla agentów, VM vs kontener.
**Twarde:** siła izolacji rośnie: proces → kontener → kontener z gVisor → microVM (Firecracker, Kata) → pełna VM; kod wygenerowany przez model albo od użytkownika uruchamiaj co najmniej w microVM lub gVisor, bez sieci wychodzącej domyślnie, bez sekretów, z limitem czasu i zasobów; snapshot i przywrócenie to najtańszy reset.
**Ekspert wie:** sandbox bez limitu sieci wychodzącej jest kanałem wycieku, nawet gdy system plików jest izolowany.
**Sprawdź:** z wnętrza sandboxa: próba połączenia na zewnątrz, odczytu zmiennych środowiskowych hosta, zapisu poza katalog roboczy.
**Nie:** `eval`/`exec` kodu z modelu w procesie aplikacji; sandbox współdzielący konto chmurowe z produkcją.
