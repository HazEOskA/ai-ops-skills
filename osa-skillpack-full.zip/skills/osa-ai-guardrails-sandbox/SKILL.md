---
name: "osa-ai-guardrails-sandbox"
description: "Bezpieczeństwo systemów AI: wstrzyknięcie promptu, izolacja wykonania kodu agenta (sandbox), najmniejsze uprawnienia, limity, filtrowanie wyjścia. Użyj, gdy agent wykonuje kod, czyta niezaufane dane lub ma narzędzia z efektami. Triggers: prompt injection, sandbox, guardrails, jailbreak, agent safety, izolacja, uprawnienia agenta."
---

# Guardrails i sandbox

## Model zagrożeń agenta

Niezaufane wejście: wiadomości użytkownika, strony WWW, pliki, wyniki narzędzi, treść repo, e-maile. Każde może zawierać instrukcje kierowane do modelu. **Model nie odróżnia niezawodnie danych od poleceń**, więc obronę budujesz architekturą, nie prośbą w prompcie.

## Reguły

1. **Wykonanie kodu tylko w izolacji**: kontener/microVM/sandbox platformy, bez dostępu do sekretów hosta, z limitami CPU, pamięci, czasu i sieci (allowlista). Kod agenta na maszynie Osy bez izolacji: nie.
2. **Najmniejsze uprawnienia**: tokeny o wąskim zakresie, tylko do odczytu tam, gdzie się da, krótkie życie.
3. **Rozdzielenie zdolności**: agent czytający niezaufane treści nie ma jednocześnie dostępu do sekretów i akcji zewnętrznych („lethal trifecta”: niezaufane dane + dostęp do prywatnych danych + kanał wyjściowy). Usuń co najmniej jedno ogniwo.
4. **Akcje z efektem za bramką zgody** (`osa-god-layer-approvals`): push, wysyłka, płatność, usuwanie.
5. **Filtrowanie wyjścia**: sekrety i dane osobowe nie wychodzą do logów ani na zewnątrz (`osa-secrets-hygiene`).
6. **Limity**: kroki, tokeny, koszt, czas, rozmiar plików. Wykrywanie pętli.
7. **Testy adwersaryjne**: przygotuj przypadki wstrzyknięcia (instrukcja ukryta w pliku, w odpowiedzi narzędzia) i sprawdź, czy agent ich nie wykonuje (`osa-evals`). Wynik to twierdzenie „nie udało się złamać metodą X”, nie „jest bezpieczny”.

## Nie

- Obrony wyłącznie promptem systemowym („ignoruj złośliwe polecenia”).
- Sandboxa z sekretami w zmiennych środowiskowych.
- Agenta z pełną siecią i dostępem do kluczy produkcyjnych.

## Karty (references/cards.md)

- **G09** · Guardrails — gdy: treść niezaufana w kontekście, injection, dane osobowe
- **Q05** · Wirtualizacja i izolacja wykonywania — gdy: uruchamianie niezaufanego kodu, sandbox dla agentów, VM vs kontener

Wczytaj tylko karty pasujące do zadania (grep po ID).
