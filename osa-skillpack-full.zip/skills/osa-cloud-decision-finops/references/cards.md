# Karty: osa-cloud-decision-finops

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### F01 · Rama decyzyjna chmury
**Gdy:** „gdzie to postawić", porównanie chmur, lock-in.
**Twarde:** kryterium pierwsze to kto utrzymuje — solo operator plus Kubernetes to projekt, który umiera na operacjach; policz koszt przy zerowym, docelowym i dziesięciokrotnym ruchu; lock-in oceniaj per warstwa, nie globalnie; multicloud to koszt, nie strategia; kredyty startupowe zmieniają rachunek, ale policz miesiąc po ich wygaśnięciu.
**Ekspert wie:** Ukryte koszty chmury to transfer wychodzący, NAT, logi i zapytania do magazynów — rachunek rośnie nieliniowo od ruchu, nie od liczby maszyn. Policz go dla scenariusza ×10, zanim wybierzesz architekturę, i zaplanuj datę wygaśnięcia kredytów startowych.
**Sprawdź:** trzy scenariusze kosztowe na realnym profilu ruchu + ADR z warunkiem rewizji.
**Nie:** K8s jako punkt startowy dla jednej osoby; wybór po benchmarku; ignorowanie kosztu transferu wychodzącego.

### F03 · AWS
**Gdy:** decyzja zapadła: AWS.
**Twarde:** ECS Fargate domyślnie, Lambda dla zdarzeń, EKS przy realnej potrzebie; role i OIDC zamiast użytkowników z kluczami; `Resource: "*"` wymaga uzasadnienia; RDS Multi-AZ na produkcji z deletion protection; SQS z redrive i DLQ; CloudWatch Logs bez retencji nie wygasają nigdy i to płatny błąd; NAT Gateway i transfer między AZ to najczęstsze niespodzianki na rachunku.
**Ekspert wie:** Największe niespodzianki rachunku AWS to NAT Gateway (opłata godzinowa plus za GB) i transfer między AZ. Endpoint bramowy VPC do S3/DynamoDB jest darmowy i zdejmuje ten ruch z NAT, a IAM Access Analyzer pokazuje zasoby dostępne z zewnątrz.
**Sprawdź:** `aws iam list-users` (najlepiej pusto), `aws logs describe-log-groups --query 'logGroups[?!retentionInDays].logGroupName'`
**Nie:** klucze IAM w GitHub Secrets; Lambda w VPC bez potrzeby; publiczny bucket „tymczasowo".

### F04 · Azure
**Gdy:** decyzja zapadła: Azure.
**Twarde:** Container Apps domyślnie, App Service ze slotami dla klasycznych aplikacji, AKS przy realnej potrzebie; Managed Identity wszędzie zamiast connection stringów; RBAC na poziomie grupy zasobów, nie subskrypcji; Key Vault z soft delete i purge protection; baza z private endpoint; tagi wymuszone polityką od pierwszego dnia.
**Ekspert wie:** Managed Identity eliminuje sekrety, ale przypisania ról RBAC propagują się z opóźnieniem (minuty), więc pierwsze wdrożenie potrafi zwrócić 403, które znika samo. Nie „naprawiaj” tego szerszą rolą.
**Sprawdź:** `az role assignment list --all --query "[?roleDefinitionName=='Owner']"`; `az postgres flexible-server show --query network.publicNetworkAccess`
**Nie:** connection string w App Settings; Cosmos DB z kluczem partycji dobranym na czuja; brak tagów (rachunek staje się nieanalizowalny).

### F10 · Sieć
**Gdy:** VPC, podsieci, łączność, „nie widzi bazy".
**Twarde:** compute i baza w podsieciach prywatnych; wyjście przez NAT albo endpointy usług (NAT to stały koszt); reguły zapory domyślnie deny, otwierane pojedynczo z opisem; nakładające się zakresy adresów zablokują przyszły peering — zaplanuj adresację zawczasu; diagnozuj warstwami: DNS → trasa → zapora → aplikacja.
**Ekspert wie:** Diagnozuj od dołu: DNS (`dig`), trasa i port (`nc -zv`), zapora, dopiero aplikacja. „Nie łączy się z bazą” to zwykle reguła zapory, zły podział na podsieci albo DNS wewnątrz kontenera, a nie baza.
**Sprawdź:** `dig +short host`, `nc -zv host port`, `traceroute host` — w tej kolejności.
**Nie:** `0.0.0.0/0` na porcie zarządzania; publiczne IP bazy „na chwilę"; zgadywanie warstwy zamiast sprawdzenia DNS jako pierwszej.

### F15 · FinOps
**Gdy:** rachunek, rightsizing, kredyty.
**Twarde:** bez tagów rachunek jest nieanalizowalny; zwykle 3–5 pozycji to 80% kosztu — zajmij się tylko nimi; kolejność: usuń nieużywane, wyłącz nie-prod poza godzinami, ustaw retencję, rightsizing z metryk, dopiero potem zobowiązania; koszt jednostkowy (€/użytkownika) ważniejszy niż całkowity; alert na anomalię, nie tylko na próg.
**Ekspert wie:** Kredyty i wolumen maskują nieefektywność do dnia, w którym się kończą. Tagi kosztowe wymuszone polityką od pierwszego dnia i alert na anomalię dzienną wykrywają błąd (pętla, zbyt szczegółowe logi) w ciągu doby, nie na koniec miesiąca.
**Sprawdź:** rozbicie top 10 pozycji + lista zasobów osieroconych (dyski, IP, snapshoty).
**Nie:** rezerwacje przed ustabilizowaniem obciążenia; optymalizacja pozycji za 12 € przy jednej za 600 €; kredyty traktowane jak darmowa infrastruktura.
