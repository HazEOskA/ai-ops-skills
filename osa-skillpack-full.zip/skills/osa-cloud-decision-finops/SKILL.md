---
name: "osa-cloud-decision-finops"
description: "Wybór chmury i runtime'u oraz koszty (FinOps): dopasowanie do czasowników rdzenia, koszt jako liczba z cennika, budżety i alerty, lock-in. Użyj przy wyborze platformy, szacowaniu kosztu, optymalizacji rachunku. Triggers: cloud, AWS, GCP, Azure, cost, pricing, FinOps, budget, runtime choice, koszt chmury."
---

# Wybór chmury i koszty

## Procedura

1. **Rdzeń najpierw** (`osa-build-gate`): platforma musi umieć wykonać każdy czasownik rdzenia (np. długie zadania, trwały stan, GPU, uruchamianie testów). Platforma, która tego nie umie, odpada, choćby była tania.
2. **Inwentarz**: konta, kredyty i narzędzia, które Osa już ma. Domyślnie zostań tam, gdzie jest, chyba że rdzeń tego zabrania.
3. **Solo builder**: preferuj usługi zarządzane i skalowanie do zera nad własnymi serwerami; własna administracja to Twój czas, a on jest najdroższy.
4. **Koszt jako liczba**: cennik sprawdź w oficjalnym źródle w dniu decyzji (WebFetch/WebSearch). Nie masz dostępu: `unknown`, nie zgaduj. Policz scenariusze: typowy, 10× ruchu, najgorszy (pętla, atak, błąd).
5. **Zabezpieczenia kosztów**: budżet z alertami, limity na klucze API i funkcje, wygaszanie środowisk testowych. Płatny zasób = zgoda (`osa-god-layer-approvals`).
6. **Lock-in**: nazwij go i wyceń wyjście (dane, formaty, API). Odwracalne decyzje szybko, nieodwracalne wolno (`osa-architecture-lock`).
7. **Wynik**: rekomendacja jednej opcji z liczbą i warunkiem rewizji, nie porównanie 6 chmur.

## Nie

- Multi-cloud „na wszelki wypadek”.
- Klastra Kubernetes dla jednej aplikacji bez liczby, która to uzasadnia.
- Cen z pamięci.

## Karty (references/cards.md)

- **F01** · Rama decyzyjna chmury — gdy: „gdzie to postawić", porównanie chmur, lock-in
- **F03** · AWS — gdy: decyzja zapadła: AWS
- **F04** · Azure — gdy: decyzja zapadła: Azure
- **F10** · Sieć — gdy: VPC, podsieci, łączność, „nie widzi bazy"
- **F15** · FinOps — gdy: rachunek, rightsizing, kredyty

Wczytaj tylko karty pasujące do zadania (grep po ID).
