---
name: "osa-mvp-solo-builder"
description: "Produkt i MVP dla solo buildera: cięcie zakresu, specyfikacja, cennik, analityka, wzrost, decyzje produktowe, kolejność pracy jednej osoby. Użyj przy pomyśle na produkt, planie MVP, cenniku, priorytetach. Triggers: MVP, product, scope cut, pricing, roadmap, launch, growth, solo founder, zakres MVP, cennik."
---

# MVP i solo builder

## Procedura

1. **Problem i użytkownik**: kto ma ten problem, jak go dziś rozwiązuje, ile go to kosztuje. Nie wiesz: zapytaj Osę lub oznacz `unknown`. Nie wymyślaj rynku.
2. **Rdzeń MVP = czasowniki** (`osa-build-gate`): co najmniejsza wersja musi *robić*, żeby dać wartość. Reszta to lista „później”.
3. **Cięcie zakresu**: każdą funkcję sprawdź pytaniem „czy bez tego wartość zniknie?”. Obcięcie rdzenia to decyzja Osy i musi być nazwane obcięciem (`osa-build-gate`).
4. **Kolejność solo**: najpierw ścieżka od wejścia do wartości end-to-end (cienka, brzydka, działająca), potem szlif. Wdrażaj wcześnie i często (`osa-deploy-validation`).
5. **Technologia**: najmniej ruchomych części (`osa-architecture-lock`). Własny czas jest najdroższym zasobem.
6. **Specyfikacja**: jedna strona: problem, rdzeń, kryteria akceptacji mierzalne, poza zakresem.
7. **Cennik i wzrost**: hipotezy do zbadania z liczbą (cena, konwersja), nie „to na pewno zadziała”. Status twierdzeń: `osa-proof-governance`.
8. **Analityka**: tylko metryki, które zmienią decyzję. Prywatność użytkowników (`osa-domain-library`, Y).
9. **Koniec**: kryterium sukcesu i warunek pivotu/zamknięcia zapisane z góry.

## Nie

- Budowy funkcji „na zapas”.
- Prognoz rynku, cen konkurencji i statystyk z pamięci: sprawdź w źródle albo `unknown`.
- Doskonalenia infrastruktury przed pierwszym użytkownikiem.

## Karty (references/cards.md)

- **M01** · Zakres MVP — gdy: nowy produkt, „co zbudować najpierw"
- **M02** · Specyfikacja — gdy: opis funkcji przed budową
- **M03** · Walidacja pomysłu — gdy: przed zbudowaniem
- **M04** · Analityka produktowa — gdy: mierzenie użycia
- **M05** · Cennik — gdy: ustalanie ceny
- **M07** · Wybór walk — gdy: za dużo pomysłów, rozproszenie
- **M08** · Praca solo — gdy: jedna osoba utrzymuje wszystko

Wczytaj tylko karty pasujące do zadania (grep po ID).
