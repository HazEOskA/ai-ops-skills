# Karty: osa-mvp-solo-builder

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### M01 · Zakres MVP
**Gdy:** nowy produkt, „co zbudować najpierw".
**Twarde:** MVP ma zweryfikować jedno założenie, nie dostarczyć małą wersję wszystkiego; nazwij hipotezę i sposób jej falsyfikacji zanim zaczniesz kodować; ręczna obsługa w tle jest legalnym pierwszym wdrożeniem automatu; jeśli nie umiesz powiedzieć, co unieważni pomysł, nie budujesz MVP tylko prototyp na własne życzenie.
**Ekspert wie:** MVP odpowiada na jedno pytanie: „czy ktoś tego chce, zanim zbuduję resztę”. Jeśli nie umiesz napisać, jaki wynik cię przekona, że nie, budujesz produkt, nie eksperyment; ręczny proces za interfejsem jest uczciwym MVP.
**Sprawdź:** jedno zdanie: „jeśli po X tygodniach nie zobaczę Y, rezygnuję".
**Nie:** panel administracyjny przed pierwszym użytkownikiem; system płatności przed potwierdzeniem, że ktoś chce płacić; skalowanie przed ruchem.

### M02 · Specyfikacja
**Gdy:** opis funkcji przed budową.
**Twarde:** zacznij od problemu i tego, co się nie zmieni, gdy zmieni się rozwiązanie; wypisz co jest poza zakresem — to najcenniejsza część dokumentu; kryteria akceptacji sprawdzalne z zewnątrz; przypadki brzegowe i stany błędne opisane, bo one zajmują większość czasu implementacji.
**Ekspert wie:** Sekcja „poza zakresem” i przypadki błędne zajmują większość czasu implementacji i zwykle nie są opisane. Spec, z którego dwie osoby zbudowałyby różne rzeczy, jest niekompletny.
**Sprawdź:** czy ktoś inny zbudowałby to samo wyłącznie z tego dokumentu.
**Nie:** spec opisujący interfejs zamiast problemu; brak sekcji „poza zakresem"; kryteria typu „ma działać dobrze".

### M03 · Walidacja pomysłu
**Gdy:** przed zbudowaniem.
**Twarde:** deklaracja zainteresowania nie jest dowodem — dowodem jest czas, dane kontaktowe albo pieniądze; rozmawiaj o ich obecnym procesie i ostatnim przypadku problemu, nie o twoim pomyśle; pytania hipotetyczne dają odpowiedzi hipotetyczne; pięć rozmów pokazuje wzorzec, jedna pokazuje anegdotę.
**Ekspert wie:** Zainteresowanie deklaratywne jest tanie; wiarygodny sygnał to koszt poniesiony przez rozmówcę (czas, pieniądze, dostęp do danych, przedstawienie kogoś). Pytaj o ostatni raz, kiedy miał ten problem, i co wtedy zrobił.
**Sprawdź:** ile osób zrobiło coś kosztownego (zapisało się, zapłaciło, poświęciło godzinę) — nie ile powiedziało „fajne".
**Nie:** pytanie „czy użyłbyś"; walidacja wśród znajomych; budowa przed pierwszą rozmową.

### M04 · Analityka produktowa
**Gdy:** mierzenie użycia.
**Twarde:** zdefiniuj jedną metryką wiodącą i 3–5 wspierających, resztę ignoruj; zdarzenia nazwane według słownika ustalonego z góry, bo bałagan w nazwach jest nieodwracalny; mierz aktywację i utrzymanie przed pozyskaniem — dolewanie użytkowników do dziurawego wiadra to strata pieniędzy; kohorty zamiast sum narastających.
**Ekspert wie:** Retencja kohortowa mówi więcej niż suma użytkowników: jeśli krzywa spada do zera, akwizycja tylko zwiększa wydatek. Zdarzenie aktywacji definiuj jako moment, w którym użytkownik dostaje wartość, nie rejestrację.
**Sprawdź:** krzywa utrzymania per kohorta tygodniowa — czy się spłaszcza, czy schodzi do zera.
**Nie:** dashboard z 40 metrykami; liczby narastające jako miara sukcesu; śledzenie wszystkiego „na zapas" bez planu użycia.

### M05 · Cennik
**Gdy:** ustalanie ceny.
**Twarde:** wyceniaj wartość dla klienta, nie koszt wytworzenia ani czas; oś rozliczeniowa musi rosnąć razem z wartością, jaką klient dostaje; za tanio odcina lepszych klientów i utrudnia sprzedaż bardziej niż za drogo; darmowy plan to koszt operacyjny — musi mieć jasną funkcję; zmiana cennika wymaga zasad dla obecnych klientów ustalonych zawczasu.
**Ekspert wie:** Cena jest komunikatem o pozycji; obniżka niszczy pozycję trudniej niż podwyżka, a obecni klienci potrzebują z góry zdefiniowanych zasad (grandfathering). Plan darmowy z limitem kosztu i jasnym wyzwalaczem przejścia to lejek — bez tego to koszt.
**Sprawdź:** rozmowa z klientem o tym, ile kosztuje go dziś problem, który rozwiązujesz.
**Nie:** cena z kosztów plus marża; trzy plany różniące się liczbą, której klient nie rozumie; darmowy plan bez limitu kosztu.

### M07 · Wybór walk
**Gdy:** za dużo pomysłów, rozproszenie.
**Twarde:** policz, ile rzeczy jest naprawdę w toku — powyżej dwóch równoległych projektów tempo spada na wszystkich; skończone i wdrożone bije rozpoczęte i ciekawe; projekt bez odbiorcy to nauka, i to jest w porządku, ale nazwij to wprost, żeby nie mylić z pracą produktową; porzucenie jest decyzją, nie porażką — ale ma być świadome.
**Ekspert wie:** Liczba projektów w toku jest lepszym predyktorem niedokończenia niż ich trudność. Nazwij odbiorcę każdego projektu i datę ostatniego użytecznego przyrostu — projekt bez odbiorcy to nauka i wolno go tak nazwać.
**Sprawdź:** lista projektów z datą ostatniego commita i nazwanym odbiorcą.
**Nie:** dziesięć repozytoriów w toku; nowy projekt jako ucieczka od trudnego etapu obecnego; brak jawnej decyzji o porzuceniu.

### M08 · Praca solo
**Gdy:** jedna osoba utrzymuje wszystko.
**Twarde:** wybieraj technologie, które utrzymasz sam za pół roku, gdy zapomnisz szczegółów; automatyzuj to, co robisz trzeci raz, nie pierwszy; pisz decyzje, bo przyszły ty nie pamięta powodów; obserwowalność i rollback są ważniejsze niż przy zespole, bo nie ma kto ratować; ustaw twardy limit czasu na walkę z jednym problemem, potem obejście.
**Ekspert wie:** Solo operator płaci za każdy niezautomatyzowany krok i każdy wybór niezrozumiały za pół roku. Obserwowalność i rollback to jego zespół dyżurny, a spisana decyzja jest listem do przyszłego siebie.
**Sprawdź:** czy potrafisz wdrożyć i wycofać zmianę z telefonu w 10 minut.
**Nie:** stos technologiczny wymagający zespołu; brak zapisanych decyzji; ręczne wdrożenie z wieloma krokami.
