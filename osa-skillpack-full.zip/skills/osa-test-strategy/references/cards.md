# Karty: osa-test-strategy

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### I01 · Strategia testów
**Gdy:** co testować, flaky, „pokrycie 100%".
**Twarde:** testuj ryzyko, nie linie — pokrycie nie mówi nic; dużo szybkich jednostkowych na logikę, warstwa integracyjnych na granice, kilka E2E na krytyczne ścieżki; integracyjne na realnej bazie w kontenerze, nie na mocku; flake to defekt krytyczny, bo uczy ignorować czerwony build; każdy incydent zostawia test regresji.
**Ekspert wie:** Test integracyjny na prawdziwej bazie w kontenerze łapie klasy błędów, których mock nie zobaczy (constrainty, transakcje, migracje). Mutation testing pokazuje, czy testy w ogóle wykryją zmianę kodu — pokrycie liniowe tego nie mierzy.
**Sprawdź:** `pytest --durations=15`; `pytest -p no:randomly --count=20 test_x.py` na podejrzanym teście.
**Nie:** `sleep` jako synchronizacja; testy zależne od kolejności; `retry: 3` jako rozwiązanie docelowe.

### W02 · Property-based testing
**Gdy:** parsery, serializacja, algorytmy, logika biznesowa z regułami.
**Twarde:** zamiast przykładów — własności: odwracalność (decode(encode(x)) = x), niezmienniki (suma sald stała), porównanie z implementacją wzorcową, idempotencja; generator produkuje tysiące wejść, a framework zmniejsza porażkę do minimalnego przykładu; testy stanowe dla API (sekwencje operacji).
**Ekspert wie:** najtrudniejsza część to nazwanie własności — jeśli nie umiesz jej nazwać, nie rozumiesz jeszcze specyfikacji.
**Sprawdź:** `hypothesis` / `fast-check` / `proptest` z seedem zapisanym przy porażce.
**Nie:** własność, która przepisuje implementację; generatory pomijające przypadki brzegowe (puste, ogromne, Unicode).

### W03 · Fuzzing
**Gdy:** parser, protokół, deserializacja, kod przyjmujący niezaufane dane, kod generowany przez model.
**Twarde:** fuzzing sterowany pokryciem (libFuzzer, AFL++, cargo-fuzz, Atheris, Jazzer) z sanitizerami; korpus startowy z realnych danych; w CI krótki przebieg na każdym PR, długi nocny; każdy znaleziony crash staje się testem regresji.
**Ekspert wie:** fuzzing różnicowy (dwie implementacje, to samo wejście, różne wyjście) znajduje błędy logiczne, nie tylko awarie.
**Sprawdź:** pokrycie osiągnięte przez fuzzer + liczba unikalnych crashy.
**Nie:** fuzzing bez sanitizerów (błędy pamięci przechodzą cicho); jednorazowy przebieg zamiast ciągłego.
