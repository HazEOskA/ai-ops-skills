# Karty: osa-containers-docker

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### F06 · Docker i obrazy
**Gdy:** konteneryzacja, rozmiar obrazu, build.
**Twarde:** multi-stage build, obraz produkcyjny bez narzędzi budowania; obraz bazowy przypięty do digestu, nie do tagu; użytkownik nie-root; warstwy uporządkowane od najrzadziej zmiennych (cache); `.dockerignore` obowiązkowy; healthcheck zdefiniowany; sekrety przez build secrets, nigdy w warstwach.
**Ekspert wie:** `docker history` i ARG/ENV zdradzają sekrety z warstw; `.dockerignore` bez `.git` i `.env` wrzuca je do obrazu. Pin do digestu daje powtarzalność, ale wymaga procesu aktualizacji, inaczej obraz starzeje się razem z podatnościami.
**Sprawdź:** `docker history $IMG`, `trivy image --severity HIGH,CRITICAL $IMG`, `docker inspect -f '{{.Config.User}}' $IMG`
**Nie:** `FROM ubuntu:latest`; `COPY . .` przed instalacją zależności; sekret w `ARG` (zostaje w historii obrazu).

### F07 · Kubernetes na produkcji
**Gdy:** K8s, OOMKilled, CrashLoopBackOff, rollout.
**Twarde:** requests to gwarancja, limits to sufit — przekroczenie pamięci zabija, CPU throttluje; memory request równy limitowi dla przewidywalności; trzy sondy o trzech różnych rolach; PDB obowiązkowy; anti-affinity; graceful shutdown z `preStop` i okresem dłuższym niż najdłuższe żądanie; sekrety z zewnętrznego sejfu; NetworkPolicy default-deny.
**Ekspert wie:** OOMKilled przy pamięci poniżej limitu bywa wyczerpaniem pamięci węzła albo page cache liczonym do cgroup. Limit CPU powoduje throttling nawet przy wolnych rdzeniach — część zespołów ustawia request bez limitu CPU i mierzy `container_cpu_cfs_throttled_periods_total`.
**Sprawdź:** `kubectl rollout status` + przetestowany `kubectl rollout undo`; `kubectl top pods --containers`
**Nie:** liveness probe sprawdzający bazę (restartuje wszystkie pody w czasie awarii bazy); brak readiness przy rolling update; `latest` w tagu obrazu.

### Q01 · Procesy, sygnały, zamykanie
**Gdy:** proces nie kończy się, zombie, restart gubi dane.
**Twarde:** SIGTERM = prośba o zamknięcie (obsłuż: przestań przyjmować, dokończ, zamknij), SIGKILL = bez szans; proces PID 1 w kontenerze nie ma domyślnych handlerów — użyj init (`tini`, `--init`) albo obsłuż sygnały sam; zombie to dziecko bez `wait()` rodzica; limit deskryptorów (`ulimit -n`) kończy się pod obciążeniem.
**Ekspert wie:** `CMD npm start` w Dockerze sprawia, że npm jest PID 1 i nie przekazuje SIGTERM do node — aplikacja dostaje SIGKILL po timeoutcie i gubi żądania w locie.
**Sprawdź:** `docker stop` z logiem zamknięcia; `ls /proc/<pid>/fd | wc -l` vs limit.
**Nie:** zamykanie przez `kill -9` jako standard; forma shell w `CMD` bez `exec`.

### Q04 · Kontenery od środka
**Gdy:** izolacja, uprawnienia, „działa lokalnie, w kontenerze nie”.
**Twarde:** kontener = proces + namespaces (pid, net, mnt, user, ipc, uts) + cgroups (limity) + capabilities + seccomp; to nie jest granica bezpieczeństwa na poziomie VM — ucieczka z kontenera to jeden błąd jądra; `--privileged` i montowanie socketu Dockera = root na hoście; rootless i user namespaces zmniejszają skutki ucieczki.
**Ekspert wie:** różnica „lokalnie działa” to zwykle: inny użytkownik (UID), brak zmiennych, system plików tylko do odczytu, DNS w sieci kontenera albo architektura obrazu (arm64 vs amd64).
**Sprawdź:** `docker inspect` (User, CapAdd, Privileged, Mounts) + `docker run --rm -it --entrypoint sh img` do porównania środowiska.
**Nie:** `/var/run/docker.sock` montowany do aplikacji; kontenery jako izolacja dla niezaufanego kodu bez gVisor/Firecrackera.
