---
name: "osa-containers-docker"
description: "Kontenery i Docker: Dockerfile, obrazy minimalne, PID 1 i sygnały, cgroups i limity, namespaces, Compose, bezpieczeństwo obrazu. Użyj przy konteneryzacji, debugowaniu kontenerów, limitach zasobów. Triggers: Docker, Dockerfile, container, image, Compose, cgroups, namespaces, Kubernetes basics, kontener."
---

# Kontenery

## Procedura

1. **Sprawdź środowisko**: czy Docker jest dostępny (`docker version`). Nie ma go w sesji? Powiedz to i oznacz komendy jako nieuruchomione.
2. **Dockerfile**: obraz bazowy przypięty do wersji (nie `latest`), wieloetapowy build, tylko artefakty runtime w obrazie końcowym, `.dockerignore`, użytkownik nie-root.
3. **PID 1 i sygnały**: proces aplikacji ma odbierać `SIGTERM` i kończyć się czysto. Uruchamianie przez menedżer pakietów jako PID 1 (np. `npm start`) bywa pułapką; użyj bezpośredniego wywołania procesu lub init (`--init`). Karty w Q opisują mechanizm.
4. **Limity**: pamięć i CPU ustawione jawnie; zachowanie po przekroczeniu (OOM kill) przetestowane.
5. **Sekrety**: nie w warstwach obrazu ani w `ENV` w Dockerfile (`osa-secrets-hygiene`). Sprawdź: `docker history <obraz>`.
6. **Test**: zbuduj i uruchom z komendą weryfikacyjną (`osa-verify-run`): obraz startuje, port odpowiada, zatrzymanie kończy się czystym exit.
7. **Skan**: skan podatności obrazu, jeśli dostępne narzędzie (nie zakładaj, że zainstalowane).

## Nie

- `latest` w produkcji, `--privileged`, montowania gniazda Dockera do kontenera bez powodu.
- Danych trwałych w warstwie zapisu kontenera.
- Kubernetesa bez liczby uzasadniającej (`osa-cloud-decision-finops`).

## Karty (references/cards.md)

- **F06** · Docker i obrazy — gdy: konteneryzacja, rozmiar obrazu, build
- **F07** · Kubernetes na produkcji — gdy: K8s, OOMKilled, CrashLoopBackOff, rollout
- **Q01** · Procesy, sygnały, zamykanie — gdy: proces nie kończy się, zombie, restart gubi dane
- **Q04** · Kontenery od środka — gdy: izolacja, uprawnienia, „działa lokalnie, w kontenerze nie”

Wczytaj tylko karty pasujące do zadania (grep po ID).
