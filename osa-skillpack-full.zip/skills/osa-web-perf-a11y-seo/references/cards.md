# Karty: osa-web-perf-a11y-seo

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### D07 · Dostępność
**Gdy:** a11y, WCAG, nawigacja klawiaturą.
**Twarde:** semantyczny HTML przed ARIA — `button` bije `div role="button"`; wszystko osiągalne klawiaturą, focus widoczny, pułapki focusu w modalach obsłużone; kontrast 4.5:1 dla tekstu; komunikaty dynamiczne w `aria-live`; formularz z etykietami powiązanymi z polami; `prefers-reduced-motion` uszanowane.
**Ekspert wie:** Najczęstsze realne bariery to brak etykiet formularza, pułapka fokusu w modalu i kontrast. Automat (axe) wykrywa tylko część problemów; resztę znajdziesz przejściem przez cały przepływ samą klawiaturą i z czytnikiem ekranu.
**Sprawdź:** `npx @axe-core/cli $URL` + przejście całego przepływu wyłącznie klawiaturą.
**Nie:** ARIA nakładana na złą semantykę; usunięty outline focusu; ikona-przycisk bez etykiety tekstowej.

### D08 · Core Web Vitals
**Gdy:** LCP, INP, CLS, wolna strona, SEO techniczne.
**Twarde:** dane z terenu są prawdą, Lighthouse to laboratorium; obraz LCP z `fetchpriority=high`, nigdy `loading=lazy`; INP psuje długi JS — dziel zadania powyżej 50 ms; CLS to brak wymiarów i wstawki nad treścią; budżet JS egzekwowany w CI; skrypty zewnętrzne mierz osobno, zwykle to one są problemem.
**Ekspert wie:** Lighthouse to laboratorium na jednym urządzeniu; oceniaj dane terenowe (CrUX, RUM) z 75. percentyla. INP psują zwykle długie zadania po interakcji i skrypty zewnętrzne — rozmiar bundla jest raczej pośrednim winowajcą.
**Sprawdź:** `npx lighthouse $URL` + RUM z produkcji; `PerformanceObserver` na `layout-shift`.
**Nie:** optymalizacja wyniku zamiast doświadczenia; preload dziesięciu zasobów; consent blokujący render.

### D09 · Obrazy i media
**Gdy:** ciężka strona, galeria, wideo.
**Twarde:** AVIF/WebP z fallbackiem; `srcset` i `sizes` dopasowane do realnych szerokości; wymiary zawsze podane; lazy poniżej pierwszego ekranu, nigdy dla LCP; wideo nie autoodtwarza się z dźwiękiem i ma `preload=metadata`; CDN z transformacją zamiast wariantów generowanych ręcznie.
**Ekspert wie:** Lazy-loading obrazu LCP opóźnia najważniejszy element strony: obraz nad linią zwijania dostaje `fetchpriority=high` i nigdy `loading=lazy`. Brak `width`/`height` to główne źródło CLS przy obrazach.
**Sprawdź:** waga strony w Network przy throttlingu Slow 4G.
**Nie:** jeden plik 3000 px serwowany na telefon; brak wymiarów (CLS); wideo w tle bez ograniczenia na mobile.

### M06 · SEO techniczne
**Gdy:** widoczność w wyszukiwarce.
**Twarde:** indeksowalność przed optymalizacją — sprawdź, czy treść jest w HTML bez JS; jeden URL kanoniczny na treść; mapa strony i poprawne kody statusu (soft 404 to realny problem); dane strukturalne tam, gdzie mają sens; Core Web Vitals jako czynnik, ale treść i intencja ważniejsze; przekierowania przy migracji zmapowane 1:1.
**Ekspert wie:** Treść renderowana wyłącznie w JS bywa indeksowana z opóźnieniem lub niekompletnie — sprawdź `curl` (co widzi robot bez JS), kody statusu (soft 404), kanoniczne URL i mapę strony. Przy migracji domeny przekierowania 301 mapowane 1:1 decydują o utracie ruchu.
**Sprawdź:** `curl -sS $URL | grep -c "<szukana treść>"` oraz raport indeksowania w narzędziach wyszukiwarki.
**Nie:** treść renderowana wyłącznie po stronie klienta; duplikaty pod wieloma URL-ami; migracja domeny bez mapy przekierowań.
