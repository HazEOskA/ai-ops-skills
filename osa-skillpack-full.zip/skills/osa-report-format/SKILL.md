---
name: "osa-report-format"
description: "Format raportu końcowego Osy: tabela czasowników rdzenia i siedem sekcji od Root Cause po Next Smallest Task. Użyj na zakończenie każdej pracy technicznej. Triggers: report, summary, final report, raport, podsumowanie, koniec zadania."
---

# Format raportu

Raport zaczyna się od tabeli z `osa-definition-of-done`, potem siedem sekcji w tej kolejności. Szablon: `assets/report_template.md`.

1. **Root Cause** — co było przyczyną (dla nowej funkcji: jaka potrzeba). Jedno zdanie, mierzalnie.
2. **Files Changed** — wynik `scope_check.py` (`osa-scope-guard`) albo `git diff --stat`. Lista plików, nie opis.
3. **Implementation Summary** — co zrobiono i dlaczego tak. Kompromis nazwany liczbą.
4. **Validation Results** — bloki dowodowe z `osa-verify-run`: komenda, exit, wynik. Poziom dowodu przy każdym.
5. **Remaining Risks** — konkretne, z warunkiem „pęka jeśli”. Nie ogólniki.
6. **Rollback** — dokładna komenda cofnięcia (SHA, `git revert`, kroki). Jeśli nieodwracalne, napisz to.
7. **Next Smallest Task** — jeden najmniejszy następny krok, nie lista.

## Zasady

- Status „GOTOWE” tylko zgodnie z `osa-definition-of-done`. Inaczej pierwsze zdanie: „CZĘŚCIOWE: …”.
- Nie opowiadaj kroków. Wynik, dowód, ryzyko.
- Wszystko niesprawdzone oznacz `nieuruchomione` albo `unknown`. Zero zgadywania.
- Po raporcie, jeśli Osa pracuje z Gmailem: `osa-gmail-draft-log`.

## Karty (references/cards.md)

- **I09** · Dokumentacja — gdy: README, dokumentacja API, runbook

Wczytaj tylko karty pasujące do zadania (grep po ID).
