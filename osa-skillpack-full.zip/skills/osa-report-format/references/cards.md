# Karty: osa-report-format

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### I09 · Dokumentacja
**Gdy:** README, dokumentacja API, runbook.
**Twarde:** dokumentacja bliżej kodu żyje dłużej; cztery różne rodzaje mają różnych odbiorców: tutorial, przewodnik zadaniowy, referencja, wyjaśnienie — nie mieszaj ich w jednym pliku; README odpowiada na: co to, jak uruchomić, jak wnieść zmianę; przykłady wykonywalne i testowane, bo nietestowany przykład gnije.
**Ekspert wie:** Dokumentacja starzeje się w tempie kodu, więc jedyną trwałą formą są przykłady uruchamiane w CI i README testowane z czystego klonu. ADR-y zapisują decyzje, których kod nie wyjaśni.
**Sprawdź:** czy nowa osoba uruchomi projekt wyłącznie z README, bez pytania.
**Nie:** dokumentacja opisująca stan sprzed roku; komentarz powtarzający kod zamiast wyjaśniający decyzję; jedna wielka strona „dokumentacja".
