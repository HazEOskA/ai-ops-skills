# Raport: <tytuł zadania>

**Status: GOTOWE / CZĘŚCIOWE: <czego brakuje>**

| Czasownik rdzenia | Status | Dowód (komenda + wynik albo „brak”) |
|---|---|---|
|  |  |  |

## Root Cause

## Files Changed

## Implementation Summary

## Validation Results

## Remaining Risks

## Rollback

## Next Smallest Task

Zakładam: … | Niepewne: … | Pęka jeśli: …
