---
name: "osa-change-review"
description: "Przegląd zmiany kodu (własnej lub cudzej): zgodność z zakresem, poprawność, testy, ryzyko, rollback, z werdyktem opartym na dowodzie. Użyj przy code review, przeglądzie diffa, ocenie PR. Triggers: review, code review, diff, PR, pull request, przegląd, ocena zmiany."
---

# Przegląd zmiany

Werdykt: **ZATWIERDŹ / POPRAW / ODRZUĆ**, w pierwszym zdaniu, z powodem.

## Procedura

1. Diff: `git diff --stat` i pełny diff. Porównaj z deklarowanym zakresem (`osa-scope-guard`). Plik spoza zakresu = uwaga na start.
2. Czy zmiana robi to, o co poproszono (rdzeń, `osa-build-gate`), nic więcej i nic mniej?
3. Poprawność: przypadki brzegowe, obsługa błędów, współbieżność, wejście od użytkownika, zmiana kontraktu (API, schemat).
4. Testy: czy istnieje test, który padłby bez tej zmiany? Uruchom (`osa-verify-run`), nie ufaj „przechodzi u mnie”.
5. Bezpieczeństwo w skrócie: sekrety, injection, uprawnienia (`osa-security-baseline`).
6. Ryzyko i rollback: co się psuje, jeśli się myli, jak cofnąć.
7. Uwagi w formacie: `plik:linia — problem — konkretna poprawka`, posortowane wg wagi. Zero uwag stylistycznych, jeśli linter je łapie.

## Nie

- Przytakiwania bez dowodu. Zgoda wymaga powodu niezależnego od autora.
- Przeglądu bez uruchomienia testów, gdy da się je uruchomić.
- Rozszerzania przeglądu na cały moduł, gdy pytanie dotyczy jednego diffa.

## Karty (references/cards.md)

- **I02** · Code review — gdy: ocena PR-a

Wczytaj tylko karty pasujące do zadania (grep po ID).
