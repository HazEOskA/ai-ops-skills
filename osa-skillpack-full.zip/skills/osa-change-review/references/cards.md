# Karty: osa-change-review

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### I02 · Code review
**Gdy:** ocena PR-a.
**Twarde:** kolejność: zgodność z opisem → bezpieczeństwo i dane → warunki brzegowe → obsługa błędów → wydajność w widocznych miejscach → testy → czytelność na końcu; oznaczaj uwagi jako BLOKUJE / POWINNO / OPCJONALNIE; test, który przechodzi też na starym kodzie, niczego nie testuje; migracje czytaj osobno, zawsze.
**Ekspert wie:** Największe ryzyko siedzi w tym, czego diff nie pokazuje: brakujący test negatywny, nowy endpoint bez autoryzacji, migracja bez planu wycofania, zmieniona wartość domyślna. Czytaj najpierw plik testów — mówi, co autor uważa za zachowanie.
**Sprawdź:** `git diff main...HEAD -- '*.sql' '*migration*'` + `gitleaks detect`
**Nie:** „LGTM" na 2000 liniach; blokowanie preferencją estetyczną; review stylu przy pominiętej dziurze w autoryzacji.
