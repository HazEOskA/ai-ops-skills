---
name: "osa-session-handoff"
description: "Zapis sesji do sessions/YYYY-MM-DD-nazwa.md i wznowienie: ustalone, otwarte, rozjazdy, następny krok. Użyj na końcu sesji, przy //osa i przy podjęciu przerwanej pracy. Triggers: session, handoff, resume, wznów, zapisz sesję, pause, koniec dnia."
---

# Przekazanie sesji

Sesje zapisujemy w repo jako `sessions/YYYY-MM-DD-nazwa.md`. Format = kotwica z `osa-honesty-contract`: USTALONE / OTWARTE / ROZJAZD / NASTĘPNY KROK, plus stan repo.

## Zapis

`python3 scripts/write_session_file.py --name "krótka-nazwa" --repo <ścieżka> --ustalone "a;b" --otwarte "c" --rozjazd "" --next "d"`

- Skrypt dopisuje branch i SHA z git (jeśli to repo), nie nadpisuje istniejącego pliku bez `--force`.
- Pola rozdziel średnikiem. Puste pole = „brak”.
- Zero sekretów w pliku (`osa-secrets-hygiene`). Skrypt ostrzega, jeśli wartość wygląda na token.

## Wznowienie

1. Wczytaj najnowszy plik z `sessions/` (najświeższa data w nazwie).
2. Wykonaj `osa-context-lock`: SHA z pliku vs. aktualny. Różnica = rozjazd, zgłoś go pierwszym zdaniem.
3. Zacznij od „NASTĘPNY KROK” z pliku, chyba że Osa powie inaczej.

## Zasady

- Zapisuj to, co ustalone i sprawdzone. Hipotezy oznacz „hipoteza”.
- Jeden plik na sesję. Nie edytuj starych, dopisz nowy.
- Po zapisie: szkic maila dziennego (`osa-gmail-draft-log`), jeśli Osa go używa.
