#!/usr/bin/env python3
"""Zapisuje sessions/YYYY-MM-DD-nazwa.md. Exit 0 = zapisano, 1 = plik istnieje, 2 = błąd wejścia.

Użycie: python3 write_session_file.py --name nazwa [--repo .] [--ustalone "a;b"] [--otwarte "c"]
        [--rozjazd "d"] [--next "e"] [--force]
"""
import argparse, datetime, re, subprocess, sys
from pathlib import Path

TOKEN_RE = re.compile(r"(AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)")


def git(repo, *args):
    r = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None


def items(s):
    parts = [x.strip() for x in (s or "").split(";") if x.strip()]
    return parts or ["brak"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--repo", default=".")
    for k in ("ustalone", "otwarte", "rozjazd", "next"):
        ap.add_argument(f"--{k}", default="")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    slug = re.sub(r"[^a-z0-9]+", "-", a.name.lower()).strip("-")
    if not slug:
        print("BŁĄD: pusta nazwa", file=sys.stderr)
        sys.exit(2)
    for v in (a.ustalone, a.otwarte, a.rozjazd, a.next):
        if TOKEN_RE.search(v):
            print("BŁĄD: wartość wygląda na sekret. Usuń i spróbuj ponownie.", file=sys.stderr)
            sys.exit(2)
    repo = Path(a.repo).resolve()
    branch, sha = git(repo, "rev-parse", "--abbrev-ref", "HEAD"), git(repo, "rev-parse", "HEAD")
    dirty = git(repo, "status", "--porcelain")
    d = datetime.date.today().isoformat()
    out = repo / "sessions" / f"{d}-{slug}.md"
    if out.exists() and not a.force:
        print(f"Istnieje: {out} (użyj --force albo innej nazwy)", file=sys.stderr)
        sys.exit(1)
    out.parent.mkdir(exist_ok=True)
    def sec(t, s):
        return f"## {t}\n" + "\n".join(f"- {x}" for x in items(s)) + "\n"
    stan = f"branch: {branch or 'unknown (nie repo git)'}\nSHA: {sha or 'unknown'}\nniezacommitowane: {('TAK, ' + str(len(dirty.splitlines())) + ' plików') if dirty else ('nie' if dirty == '' else 'unknown')}"
    out.write_text(f"# Sesja {d} · {a.name}\n\n## STAN REPO\n{stan}\n\n" + sec("USTALONE", a.ustalone) + "\n" + sec("OTWARTE", a.otwarte) + "\n" + sec("ROZJAZD", a.rozjazd) + "\n" + sec("NASTĘPNY KROK", a.next), encoding="utf-8")
    print(f"Zapisano {out}")


if __name__ == "__main__":
    main()
