#!/usr/bin/env python3
"""Porównuje zmienione pliki (git) z deklarowaną listą. Exit 0 = zgodne, 1 = naruszenie, 2 = błąd środowiska.

Użycie: python3 scope_check.py --declared .osa-scope.txt [--base HEAD] [--repo .]
Zmienione = różnice względem --base (domyślnie HEAD) + pliki nieśledzone.
"""
import argparse, subprocess, sys
from pathlib import Path


def git(repo, *args):
    r = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True)
    if r.returncode:
        print("BŁĄD git:", r.stderr.strip(), file=sys.stderr)
        sys.exit(2)
    return r.stdout


def norm(p):
    return p.strip().replace("\\", "/").lstrip("./")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--declared", required=True)
    ap.add_argument("--base", default="HEAD")
    ap.add_argument("--repo", default=".")
    a = ap.parse_args()
    dp = Path(a.declared)
    if not dp.exists():
        print(f"BŁĄD: brak pliku z deklaracją {dp}", file=sys.stderr)
        sys.exit(2)
    declared = {norm(l) for l in dp.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")}
    changed = {norm(l) for l in git(a.repo, "diff", "--name-only", a.base).splitlines() if l.strip()}
    changed |= {norm(l) for l in git(a.repo, "ls-files", "--others", "--exclude-standard").splitlines() if l.strip()}
    changed.discard(norm(a.declared))
    outside = sorted(changed - declared)
    untouched = sorted(declared - changed)
    print(f"zmienione: {len(changed)} | zadeklarowane: {len(declared)}")
    for f in sorted(changed & declared):
        print(f"  OK       {f}")
    for f in outside:
        print(f"  NARUSZENIE (spoza listy) {f}")
    for f in untouched:
        print(f"  nie ruszono (zadeklarowany) {f}")
    print("WYNIK:", "NARUSZENIE ZAKRESU" if outside else "zakres zgodny")
    sys.exit(1 if outside else 0)


if __name__ == "__main__":
    main()
