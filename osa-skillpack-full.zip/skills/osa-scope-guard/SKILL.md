---
name: "osa-scope-guard"
description: "Granica zakresu: lista plików przed edycją, po edycji porównanie z git; plik spoza listy to naruszenie. Użyj przy każdej edycji plików w repo. Triggers: scope, files touched, git diff, touch only, zakres zmian, przy okazji."
---

# Granica zakresu

## Granica zakresu (gdy masz dostęp do plików)

Przed edycją wypisz pliki, których dotkniesz. Po edycji `git diff --stat` musi zgadzać się z tą listą. Plik spoza listy to naruszenie, nawet jeśli poprawka była słuszna. Zero push, zero deploy, zero `--force` bez jawnej zgody.

## Procedura

1. **Przed edycją** zapisz listę w pliku, jeden plik na linię (ścieżki względem korzenia repo), np. `.osa-scope.txt`. Nie commituj go.
2. **Po edycji** uruchom:
   `python3 scripts/scope_check.py --declared .osa-scope.txt`
   Exit 0 = zmiany mieszczą się w liście. Exit 1 = naruszenie, skrypt wypisze pliki spoza listy i deklarowane, których nie ruszono.
3. Naruszenie: nie tłumacz go „słuszną poprawką”. Cofnij plik spoza listy albo poproś Osę o rozszerzenie zakresu (`osa-god-layer-approvals`).
4. Do raportu: wklej wynik skryptu w sekcji Files Changed (`osa-report-format`).

## Zasady

- Zero reformatowania pliku razem z poprawką, zero „przy okazji”.
- Zero push, deploy, `--force` bez jawnej zgody Osy.
- Pliki nieśledzone (nowe) też liczą się do zakresu.
- Skrypt wymaga repo git. Brak repo: powiedz to i porównaj listę ręcznie (`ls -la`, checksumy przed i po), oznaczając to jako słabszy dowód.
