---
name: "osa-refactor-safe"
description: "Bezpieczny refactor i dług techniczny: testy charakteryzujące najpierw, małe kroki bez zmiany zachowania, dowód równoważności. Użyj przy refactorze, porządkowaniu kodu, migracji wewnętrznej, spłacie długu. Triggers: refactor, cleanup, tech debt, rename, restructure, porządki."
---

# Bezpieczny refactor

Refactor nie zmienia zachowania. Jeśli zmienia, to już nie refactor, tylko zmiana funkcjonalna: rozdziel.

## Procedura

1. Bez testów pokrywających zachowanie nie ruszaj. Napisz najpierw testy charakteryzujące (zapisują to, co kod robi dziś, także dziwactwa). `osa-test-strategy`.
2. Wynik bazowy testów przed zmianą (`osa-verify-run`).
3. Małe kroki: jeden ruch (rename, extract, move), testy, commit. Nigdy „wielki wybuch”.
4. Refactor i zmiana zachowania w osobnych commitach.
5. Zakres z góry (`osa-scope-guard`). Reformat całych plików to osobny commit, nie „przy okazji”.
6. Dowód równoważności: te same testy przed i po, wynik porównany. Dla ścieżek krytycznych: porównanie wyjść na realnych danych.
7. Rollback: każdy krok odwracalny osobno.

## Nie

- Refactoru bez testów (poza triviami wspieranymi przez kompilator/IDE i oznaczonymi jako takie).
- Refactoru w tym samym PR-ze co funkcja.
- Uzasadnienia „ładniej”. Podaj mierzalny koszt obecnego stanu.

## Karty (references/cards.md)

- **I03** · Refactor — gdy: legacy, przepisanie modułu
- **I04** · Dług techniczny — gdy: „trzeba to posprzątać"

Wczytaj tylko karty pasujące do zadania (grep po ID).
