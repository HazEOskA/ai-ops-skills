# Karty: osa-refactor-safe

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### I03 · Refactor
**Gdy:** legacy, przepisanie modułu.
**Twarde:** refactor zachowuje zachowanie i jest odwracalny w każdym kroku, rewrite to nowy projekt z pełnym ryzykiem; testy charakteryzujące przed pierwszą zmianą, łącznie z dziwactwami; małe kroki mergowane do main, bo długi branch umiera w konfliktach; przeniesienia plików w osobnych commitach od zmian logiki; strangler przy dużej zmianie; usunięcie starej ścieżki to osobne zadanie z terminem.
**Ekspert wie:** Testy charakteryzujące zapisują to, co kod robi, nie to, co powinien — łapią przypadkową regresję. Refactor i zmiana zachowania w jednym commicie uniemożliwiają bisekcję, więc rozdziel je nawet kosztem dwóch PR.
**Sprawdź:** te same testy charakteryzujące zielone przed i po każdym kroku; `git diff -M --stat`.
**Nie:** rewrite działającego systemu; refactor razem z nową funkcją w jednym PR; zmiana zachowania „przy okazji porządkowania".

### I04 · Dług techniczny
**Gdy:** „trzeba to posprzątać".
**Twarde:** dług bez kosztu wyrażonego liczbą nie ma priorytetu — mierz czasem wdrażania zmian i częstością błędów w danym obszarze; rozróżnij dług świadomy (decyzja z terminem) od bałaganu (brak decyzji); spłacaj przy okazji pracy w danym miejscu, nie w osobnym kwartale sprzątania; niektóre obszary nie warto spłacać, bo i tak znikną.
**Ekspert wie:** Dług mierz miejscami, gdzie zmiany trwają najdłużej i psują najczęściej (hotspot: częstość zmian × złożoność), a nie estetyką. Obszar, którego nie dotykasz, nie kosztuje odsetek.
**Sprawdź:** mapa obszarów po liczbie zmian i liczbie poprawek błędów — tam siedzi realny dług.
**Nie:** rejestr długu, którego nikt nie czyta; „sprint techniczny" zamiast ciągłej spłaty; refactor obszaru, który nie jest dotykany.
