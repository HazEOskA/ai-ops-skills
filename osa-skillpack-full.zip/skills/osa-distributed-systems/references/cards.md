# Karty: osa-distributed-systems

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### P01 · Modele spójności
**Gdy:** „użytkownik nie widzi swojego zapisu”, cache, repliki, multi-region.
**Twarde:** nazwij wymagany model per operacja: linearizowalność (jak jedna kopia), sekwencyjna, przyczynowa, read-your-writes, monotoniczne odczyty, ostateczna; CAP mówi o partycji, PACELC dodaje: bez partycji wybierasz latencję albo spójność; silniejsza spójność = wyższa latencja, zawsze.
**Ekspert wie:** większość skarg „dane znikają” to brak read-your-writes po zapisie do primary i odczycie z repliki — naprawa to sticky routing albo odczyt z primary przez okno czasu po zapisie, nie silniejsza baza.
**Sprawdź:** test: zapis → natychmiastowy odczyt z innej instancji, 1000 razy, liczba niezgodności.
**Nie:** „baza jest ACID, więc system jest spójny” przy cache i replikach po drodze; wybór eventual consistency bez zaprojektowania, co widzi użytkownik w oknie rozjazdu.

### P02 · Konsensus
**Gdy:** wybór lidera, konfiguracja rozproszona, blokady rozproszone.
**Twarde:** nie implementuj Raft/Paxos sam — użyj etcd, ZooKeeper, Consul albo bazy z wbudowanym konsensusem; klaster ma nieparzystą liczbę węzłów (3 toleruje 1 awarię, 5 toleruje 2); zapis wymaga większości, więc latencja zapisu = latencja do najwolniejszego z większości; lider z dzierżawą potrzebuje fencing tokenów.
**Ekspert wie:** blokada rozproszona bez fencing tokena nie chroni przed procesem, który „obudził się” po pauzie GC z przekonaniem, że nadal ma blokadę — dlatego Redlock jest krytykowany.
**Sprawdź:** test Jepsen-podobny: zabij lidera i podziel sieć podczas zapisów, sprawdź historię pod kątem linearizowalności.
**Nie:** dwa węzły konsensusu (brak większości przy awarii jednego); konsensus rozciągnięty między kontynentami dla każdego zapisu.

### P03 · Replikacja
**Gdy:** HA, repliki odczytowe, multi-region, failover.
**Twarde:** synchroniczna = zero utraty, wyższa latencja, zależność od repliki; asynchroniczna = okno utraty równe lagowi — nazwij je w sekundach; multi-leader i leaderless wymagają rozstrzygania konfliktów (LWW gubi dane, CRDT kosztuje złożoność); lag replikacji jest metryką z alertem.
**Ekspert wie:** failover na replikę asynchroniczną po cichu cofa czas — zapisy potwierdzone klientom znikają; sekwencje/ID mogą się powtórzyć po przełączeniu.
**Sprawdź:** lag w p99 pod obciążeniem + ćwiczenie failoveru z policzeniem utraconych zapisów.
**Nie:** LWW z zegarami ściennymi z wielu maszyn; odczyty z repliki dla danych, które użytkownik właśnie zapisał.

### P04 · Czas i zegary
**Gdy:** kolejność zdarzeń, TTL, wygasanie, logi z wielu maszyn.
**Twarde:** zegar ścienny skacze (NTP, sekundy przestępne, ręczna zmiana) — do mierzenia odcinków używaj zegara monotonicznego; kolejność przyczynowa przez zegary logiczne (Lamport) albo wektorowe; hybrid logical clocks gdy potrzebujesz i czasu, i przyczynowości; timestampy w UTC, strefa tylko w prezentacji.
**Ekspert wie:** dryf zegarów między maszynami rzędu milisekund wystarcza, żeby „późniejszy” zapis miał wcześniejszy timestamp — każda logika „nowszy wygrywa” na timestampach z wielu maszyn jest błędem czekającym na obciążenie.
**Sprawdź:** `chronyc tracking` / `timedatectl` na węzłach + test z celowo przestawionym zegarem.
**Nie:** `Date.now()` do mierzenia czasu wykonania; porządkowanie zdarzeń z różnych serwisów po czasie ściennym.

### P05 · Partycjonowanie (sharding)
**Gdy:** jedna baza nie wystarcza, gorące klucze, wzrost.
**Twarde:** najpierw pionowo, repliki odczytowe i cache — sharding to ostatni krok, bo zabiera joiny i transakcje między shardami; klucz shardowania z wysoką kardynalnością i równym rozkładem ruchu (nie tylko danych); consistent hashing albo katalog shardów do przenoszenia; zaplanuj resharding zanim będzie potrzebny.
**Ekspert wie:** rozkład danych równy ≠ rozkład ruchu równy — jeden celebryta albo jeden duży tenant robi gorący shard niezależnie od hashowania; rozwiązanie to dzielenie gorących kluczy, nie więcej shardów.
**Sprawdź:** ruch i rozmiar per shard na dashboardzie; najgorszy shard vs mediana.
**Nie:** shardowanie po dacie (cały zapis trafia w jeden shard); zapytania rozgłoszeniowe do wszystkich shardów w ścieżce użytkownika.

### P06 · Transakcje rozproszone i sagi
**Gdy:** operacja obejmuje kilka serwisów lub baz.
**Twarde:** 2PC blokuje przy awarii koordynatora — unikaj między serwisami; saga = sekwencja lokalnych transakcji z akcjami kompensującymi; orkiestracja (centralny koordynator, łatwiejsza do śledzenia) vs choreografia (zdarzenia, łatwiej się rozjeżdża); każdy krok idempotentny; kompensacja to nowa operacja biznesowa, nie „rollback”.
**Ekspert wie:** niektórych kroków nie da się skompensować (wysłany mail, wypłacone pieniądze) — ustaw je na końcu sagi; stan sagi musi być trwały, żeby przetrwać restart koordynatora.
**Sprawdź:** wstrzyknij awarię po każdym kroku sagi i sprawdź stan końcowy wszystkich systemów.
**Nie:** transakcja rozproszona przez wywołania HTTP w jednym handlerze; brak ścieżki dla kompensacji, która też się nie udała.
