---
name: "osa-distributed-systems"
description: "Systemy rozproszone: spójność, replikacja, konsensus, zegary, partycjonowanie, sagi, split-brain, kompromis CAP/PACELC z liczbami. Użyj przy replikacji, wielu instancjach, transakcjach między usługami, symulacji rozproszonej. Triggers: distributed, consensus, replication, consistency, CAP, saga, partition, Raft, eventual consistency, rozproszone."
---

# Systemy rozproszone

## Zasady

1. **Nie rozpraszaj bez potrzeby.** Jeden proces i jedna baza przetwarzają zaskakująco dużo; rozproszenie dodaje klasy błędów, których nie da się wyeliminować, tylko zarządzać. Uzasadnij liczbą (obciążenie, dostępność, opóźnienie geograficzne).
2. **Sieć zawodzi**: zakładaj utratę, duplikację, przekroczenie czasu, zmianę kolejności i częściowe awarie. Projektuj operacje idempotentne z kluczami.
3. **Spójność jako wybór z ceną**: dla każdej operacji wskaż wymagany model (silna, sesyjna, „read-your-writes”, ostateczna) i cenę w opóźnieniu i dostępności. Replikacja synchroniczna vs asynchroniczna: nazwij okno możliwej utraty danych (RPO) i opóźnienie zapisu liczbą, nie przymiotnikiem.
4. **Konsensus i lider**: nie implementuj własnego. Użyj sprawdzonego magazynu/usługi koordynacji. Chroń się przed dwoma liderami (split-brain): tokeny ogradzające (fencing).
5. **Czas**: zegarów ściennych nie używaj do porządkowania zdarzeń między maszynami; użyj zegarów logicznych/wektorowych albo monotoniczności z jednego źródła.
6. **Transakcje między usługami**: sagi z kompensacją i outbox zamiast rozproszonych transakcji dwufazowych, chyba że masz uzasadnienie.
7. **Partycjonowanie**: klucz dobrany pod wzorzec dostępu, plan przebalansowania, gorące klucze.
8. **Dowód**: test chaosu i partycji sieciowej (odcięcie węzła, opóźnienie, duplikaty) i sprawdzenie niezmienników (`osa-verify-run`). Formalnie krytyczne protokoły: modelowanie (`osa-domain-library`, karty W).

## Nie

- Zakładania niezawodnej sieci ani synchronizacji zegarów.
- „Ostatecznej spójności” bez zdefiniowanego zachowania w konflikcie.
- Własnego algorytmu konsensusu.

## Karty (references/cards.md)

- **P01** · Modele spójności — gdy: „użytkownik nie widzi swojego zapisu”, cache, repliki, multi-region
- **P02** · Konsensus — gdy: wybór lidera, konfiguracja rozproszona, blokady rozproszone
- **P03** · Replikacja — gdy: HA, repliki odczytowe, multi-region, failover
- **P04** · Czas i zegary — gdy: kolejność zdarzeń, TTL, wygasanie, logi z wielu maszyn
- **P05** · Partycjonowanie (sharding) — gdy: jedna baza nie wystarcza, gorące klucze, wzrost
- **P06** · Transakcje rozproszone i sagi — gdy: operacja obejmuje kilka serwisów lub baz

Wczytaj tylko karty pasujące do zadania (grep po ID).
