---
name: "osa-skill-authoring"
description: "Tworzenie i utrzymanie skilli OsaTechGPT: format SKILL.md, opis, rejestr, regeneracja indeksu orkiestratora, walidacja. Użyj przy dodawaniu, zmianie lub audycie skilla. Triggers: new skill, add skill, skill format, registry, index, dodaj skill, nowy skill."
---

# Tworzenie skilli

Paczka ma być otwarta: nie ma limitu liczby skilli. Orkiestrator to spis treści generowany z frontmatter.

## Nowy skill (kroki)

1. Folder `<nazwa>/` (kebab-case, prefiks `osa-`, bez słów claude i anthropic), w nim `SKILL.md`. Opcjonalnie `scripts/`, `references/`, `assets/`.
2. Frontmatter, jednolinijkowy, bez znaków `<` i `>`:
   ```
   ---
   name: "osa-<nazwa>"
   description: "<jedno zdanie ≤170 znaków: co i kiedy>. Triggers: <słowa kluczowe PL i EN>."
   ---
   ```
   Pierwsze zdanie opisu trafia do indeksu. Reszta to słowa wyzwalające.
3. Treść: procedura w krokach, twarde reguły, „Nie”, jak sprawdzić. Krótko. Długa wiedza idzie do `references/`, czytana selektywnie.
4. Wpis do `registry.json` (grupa). Bez wpisu skill trafi do grupy „Inne”.
5. `python3 scripts/build_index.py <katalog_skilli>`, potem `python3 scripts/validate_skills.py <katalog_skilli>`. Exit 0 wymagany.

## Zasady jakości

- Skill bez procedury i bez „Nie” to esej, nie skill. Dopisz oba.
- Nie duplikuj kontraktu: odwołaj się do `osa-honesty-contract` po nazwie.
- Skrypty: Python stdlib, bez zależności, działają na Windows (bez bash). Każdy skrypt ma exit code i jest uruchomiony przynajmniej raz na prawdziwym wejściu przed uznaniem za gotowy (`osa-verify-run`).
- Status skilla: dopóki nie ma wyniku ewaluacji (`osa-evals`), pisz w README „UNPROVEN”. Zero deklaracji SOTA bez benchmarku (`osa-proof-governance`).

## Audyt istniejącego skilla

Czy opis jednoznacznie odróżnia go od sąsiadów? Czy procedura da się wykonać bez zgadywania? Czy odwołania do innych skilli istnieją (walidator to sprawdza)? Czy ktoś kiedykolwiek go uruchomił?
