#!/usr/bin/env python3
"""Waliduje paczkę skilli. Exit 0 = OK, 1 = błędy.

Sprawdza: frontmatter (name == folder, kebab-case, opis jednolinijkowy <=1024 znaki,
pierwsze zdanie <=170, bez nawiasów kątowych), skille z registry istnieją,
INDEX zgodny z folderami, skrypty .py się kompilują, referencje do innych skilli istnieją.
"""
import json, re, sys
from pathlib import Path


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    err = []
    names = set()
    for d in sorted(root.iterdir()):
        if not d.is_dir():
            continue
        p = d / "SKILL.md"
        if not p.exists():
            err.append(f"{d.name}: brak SKILL.md")
            continue
        t = p.read_text(encoding="utf-8")
        m = re.match(r"^---\n(.*?)\n---\n", t, re.S)
        if not m:
            err.append(f"{d.name}: brak frontmatter")
            continue
        fm = dict(l.split(":", 1) for l in m.group(1).split("\n") if ":" in l)
        fm = {k.strip(): v.strip().strip('"') for k, v in fm.items()}
        n, desc = fm.get("name", ""), fm.get("description", "")
        names.add(d.name)
        if n != d.name:
            err.append(f"{d.name}: name '{n}' != folder")
        if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", n) or "claude" in n or "anthropic" in n:
            err.append(f"{d.name}: niedozwolona nazwa")
        if not desc or len(desc) > 1024:
            err.append(f"{d.name}: opis pusty lub >1024 ({len(desc)})")
        if "<" in desc or ">" in desc:
            err.append(f"{d.name}: nawiasy kątowe w opisie")
        s = re.match(r"(.+?[.!?])(\s|$)", desc)
        if s and len(s.group(1)) > 170:
            err.append(f"{d.name}: pierwsze zdanie opisu {len(s.group(1))} > 170")
        for py in d.rglob("*.py"):
            try:
                compile(py.read_text(encoding="utf-8"), str(py), "exec")
            except Exception as e:  # noqa
                err.append(f"{py}: {e}")
    reg = json.loads((root / "registry.json").read_text(encoding="utf-8")) if (root / "registry.json").exists() else None
    if reg:
        listed = {n for g in reg["groups"] for n in g["skills"]}
        for n in sorted(listed - names):
            err.append(f"registry: skill {n} bez folderu")
        for n in sorted(names - listed - {"osa-orchestrator"}):
            err.append(f"folder {n} nie jest w registry.json (trafi do 'Inne')")
    orch = root / "osa-orchestrator" / "SKILL.md"
    if orch.exists():
        t = orch.read_text(encoding="utf-8")
        idx = re.search(r"<!-- INDEX:START -->(.*?)<!-- INDEX:END -->", t, re.S)
        if not idx:
            err.append("orkiestrator: brak INDEX")
        else:
            in_idx = set(re.findall(r"^\| `(osa-[a-z0-9-]+)`", idx.group(1), re.M))
            for n in sorted(names - in_idx - {"osa-orchestrator"}):
                err.append(f"INDEX nie zawiera {n}")
    for d in root.iterdir():
        if d.is_dir() and (d / "SKILL.md").exists():
            for ref in set(re.findall(r"`(osa-[a-z0-9-]+)`", (d / "SKILL.md").read_text(encoding="utf-8"))):
                if ref not in names:
                    err.append(f"{d.name}: odwołanie do nieistniejącego skilla {ref}")
    print("\n".join(err) if err else f"OK: {len(names)} skilli")
    sys.exit(1 if err else 0)


if __name__ == "__main__":
    main()
