#!/usr/bin/env python3
"""Regeneruje INDEX w osa-orchestrator/SKILL.md z frontmatter wszystkich skilli w katalogu.

Użycie: python3 build_index.py <katalog_ze_skillami>
Dodanie skilla = dodanie folderu z SKILL.md, opcjonalnie wpis w registry.json, uruchomienie tego skryptu.
Skill nieujęty w registry.json trafia do grupy „Inne (niezarejestrowane)”.
"""
import json, re, sys
from pathlib import Path


def frontmatter(p):
    t = p.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n", t, re.S)
    if not m:
        return None
    fm = {}
    for ln in m.group(1).split("\n"):
        if ":" in ln:
            k, v = ln.split(":", 1)
            fm[k.strip()] = v.strip().strip('"')
    return fm


def first_sentence(d):
    m = re.match(r"(.+?[.!?])(\s|$)", d)
    return (m.group(1) if m else d).strip().replace("|", "/")


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    reg_p = root / "registry.json"
    reg = json.loads(reg_p.read_text(encoding="utf-8")) if reg_p.exists() else {"groups": [], "external": []}
    found = {}
    for d in sorted(root.iterdir()):
        if d.is_dir() and (d / "SKILL.md").exists():
            fm = frontmatter(d / "SKILL.md")
            if fm and fm.get("name"):
                found[fm["name"]] = fm.get("description", "")
    used, out = set(), []

    def rows(names):
        r = []
        for n in names:
            if n in found:
                used.add(n)
                r.append(f"| `{n}` | {first_sentence(found[n])} |")
            else:
                r.append(f"| `{n}` | BRAK FOLDERU — popraw registry.json |")
        return r

    for g in reg["groups"]:
        out += [f"**{g['title']}**", "", "| Skill | Kiedy |", "|---|---|"] + rows([n for n in g["skills"] if n != "osa-orchestrator"])
        ext = [e for e in reg.get("external", []) if e.get("group") == g["id"]]
        for e in ext:
            out.append(f"| `{e['name']}` (zewnętrzny) | {first_sentence(e['description'])} |")
        out.append("")
    rest = [n for n in found if n not in used and n != "osa-orchestrator"]
    if rest:
        out += ["**Inne (niezarejestrowane)**", "", "| Skill | Kiedy |", "|---|---|"] + rows(rest) + [""]
    idx = "\n".join(out).rstrip()
    o = root / "osa-orchestrator" / "SKILL.md"
    t = o.read_text(encoding="utf-8")
    if "<!-- INDEX:START -->" not in t:
        print("BŁĄD: brak znaczników INDEX w orkiestratorze", file=sys.stderr)
        sys.exit(1)
    t = re.sub(r"(<!-- INDEX:START -->).*?(<!-- INDEX:END -->)", lambda m: f"{m.group(1)}\n{idx}\n{m.group(2)}", t, flags=re.S)
    o.write_text(t, encoding="utf-8")
    print(f"INDEX: {len(used)} skilli w grupach, {len(rest)} niezarejestrowanych, {len(reg.get('external', []))} zewnętrznych")


if __name__ == "__main__":
    main()
