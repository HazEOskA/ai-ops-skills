---
name: "osa-postgres-data"
description: "Bazy danych, głównie PostgreSQL: projekt schematu, migracje bez przestoju, indeksy, EXPLAIN, pule połączeń, transakcje, kopie zapasowe i odtwarzanie. Użyj przy schemacie, migracji, wolnym zapytaniu, wyborze bazy. Triggers: Postgres, SQL, schema, migration, index, EXPLAIN, database, Supabase, baza danych, migracja."
---

# Postgres i dane

## Procedura

1. **Schemat**: znormalizuj do sensownego poziomu, klucze i ograniczenia w bazie (nie tylko w aplikacji), typy dokładne (czas z strefą, pieniądze jako liczba całkowita groszy lub numeric).
2. **Zapytania**: `EXPLAIN (ANALYZE, BUFFERS)` na realistycznej ilości danych. Indeks dodawaj pod konkretne zapytanie i sprawdź, że jest używany. Każdy indeks kosztuje zapisy.
3. **Migracje**: wersjonowane, w repo. Zmiany łamiące rozłóż: dodaj (expand) → przenieś dane → przełącz kod → usuń (contract). Duże tabele: uważaj na blokady; dodawanie indeksu współbieżnie (`CREATE INDEX CONCURRENTLY`), kolumny z wartością domyślną według dokumentacji Twojej wersji (`unknown`, jeśli wersji nie sprawdzono).
4. **Test migracji na kopii danych** i plan cofnięcia zapisany, zanim ruszysz produkcję. Migracja produkcyjna = zgoda (`osa-god-layer-approvals`).
5. **Połączenia**: pula (lub pooler) dopasowana do limitu bazy; liczba instancji aplikacji × pula < limit połączeń.
6. **Kopie zapasowe**: istnieją, a odtworzenie zostało przetestowane, z zmierzonym czasem (`osa-observability-slo`).
7. **Wybór bazy**: relacyjna domyślnie. Inna (dokumentowa, kolumnowa, grafowa, wektorowa) tylko z opisanym wzorcem dostępu, którego Postgres nie obsłuży.
8. **Supabase i podobne**: reguły dostępu na poziomie wierszy (RLS) włączone i przetestowane (`osa-authz-multitenancy`).

## Nie

- `SELECT *` w kodzie produkcyjnym, zapytań w pętli (N+1).
- Migracji łamiącej bez kompatybilnego okna.
- Sekretów bazy w repo (`osa-secrets-hygiene`).

## Karty (references/cards.md)

- **C01** · Modelowanie danych — gdy: projekt schematu, nowa encja
- **C02** · Postgres: indeksy i plany — gdy: wolne zapytanie, „dodajmy indeks"
- **C03** · Migracje bez downtime — gdy: zmiana schematu na żywej bazie
- **C04** · NoSQL (Mongo, Dynamo, Cosmos) — gdy: wybór albo modelowanie w bazie dokumentowej/klucz-wartość
- **C10** · Backup i odtwarzanie — gdy: kopie zapasowe, DR

Wczytaj tylko karty pasujące do zadania (grep po ID).
