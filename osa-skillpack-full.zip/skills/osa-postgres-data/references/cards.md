# Karty: osa-postgres-data

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### C01 · Modelowanie danych
**Gdy:** projekt schematu, nowa encja.
**Twarde:** normalizuj domyślnie, denormalizuj świadomie i z powodem; `timestamptz` nie `timestamp`; `numeric` na pieniądze; klucz naturalny tylko gdy jest naprawdę niezmienny; miękkie usuwanie wymaga indeksu częściowego, inaczej z czasem skanujesz śmieci; stan jako maszyna stanów z dozwolonymi przejściami, nie luźny string.
**Ekspert wie:** Miękkie usuwanie (`deleted_at`) psuje unikalność: `UNIQUE(email)` blokuje ponowną rejestrację — potrzebny indeks częściowy `WHERE deleted_at IS NULL`. Stan modeluj tabelą przejść albo CHECK, bo goły string „status” kończy z pięcioma pisowniami tej samej wartości.
**Sprawdź:** czy da się odpowiedzieć na trzy najważniejsze pytania biznesowe jednym zapytaniem bez sztuczek.
**Nie:** kolumny `data1`, `meta_json` jako wysypisko; enum jako typ bazy (dodanie tanie, zmiana koszmarna); brak `NOT NULL` tam, gdzie null nie ma znaczenia biznesowego.

### C02 · Postgres: indeksy i plany
**Gdy:** wolne zapytanie, „dodajmy indeks".
**Twarde:** najpierw `EXPLAIN (ANALYZE, BUFFERS)`, potem indeks; kolejność kolumn: równość → zakres → sortowanie; rozjazd szacunków to problem statystyk, nie indeksu; indeks częściowy dla stałego podzbioru; FK wymaga indeksu po stronie dziecka — Postgres go nie tworzy; index-only scan wymaga `INCLUDE`.
**Ekspert wie:** Planner często słusznie wybiera skan sekwencyjny (mała tabela, niska selektywność) — nie „naprawiaj” tego wymuszaniem. Problem zaczyna się, gdy szacunek wierszy różni się od rzeczywistego o rzędy wielkości (`rows=1` vs `actual rows=200000`): to sygnał na `ANALYZE`, statystyki rozszerzone lub przepisanie zapytania.
**Sprawdź:** `EXPLAIN (ANALYZE, BUFFERS) <q>;` przed i po; `SELECT indexrelname, idx_scan FROM pg_stat_user_indexes WHERE idx_scan = 0;`
**Nie:** indeks na każdą kolumnę z `WHERE`; `SELECT *` w produkcji; funkcja na kolumnie w `WHERE` bez indeksu funkcyjnego.

### C03 · Migracje bez downtime
**Gdy:** zmiana schematu na żywej bazie.
**Twarde:** zawsze `SET lock_timeout` — `ALTER TABLE` bierze ACCESS EXCLUSIVE i zakolejkuje cały ruch; `CREATE INDEX CONCURRENTLY` poza transakcją; NOT NULL przez `CHECK NOT VALID` → `VALIDATE`; sekwencja: migracja dodająca → deploy kodu → w kolejnym wydaniu migracja usuwająca; rollback przetestowany na kopii produkcyjnej.
**Ekspert wie:** Nawet „szybki” `ALTER TABLE` czeka na blokadę za długą transakcją i wtedy blokuje za sobą cały ruch (kolejka blokad) — zawsze `lock_timeout` i ponowienie. Dodanie kolumny ze stałą wartością domyślną jest tanie od Postgresa 11, ale zmiana typu nadal przepisuje tabelę.
**Sprawdź:** `SET lock_timeout='3s'; SET statement_timeout='60s';` + próba na kopii z realnym wolumenem.
**Nie:** usunięcie kolumny w tym samym wdrożeniu, w którym kod przestaje jej używać; migracja bez limitu blokady; `ALTER COLUMN TYPE` na dużej tabeli bez planu.

### C04 · NoSQL (Mongo, Dynamo, Cosmos)
**Gdy:** wybór albo modelowanie w bazie dokumentowej/klucz-wartość.
**Twarde:** projektuj od wzorców dostępu, nie od encji — zmiana wzorca później to przeprojektowanie; klucz partycji decyduje o wszystkim (nierówne partycje bolą trwale); brak transakcji wielodokumentowych to decyzja projektowa, nie szczegół; zagnieżdżanie ma sufit rozmiaru dokumentu.
**Ekspert wie:** W DynamoDB gorąca partycja ma twardy limit przepustowości niezależny od łącznej zarezerwowanej mocy. Klucz partycji o niskiej kardynalności (status, data) robi z tabeli jedno wąskie gardło, a zmiana wzorca dostępu to zwykle nowa tabela i migracja.
**Sprawdź:** wypisz wszystkie zapytania, jakie aplikacja będzie robić, zanim wybierzesz klucz.
**Nie:** NoSQL „bo skaluje" przy danych relacyjnych; skan całej kolekcji jako normalna operacja; joiny robione w aplikacji na tysiącach dokumentów.

### C10 · Backup i odtwarzanie
**Gdy:** kopie zapasowe, DR.
**Twarde:** backup nie istnieje, dopóki nie odtworzysz — test kwartalny z pomiarem RTO; PITR dla baz transakcyjnych; kopie w innym koncie/regionie niż produkcja; szyfrowanie kopii; sprawdź, czy backup obejmuje też konfigurację i sekrety, nie tylko dane.
**Ekspert wie:** Backup, który nie był odtworzony, jest hipotezą. RTO mierz faktycznym czasem przywrócenia z największej bazy; ryzyko siedzi też w kluczach szyfrujących i uprawnieniach — kopia zaszyfrowana kluczem dostępnym tylko z przejętego konta jest bezużyteczna.
**Sprawdź:** odtworzenie do świeżej instancji + zapisany czas trwania i data testu.
**Nie:** backup w tym samym koncie, do którego atakujący ma dostęp; retencja krótsza niż czas wykrycia problemu; brak testu odtworzenia.
