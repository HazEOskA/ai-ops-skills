# Karty: osa-context-lock

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### A01 · Blokada kontekstu
**Gdy:** start roboty na istniejącym systemie, wznowienie, przejęcie zadania.
**Twarde:** ustal repo, branch i SHA startowy zanim cokolwiek napiszesz; sprawdź `git status` zamiast zakładać; wypisz listę plików do dotknięcia przed edycją; plan walidacji i rollbacku przed pierwszą linią.
**Ekspert wie:** Najdroższy błąd startowy to praca na nieaktualnym stanie: lokalny HEAD za origin, inny branch niż zakładany, niezacommitowane zmiany po poprzedniej sesji. Dlatego `git fetch` idzie przed jakimkolwiek wnioskiem o stanie repo, a SHA startowy trafia do raportu, żeby diff dało się później zweryfikować.
**Sprawdź:** `git rev-parse HEAD && git status --porcelain && git fetch && git status -sb`
**Nie:** praca od lokalnego HEAD, gdy wskazano inny commit; „przy okazji poprawiłem"; reformatowanie pliku razem z poprawką.
