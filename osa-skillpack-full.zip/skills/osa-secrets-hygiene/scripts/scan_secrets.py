#!/usr/bin/env python3
"""Heurystyczny skan sekretów w plikach. Wyniki maskowane. Exit 0 = brak trafień, 1 = trafienia, 2 = błąd.

Użycie: python3 scan_secrets.py [ścieżka] [--max-bytes 1000000]
"""
import argparse, re, sys
from pathlib import Path

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".next"}
PATTERNS = [
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Klucz prywatny PEM", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("Token GitHub", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b")),
    ("Token Slack", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b")),
    ("Klucz Google API", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("Klucz Stripe live", re.compile(r"\b[sr]k_live_[0-9A-Za-z]{16,}\b")),
    ("Klucz w stylu sk-", re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}\b")),
    ("Przypisanie sekretu", re.compile(r"(?i)\b(password|passwd|secret|api[_-]?key|token)\b\s*[:=]\s*['\"]([^'\"\s]{8,})['\"]")),
]
PLACEHOLDER = re.compile(r"(?i)(example|changeme|placeholder|your[_-]|xxxx|<.*>|\$\{|process\.env|os\.environ|dummy|test)")


def mask(s):
    s = s.strip()
    return s[:4] + "…" + f"[{len(s)} znaków]" if len(s) > 8 else "…"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default=".")
    ap.add_argument("--max-bytes", type=int, default=1_000_000)
    a = ap.parse_args()
    root = Path(a.path)
    if not root.exists():
        print("BŁĄD: ścieżka nie istnieje", file=sys.stderr)
        sys.exit(2)
    files = [root] if root.is_file() else [p for p in root.rglob("*") if p.is_file() and not (set(p.parts) & SKIP_DIRS)]
    hits, scanned = 0, 0
    for p in files:
        try:
            if p.stat().st_size > a.max_bytes:
                continue
            data = p.read_bytes()
            if b"\0" in data[:2048]:
                continue
            text = data.decode("utf-8", "replace")
        except OSError:
            continue
        scanned += 1
        for n, line in enumerate(text.splitlines(), 1):
            for name, rx in PATTERNS:
                m = rx.search(line)
                if not m:
                    continue
                val = m.group(2) if name == "Przypisanie sekretu" else m.group(0)
                if PLACEHOLDER.search(val) or PLACEHOLDER.search(line) and name == "Przypisanie sekretu":
                    continue
                hits += 1
                print(f"{p}:{n}: {name}: {mask(val)}")
    print(f"WYNIK: przeskanowano {scanned} plików, trafień: {hits}" + ("" if hits else " (heurystyka; brak trafień nie dowodzi braku sekretów)"))
    sys.exit(1 if hits else 0)


if __name__ == "__main__":
    main()
