# Karty: osa-secrets-hygiene

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### F13 · Sekrety
**Gdy:** klucze, tokeny, konfiguracja wrażliwa.
**Twarde:** sejf zamiast zmiennych w repo; federacja OIDC zamiast długoterminowych kluczy w CI; rotacja zaplanowana, nie reaktywna; skan repo i historii gita (sekret usunięty commitem dalej tam jest); sekret w logu to sekret ujawniony; osobne sekrety per środowisko.
**Ekspert wie:** Sekret w historii gita jest ujawniony nawet po usunięciu commita — jedyną naprawą jest rotacja; sekret w logu CI też. Lepszy niż sejf jest brak długoterminowego sekretu: OIDC i Workload Identity dają krótkotrwałe tokeny.
**Sprawdź:** `gitleaks detect --source . --redact` na pełnej historii.
**Nie:** `.env` w repo „tylko na dev"; jeden klucz współdzielony przez środowiska; rotacja dopiero po incydencie.

### H04 · Kryptografia w użyciu
**Gdy:** hasła, szyfrowanie, podpisy, tokeny.
**Twarde:** nie implementuj własnych prymitywów; hasła przez argon2id albo bcrypt z odpowiednim kosztem, nigdy SHA; AES-GCM albo ChaCha20-Poly1305 z unikalnym nonce (powtórzony nonce w GCM łamie poufność); porównania sekretów w czasie stałym; losowość z generatora kryptograficznego, nie z `random()`; klucze rotowane, z wersją w zaszyfrowanych danych.
**Ekspert wie:** Błędy siedzą w użyciu, nie w algorytmie: powtórzony nonce w AES-GCM ujawnia klucz uwierzytelniania, szyfrowanie bez uwierzytelnienia pozwala na modyfikację, a hasło hashowane szybkim hashem łamie się na GPU. Używaj bibliotek wysokiego poziomu (libsodium, `age`).
**Sprawdź:** przegląd użycia bibliotek kryptograficznych + weryfikacja źródła losowości.
**Nie:** szyfrowanie bez uwierzytelnienia; nonce z licznika resetowanego przy restarcie; własna implementacja czegokolwiek z tej listy.
