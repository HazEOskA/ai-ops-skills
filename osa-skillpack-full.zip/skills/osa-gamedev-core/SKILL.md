---
name: "osa-gamedev-core"
description: "Gamedev i symulacja czasu rzeczywistego: pętla gry, stały krok fizyki, ECS, netcode, determinizm, assety, silniki Unity, Godot, Unreal. Użyj przy budowie gry, silnika, symulacji z ticka, multiplayer. Triggers: game, game loop, ECS, physics, netcode, Unity, Godot, Unreal, multiplayer, engine, gra."
---

# Gamedev (rdzeń)

## Procedura

1. **Rdzeń** (`osa-build-gate`): jakie czasowniki gry (gracz robi X, świat robi Y) i na jakim runtime (przeglądarka, natywnie, serwer). Od tego zależy silnik.
2. **Pętla**: stały krok symulacji (fixed timestep) oddzielony od renderowania; interpolacja klatek. Zmienny krok w fizyce = niedeterminizm i błędy.
3. **Determinizm**: seedowany generator, brak zależności od kolejności iteracji nieuporządkowanych struktur, jedna ścieżka aktualizacji. Pozwala na odtwarzanie, testy i sieć z rekoncyliacją.
4. **ECS/dane**: dane ułożone pod dostęp (lokalność pamięci), systemy operują na komponentach. Zanim wybierzesz ECS, sprawdź, czy skala tego wymaga.
5. **Netcode**: serwer autorytatywny, klient przewiduje i rekoncyliuje; wysyłaj wejście, nie stan; projektuj pod utratę pakietów i opóźnienia rzędu 100+ ms, nie pod LAN.
6. **Wydajność**: budżet klatki, profilowanie przed optymalizacją, pooling obiektów, brak alokacji w pętli gorącej.
7. **Assety**: potok importu z walidacją, kompresja, wersjonowanie; duże pliki poza zwykłym git (LFS lub odpowiednik).
8. **Dowód**: uruchom i zagraj/odtwórz scenariusz, zmierz fps i tick (`osa-verify-run`).

## Nie

- Fizyki z `deltaTime` bez ograniczenia.
- Klienta autorytatywnego (cheaty, rozjazdy).
- Silnika własnego, gdy istniejący spełnia rdzeń.

Symulacja badawcza wieloagentowa: `osa-agent-sim-world`.

## Karty (references/cards.md)

- **K01** · Pętla gry i timing — gdy: ruch zależny od klatek, „na szybkim PC gra inaczej"
- **K02** · ECS i architektura — gdy: dużo obiektów, rozrastające się dziedziczenie
- **K03** · Fizyka i kolizje — gdy: przenikanie, tunelowanie, dziwne odbicia
- **K04** · Netcode — gdy: multiplayer
- **K05** · Pipeline assetów — gdy: rozmiar builda, długie ładowanie, chaos w plikach
- **K06** · Wydajność gry — gdy: spadki FPS, zacięcia

Wczytaj tylko karty pasujące do zadania (grep po ID).
