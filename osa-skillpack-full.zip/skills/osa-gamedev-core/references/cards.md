# Karty: osa-gamedev-core

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### K01 · Pętla gry i timing
**Gdy:** ruch zależny od klatek, „na szybkim PC gra inaczej".
**Twarde:** logika na stałym kroku czasowym, renderowanie na zmiennym, z interpolacją — to rozwiązuje większość problemów z determinizmem; akumulator zamiast mnożenia przez delta time we wszystkim; ogranicz maksymalny delta, bo po zatrzymaniu debuggerem obiekty przelecą przez ściany; wejście zbierane niezależnie od kroku logiki.
**Ekspert wie:** Stały krok fizyki z akumulatorem i ograniczonym `dt` (spiral of death przy zwłoce) daje determinizm i powtarzalność. Interpolacja stanu renderowania między krokami usuwa drgania przy różnicy między częstotliwością fizyki a wyświetlacza.
**Sprawdź:** test przy 30, 60 i 144 Hz oraz po sztucznej zwłoce 2 s.
**Nie:** fizyka w klatce renderowania; brak limitu delta; logika zależna od kolejności wywołań aktualizacji.

### K02 · ECS i architektura
**Gdy:** dużo obiektów, rozrastające się dziedziczenie.
**Twarde:** ECS opłaca się przy tysiącach jednostek i chęci utrzymania lokalności pamięci — przy małej grze to narzut bez zysku; kompozycja zamiast dziedziczenia niezależnie od tego, czy używasz ECS; systemy w jawnej, ustalonej kolejności; dane oddzielone od zachowania.
**Ekspert wie:** Wartością ECS jest lokalność danych i iteracja po komponentach w ciągłej pamięci. Przy setkach obiektów i logice bogatszej niż dane często wystarczy zwykła kompozycja, a ECS dokłada koszt narzędzi i debugowania.
**Sprawdź:** profil klatki przy docelowej liczbie jednostek, nie przy dziesięciu.
**Nie:** ECS w prototypie dwuosobowego zespołu; hierarchia klas z siedmioma poziomami; systemy o kolejności zależnej od kolejności rejestracji.

### K03 · Fizyka i kolizje
**Gdy:** przenikanie, tunelowanie, dziwne odbicia.
**Twarde:** szybkie obiekty wymagają wykrywania ciągłego, inaczej przelatują przez cienkie ściany; warstwy i maski kolizji zdefiniowane w tabeli, nie ad hoc; skala świata dopasowana do silnika (bardzo małe i bardzo duże obiekty łamią stabilność solvera); zmiany fizyki wyłącznie w kroku fizyki.
**Ekspert wie:** Tunelowanie to prędkość większa niż grubość collidera na krok — potrzebna ciągła detekcja albo raycast/sweep. Niestabilność stosów bierze się ze zbyt małych lub dużych mas i skali: trzymaj obiekty w skali metrów silnika i stały krok.
**Sprawdź:** test z obiektem o dużej prędkości przy cienkim colliderze.
**Nie:** siła aplikowana w klatce renderowania; collider siatkowy tam, gdzie wystarczy prymityw; skalowanie obiektów zamiast projektowania w skali silnika.

### K04 · Netcode
**Gdy:** multiplayer.
**Twarde:** serwer autorytatywny, klient przewidujący, z rekoncyliacją — klient autorytatywny to gotowe cheaty; wysyłaj wejście, nie stan; interpolacja u obserwatorów, kompensacja opóźnienia u strzelca; projektuj pod utratę pakietów i 150 ms, nie pod LAN; stan gry rozdzielony na to, co musi być spójne, i to, co może się rozjechać.
**Ekspert wie:** Predykcja po stronie klienta wymaga rekoncyliacji: serwer odsyła autorytatywny stan z numerem ostatnio przetworzonego wejścia, a klient odtwarza niepotwierdzone wejścia. Cały ruch projektuj pod utratę i zmianę kolejności pakietów.
**Sprawdź:** test z symulowanym opóźnieniem 150 ms i 5% utraty pakietów.
**Nie:** zaufanie do pozycji przysłanej przez klienta; wysyłanie pełnego stanu świata co klatkę; testy wyłącznie lokalnie.

### K05 · Pipeline assetów
**Gdy:** rozmiar builda, długie ładowanie, chaos w plikach.
**Twarde:** źródła oddzielone od plików importowanych; konwencja nazw i struktura wymuszone skryptem walidującym; import z ustawieniami per typ, nie ręcznie; atlasy i kompresja tekstur per platforma; kontrola wersji z LFS dla binariów; budżet rozmiaru per poziom pilnowany w CI.
**Ekspert wie:** Największe wagi builda to zwykle tekstury i audio w złym formacie kompresji dla platformy. Raport rozmiaru builda per typ zasobu w CI wykrywa regresję, zanim trafi do sklepu (limity rozmiaru pobrania).
**Sprawdź:** raport rozmiaru builda z rozbiciem na typy zasobów, porównywany między wersjami.
**Nie:** tekstury 4K na obiektach tła; assety źródłowe w buildzie; brak walidacji konwencji przy commicie.

### K06 · Wydajność gry
**Gdy:** spadki FPS, zacięcia.
**Twarde:** rozdziel wąskie gardło: CPU (logika, draw calls) czy GPU (fill rate, shadery); zacięcia to zwykle alokacje i GC albo kompilacja shaderów w locie — prekompiluj i używaj puli obiektów; profiluj na najsłabszym docelowym urządzeniu; stabilne 30 klatek bije skaczące 60; budżet klatki rozpisany na systemy.
**Ekspert wie:** Zacięcia (spiki) to inne zjawisko niż niskie FPS — alokacje i GC, ładowanie w locie, kompilacja shaderów — i wymagają profilera klatka po klatce, nie średniej. Pula obiektów i prekompilacja shaderów je usuwają.
**Sprawdź:** profiler klatki na docelowym sprzęcie z zapisanym budżetem per system.
**Nie:** optymalizacja bez profilera; alokacje w pętli aktualizacji; testy wydajności na maszynie deweloperskiej.
