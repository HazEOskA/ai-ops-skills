# Karty: osa-motion-3d-webgl

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### D11 · System animacji
**Gdy:** ruch w interfejsie, easing, mikrointerakcje.
**Twarde:** trzy czasy i trzy krzywe wystarczą — tokeny, nie magiczne liczby; ease-out na wejście, ease-in na wyjście, linear tylko dla ruchu ciągłego; animuj wyłącznie `transform` i `opacity`; stagger max 5–7 elementów; animacja przerywalna; `prefers-reduced-motion` obsłużone globalnie.
**Ekspert wie:** Animacje `transform` i `opacity` działają na kompozytorze i nie wywołują layoutu; animowanie `height`, `top`, `margin` wymusza layout w każdej klatce. `will-change` stosuj punktowo, bo nadmiar tworzy warstwy i zjada pamięć GPU.
**Sprawdź:** Performance z 4× CPU throttling — brak gubionych klatek; test z włączonym reduce motion.
**Nie:** animacja `width`/`top`/`margin`; ruch na ścieżce krytycznej, przez który użytkownik czeka; parallax bez reduce motion.

### D12 · GSAP i scroll
**Gdy:** ScrollTrigger, pinning, scrollytelling.
**Twarde:** jedna oś czasu zamiast wielu triggerów; `scrub` z liczbą, nie `true`; w React wszystko w `gsap.context()` z `revert()` w cleanupie; `ScrollTrigger.refresh()` po zmianie wysokości i po załadowaniu obrazów; `svh`/`dvh` zamiast `vh` na mobile; stan początkowy z `gsap.set`, nie z CSS.
**Ekspert wie:** Najczęstszy błąd w React to brak `revert()` przy odmontowaniu — triggery dublują się przy każdej nawigacji. Drugi to pomiar pozycji przed załadowaniem obrazów i fontów, po którym wszystkie punkty startu są przesunięte: `ScrollTrigger.refresh()` po zdarzeniu ładowania.
**Sprawdź:** `ScrollTrigger.getAll().length` po kilku nawigacjach SPA — nie może rosnąć.
**Nie:** brak cleanupu; pinowanie kontenera bez ustalonej wysokości; treść dostępna wyłącznie przez scroll.

### D13 · Three.js / R3F
**Gdy:** scena 3D, model GLTF, kamera, materiały.
**Twarde:** budżet ustalony przed pierwszą linią; `dpr` ograniczony do 2; GLTF z Draco + tekstury KTX2; `frameloop="demand"` dla scen statycznych; zero alokacji obiektów w `useFrame`; współdzielone materiały; `dispose()` dla zasobów tworzonych ręcznie; scena pauzuje poza viewportem i przy nieaktywnej zakładce.
**Ekspert wie:** W R3F każdy `setState` w `useFrame` to re-render drzewa React co klatkę — mutuj refy. `new THREE.Vector3()` w pętli to presja na GC i mikrozacięcia, a `dispose()` geometrii, materiałów i tekstur nie dzieje się automatycznie.
**Sprawdź:** `npx gltf-transform inspect model.glb`; w konsoli `renderer.info.render.calls` i `.triangles`.
**Nie:** nieograniczone `devicePixelRatio`; model 40 MB bez wskaźnika ładowania; cienie w czasie rzeczywistym ze wszystkich świateł.

### D14 · Budżet WebGL
**Gdy:** 3D klatkuje, grzeje telefon.
**Twarde:** rozstrzygnij CPU czy GPU — zmniejsz okno o połowę, jeśli FPS skoczył, to fill rate; draw calls poniżej 150 desktop / 60 mobile; instancing dla powtarzalnych obiektów; tekstury w formacie kompresowanym GPU; shadery prekompilowane (`renderer.compile`); testuj 5 minut, nie 20 sekund — telefon throttluje termicznie.
**Ekspert wie:** Telefon throttluje termicznie po kilku minutach, więc test 20 sekund na biurku kłamie. Zmniejszenie rozdzielczości renderu o połowę odróżnia fill rate od CPU w kilka sekund, a najtańszą oszczędnością bywa ograniczenie `dpr`.
**Sprawdź:** `renderer.info` przed i po + nagranie Performance na realnym urządzeniu.
**Nie:** optymalizacja shaderów przy 800 draw calls; testy tylko na desktopie; postprocessing stack na mobile.

### D15 · Shadery GLSL
**Gdy:** własny materiał, efekt, noise, distortion.
**Twarde:** najpierw sprawdź, czy CSS albo standardowy materiał nie wystarczy; przenoś obliczenia do vertex shadera; rozszerzaj istniejący materiał (`onBeforeCompile`) zamiast pisać PBR od zera; `mediump` domyślnie na mobile; zamiast `if` używaj `step`/`mix`/`smoothstep`; debug przez kolor.
**Ekspert wie:** Koszt rozgałęzień w shaderze zależy od spójności warpu — `if` nie jest ani zawsze tani, ani zawsze drogi. Częsty problem to precyzja (`mediump` na mobile) w obliczeniach na dużych współrzędnych albo czasie, który po dłuższym działaniu zaczyna dawać artefakty.
**Sprawdź:** `renderer.info.programs.length` (liczba wariantów) + FPS przy pełnoekranowym efekcie.
**Nie:** pętla o zmiennej liczbie iteracji we fragmencie; wszystko w `highp`; efekt bez fallbacku na słabym GPU.

### D16 · Canvas 2D i wizualizacje
**Gdy:** wykres, edytor, rysowanie, dużo elementów.
**Twarde:** powyżej ~1000 elementów DOM/SVG przechodź na canvas; rysuj w jednej pętli `requestAnimationFrame`, nie per zdarzenie; uwzględnij `devicePixelRatio` przy skalowaniu; offscreen canvas dla ciężkich obliczeń; interakcja przez mapę trafień, nie przez iterację po wszystkich obiektach.
**Ekspert wie:** Rozmyty canvas na ekranach retina to brak skalowania o `devicePixelRatio`. Koszt rysowania dominują zmiany stanu i ścieżki, więc grupowanie po stylu i warstwowanie (statyczne tło osobno od dynamiki) daje więcej niż mikrooptymalizacja.
**Sprawdź:** profil klatki przy docelowej liczbie elementów.
**Nie:** przerysowanie całej sceny przy każdym ruchu myszy; canvas bez korekty DPR (rozmyty obraz); brak zwalniania zasobów przy odmontowaniu.

### T01 · Pipeline renderingu
**Gdy:** silnik, własny renderer, optymalizacja grafiki, WebGPU.
**Twarde:** vertex → rasteryzacja → fragment → blending; forward vs deferred (deferred tanio przy wielu światłach, drogo w przezroczystości i MSAA); PBR z energią zachowaną; stan GPU zmieniaj jak najrzadziej (sortuj po materiale); WebGPU daje compute shadery i mniejszy narzut niż WebGL.
**Ekspert wie:** koszt nie leży w trójkątach, tylko w pikselach (overdraw, przezroczystość, rozdzielczość) i w liczbie zmian stanu — dlatego zmniejszenie rozdzielczości renderowania daje więcej niż LOD.
**Sprawdź:** RenderDoc / Spector.js — liczba wywołań, overdraw, czas per pass.
**Nie:** przezroczystość bez sortowania; nowe shadery kompilowane w trakcie gry.

### T02 · Kolor
**Gdy:** „kolory wyglądają inaczej”, HDR, gradienty, obróbka obrazu.
**Twarde:** obliczenia (mieszanie, oświetlenie, skalowanie) w przestrzeni liniowej, prezentacja w sRGB; tekstury koloru jako sRGB, mapy normalnych i danych jako liniowe; szerokie gamuty (Display P3) wymagają oznaczenia profilu; w UI OKLCH daje przewidywalną jasność przy zmianie odcienia.
**Ekspert wie:** ciemne obwódki przy skalowaniu i zbyt ciemne gradienty to niemal zawsze mieszanie w sRGB zamiast liniowo.
**Sprawdź:** gradient czerń→biel i czerwień→zieleń — porównanie mieszania liniowego i sRGB.
**Nie:** mapy normalnych oznaczone jako sRGB; kolory marki zdefiniowane bez przestrzeni barw.
