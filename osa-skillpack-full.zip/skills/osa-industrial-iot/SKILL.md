---
name: "osa-industrial-iot"
description: "IoT, edge i przemysł: MQTT, OTA, ROS, czas rzeczywisty, sensory, OPC UA, PLC, integracja fabryczna, bezpieczeństwo OT. Użyj przy urządzeniach, maszynach, protokołach przemysłowych, robotyce. Triggers: IoT, MQTT, OPC UA, PLC, ROS, edge, OTA, embedded, przemysł, fabryka, SCADA, sensor."
---

# IoT i przemysł

## Procedura

1. **Środowisko realne czy symulowane?** Nie masz dostępu do urządzenia ani maszyny? Powiedz to i pracuj na symulatorze/emulatorze, oznaczając wynik jako `symulowane`. Dowód z symulacji to nie dowód z maszyny (`osa-definition-of-done`).
2. **Rdzeń i ograniczenia**: latencja, determinizm czasowy, zasilanie, pamięć, łączność przerywana. Sprawdź je liczbami z dokumentacji urządzenia, nie zgaduj (`unknown`).
3. **Protokoły**: MQTT (jakość dostarczenia QoS, sesje trwałe, wiadomości zatrzymane, ostatnia wola), OPC UA (model informacji, bezpieczeństwo), Modbus i pokrewne (prosty, bez uwierzytelniania: izoluj sieć). Dobór według karty i dokumentacji sprzętu.
4. **OTA**: podpisane obrazy, rollback przy nieudanej aktualizacji, aktualizacja etapami. Urządzenie w terenie, którego nie da się odzyskać, wymaga szczególnej ostrożności (zgoda: `osa-god-layer-approvals`).
5. **Bezpieczeństwo OT**: segmentacja sieci, brak bezpośredniej ekspozycji do internetu, uwierzytelnianie urządzeń (certyfikaty), aktualizowalność (`osa-security-baseline`). Sterowanie fizyczne = ryzyko dla ludzi: każda komenda zapisu do maszyny za jawną zgodą.
6. **Integracja z IT** (ERP, historian, API gateway): kolejka buforująca przy utracie łączności, idempotentne przetwarzanie (`osa-backend-reliability`).
7. **Dowód**: test na sprzęcie lub symulatorze z zapisem wyników, w tym awarie (odcięcie sieci, zanik zasilania).

## Nie

- Zapisu do sterowników bez potwierdzenia i procedury bezpiecznego zatrzymania.
- Zakładania niezawodnej łączności.
- Domyślnych haseł i otwartych portów.

## Karty (references/cards.md)

- **Z01** · Architektura IoT — gdy: czujniki, telemetria, urządzenia w terenie, monitoring maszyn
- **Z02** · OTA i zarządzanie flotą — gdy: aktualizacja oprogramowania urządzeń w terenie
- **Z03** · Robotyka i ROS — gdy: roboty, manipulatory, pojazdy autonomiczne, symulacja
- **Z04** · Przemysł: OPC UA, PLC, SCADA — gdy: integracja z maszynami, dane z linii produkcyjnej, monitoring stanu maszyn, predykcyjne utrzymanie ruchu
- **Z05** · Edge AI — gdy: model na urządzeniu, kamera z analizą, niska latencja, brak łączności
- **W05** · Niezawodność systemów krytycznych — gdy: maszyny, przemysł, medycyna, pieniądze, bezpieczeństwo ludzi

Wczytaj tylko karty pasujące do zadania (grep po ID).
