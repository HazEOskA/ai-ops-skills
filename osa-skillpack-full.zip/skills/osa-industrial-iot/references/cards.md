# Karty: osa-industrial-iot

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### Z01 · Architektura IoT
**Gdy:** czujniki, telemetria, urządzenia w terenie, monitoring maszyn.
**Twarde:** urządzenie zakłada zerwaną łączność — bufor lokalny i wysyłka po odzyskaniu; MQTT z QoS dobranym do wagi danych, retained dla stanu, LWT (last will) do wykrywania zniknięcia; tożsamość per urządzenie (certyfikat X.509), nigdy wspólny klucz; czas z urządzenia niezaufany — znacznik serwera obok znacznika urządzenia; dane surowe do magazynu, agregaty do dashboardu.
**Ekspert wie:** koszt IoT to nie chmura, tylko obsługa floty w terenie — każda funkcja wymagająca fizycznej wizyty technika jest wielokrotnie droższa niż jej zdalny odpowiednik.
**Sprawdź:** test: urządzenie offline 24 h → powrót → kompletność danych.
**Nie:** wspólne hasło dla wszystkich urządzeń; urządzenie, które traci dane przy braku sieci.

### Z02 · OTA i zarządzanie flotą
**Gdy:** aktualizacja oprogramowania urządzeń w terenie.
**Twarde:** podział A/B partycji z automatycznym powrotem, gdy nowa wersja nie potwierdzi zdrowia; aktualizacje podpisane i weryfikowane na urządzeniu; wdrożenie stopniowe (1% → 10% → 100%) z metryką zdrowia; aktualizacja odporna na zanik zasilania w połowie; inwentarz wersji całej floty.
**Ekspert wie:** jedna zła aktualizacja bez automatycznego powrotu potrafi zamienić tysiące urządzeń w cegły — to jedyny błąd w IoT, którego nie naprawisz zdalnie.
**Sprawdź:** wyłączenie zasilania w trakcie aktualizacji na urządzeniu testowym + powrót po nieudanym starcie.
**Nie:** aktualizacja bez podpisu; wdrożenie na całą flotę naraz.

### Z03 · Robotyka i ROS
**Gdy:** roboty, manipulatory, pojazdy autonomiczne, symulacja.
**Twarde:** ROS 2 z DDS i profilami QoS dopasowanymi do rodzaju danych (czujniki best-effort, komendy reliable); symulacja (Gazebo, Isaac Sim) przed sprzętem, ale luka sim-to-real jest realna; pętle sterowania w czasie rzeczywistym osobno od logiki wysokiego poziomu; układ bezpieczeństwa (e-stop) sprzętowy, niezależny od oprogramowania.
**Ekspert wie:** w robotyce najwięcej czasu zjadają kalibracja, synchronizacja czasu czujników i transformacje układów współrzędnych (tf) — nie algorytmy planowania.
**Sprawdź:** `ros2 topic hz` i opóźnienia na kluczowych tematach + test e-stopu.
**Nie:** zatrzymanie awaryjne realizowane tylko programowo; model AI bezpośrednio sterujący aktuatorami bez warstwy limitów.

### Z04 · Przemysł: OPC UA, PLC, SCADA
**Gdy:** integracja z maszynami, dane z linii produkcyjnej, monitoring stanu maszyn, predykcyjne utrzymanie ruchu.
**Twarde:** odczyt z maszyn przez OPC UA (model informacyjny, bezpieczeństwo, subskrypcje) albo przez bramkę protokołów (Modbus, Profinet, EtherNet/IP); sieć OT oddzielona od IT (model Purdue, strefy i przepływy wg IEC 62443), dane wychodzą przez DMZ, nic nie wchodzi bez kontroli; system IT tylko czyta — zapis do PLC wyłącznie przez procedurę zatwierdzoną przez automatyka i utrzymanie ruchu; znaczniki czasu z PLC synchronizowane.
**Ekspert wie:** w predykcyjnym utrzymaniu ruchu najcenniejsze dane to dziennik awarii i napraw spisany przez ludzi z hali — bez etykiet awarii model wibracji nie ma czego się nauczyć; zacznij od monitoringu warunków i progów, zanim zbudujesz ML.
**Sprawdź:** mapa przepływów danych OT→IT z zaporą i kierunkiem + test, że z sieci IT nie da się zapisać do sterownika.
**Nie:** chmura z bezpośrednim dostępem do PLC; zmiana logiki sterownika bez automatyka i bez okna serwisowego; AI podejmujące decyzje o zatrzymaniu linii bez zatwierdzenia człowieka.

### Z05 · Edge AI
**Gdy:** model na urządzeniu, kamera z analizą, niska latencja, brak łączności.
**Twarde:** budżet: pamięć, moc, temperatura, latencja — wybór modelu od budżetu, nie odwrotnie; kwantyzacja (int8) i dedykowane runtime'y (TensorRT, ONNX Runtime, TFLite, OpenVINO) z pomiarem utraty jakości; wersjonowanie modelu jak firmware (OTA, powrót); zbieranie próbek trudnych przypadków do douczania.
**Ekspert wie:** na brzegu model degraduje się przez zmianę warunków (kurz na obiektywie, sezonowe oświetlenie, nowa partia produktu) — monitoring rozkładu wejść jest ważniejszy niż sam model.
**Sprawdź:** latencja p99 i dokładność na docelowym urządzeniu po kwantyzacji, w docelowej temperaturze.
**Nie:** benchmark tylko na stacji roboczej; model bez mechanizmu aktualizacji.

### W05 · Niezawodność systemów krytycznych
**Gdy:** maszyny, przemysł, medycyna, pieniądze, bezpieczeństwo ludzi.
**Twarde:** analiza trybów awarii (FMEA) przed implementacją; stan bezpieczny zdefiniowany dla każdej awarii (fail-safe vs fail-operational); redundancja niezależna (inny dostawca, inna ścieżka); ślad audytowy każdej decyzji automatu; człowiek zatwierdza działania nieodwracalne.
**Ekspert wie:** redundancja z tymi samymi komponentami ma wspólne tryby awarii — dwa identyczne serwery z tym samym błędem padają razem.
**Sprawdź:** tabela FMEA: tryb awarii → skutek → wykrywalność → reakcja → test tej reakcji.
**Nie:** AI sterujące fizycznym procesem bez twardych limitów poza modelem; brak ręcznego obejścia automatu.
