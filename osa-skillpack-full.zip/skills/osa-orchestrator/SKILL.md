---
name: "osa-orchestrator"
description: "Spis treści i router skilli OsaTechGPT: wybiera, które skille wczytać do zadania, zamiast czytać wszystkie. Użyj jako PIERWSZY na każdym zadaniu technicznym. Triggers: route, which skill, orchestrate, start task, zadanie, zbuduj, napraw, wdróż, zaplanuj."
---

# OSA Orchestrator (spis treści skilli)

Wersja paczki i status: patrz `registry.json` (status TARGET/UNPROVEN: routing nie był mierzony).

## Protokół (5 kroków, w tej kolejności)

1. **Zawsze aktywne:** `osa-honesty-contract` i `osa-context-lock` (krótkie; wczytaj je, jeśli jeszcze nie są w kontekście).
2. **Sklasyfikuj zadanie** jednym z trzech typów:
   - **BUDOWA / ZMIANA / WDROŻENIE** (wynik to działająca rzecz) → najpierw `osa-build-gate`. Na koniec `osa-verify-run`, `osa-definition-of-done`, `osa-report-format`.
   - **PYTANIE O WIEDZĘ** → bez bramki. Wybierz 1 skill z indeksu po opisie.
   - **AWARIA** → `osa-incident-response` i `osa-debug-bisect`.
3. **Sprawdź trasy** (tabela ROUTES niżej). Trafia typ zadania → wczytaj skille z kolumny w podanej kolejności.
4. **Nie ma trasy → wybierz z INDEX po opisie.** Maksymalnie 3 skille naraz na start. Kolejne dokładaj, gdy zadanie ich dotknie.
5. **Skill z kartami** (`references/cards.md`): nie czytaj całości. `grep -n "^### <ID>" references/cards.md`, potem zakres linii.

Nic nie pasuje: nie naciągaj. Pracuj na `osa-honesty-contract` + `osa-build-gate` i powiedz „brak skilla dla: X”. To sygnał do `osa-skill-authoring`.

## Kolejność ważności (przy konflikcie wygrywa wyższy)

1. Instrukcja Osy w tej rozmowie
2. `osa-god-layer-approvals` (AI proponuje, Osa zatwierdza; push, deploy, koszty, sekrety)
3. `osa-honesty-contract`
4. `osa-build-gate`
5. Skille domenowe

## Trasy (wygenerowane z pakietów osa-godmode v2)

<!-- ROUTES:START -->
| Typ zadania | Skille (w tej kolejności) | Karty |
|---|---|---|
| Narzędzie / dashboard z AI | osa-build-gate → osa-architecture-lock → osa-cloud-decision-finops → osa-llm-system-design → osa-agent-design → osa-agent-tools-mcp → osa-test-strategy → osa-mvp-solo-builder | A03 A07 F01 G01 G06 G07 I01 M01 |
| Agent, który zmienia kod | osa-build-gate → osa-god-layer-approvals → osa-agent-design → osa-agent-tools-mcp → osa-ai-guardrails-sandbox → osa-security-baseline → osa-change-review → osa-cicd-iac → osa-test-strategy | G06 G07 G08 G09 H05 I02 F09 W03 |
| Nowy SaaS od zera | osa-build-gate → osa-mvp-solo-builder → osa-api-contract → osa-authz-multitenancy → osa-cloud-decision-finops → osa-cicd-iac → osa-security-baseline | M01 M03 A05 B01 B07 B16 F01 F09 H01 |
| Deploy na produkcję | osa-god-layer-approvals → osa-cicd-iac → osa-secrets-hygiene → osa-observability-slo → osa-postgres-data → osa-deploy-validation → osa-git-discipline | F09 F13 F14 C03 J05 I05 |
| Migracja systemu / danych | osa-god-layer-approvals → osa-repo-intake → osa-postgres-data → osa-deploy-validation → osa-distributed-systems | A06 C03 J05 C10 P03 |
| Awaria / „nie działa” | osa-repo-intake → osa-incident-response → osa-debug-bisect → osa-backend-reliability → osa-cloud-decision-finops | J01 I11 B08 F10 Q02 |
| Wydajność | osa-backend-reliability → osa-postgres-data → osa-debug-bisect → osa-domain-library → osa-web-perf-a11y-seo | B08 C02 N04 O01 D08 |
| Przegląd bezpieczeństwa | osa-security-baseline → osa-authz-multitenancy → osa-ai-guardrails-sandbox | H01 H02 H03 H05 B07 G09 |
| Pipeline danych / ML | osa-data-pipelines-quality → osa-domain-library → osa-evals | C06 C08 G13 G14 U01 |
| Gra / symulacja / świat agentów | osa-agent-sim-world → osa-gamedev-core → osa-distributed-systems → osa-domain-library → osa-test-strategy | K01 K02 P01 O02 W02 |
| Integracja przemysłowa (fabryka, maszyny) | osa-industrial-iot → osa-domain-library → osa-incident-response → osa-security-baseline | Z01 Z04 X01 J04 H06 |
| Własny język / DSL / runtime | osa-domain-library → osa-agent-design → osa-test-strategy | R01 R02 R04 W02 |
<!-- ROUTES:END -->

## Indeks skilli

<!-- INDEX:START -->
**Rdzeń pracy (proces)**

| Skill | Kiedy |
|---|---|
| `osa-context-lock` | Blokada kontekstu na starcie: repo, branch, SHA, git status, lista plików do dotknięcia, plan walidacji i rollbacku przed pierwszą edycją. |
| `osa-honesty-contract` | Kontrakt prawdy i niepewności: zero zgadywania, zgoda tylko z powodem, bezpiecznik Zakładam/Niepewne/Pęka jeśli, kotwica //osa. |
| `osa-build-gate` | Bramka budowy przed pierwszym plikiem: czasowniki rdzenia, inwentarz narzędzi, istniejący projekt, mapa i werdykt BUDUJĘ albo STOP. |
| `osa-scope-guard` | Granica zakresu: lista plików przed edycją, po edycji porównanie z git; plik spoza listy to naruszenie. |
| `osa-verify-run` | Uruchomienie z dowodem: komenda, exit code, wynik i poziom na drabinie dowodów zapisane jako blok dowodowy. |
| `osa-definition-of-done` | Definicja „gotowe” oparta na dowodzie: GOTOWE tylko gdy każdy czasownik rdzenia ma dowód z uruchomienia, inaczej CZĘŚCIOWE. |
| `osa-report-format` | Format raportu końcowego Osy: tabela czasowników rdzenia i siedem sekcji od Root Cause po Next Smallest Task. |
| `osa-god-layer-approvals` | Warstwa zatwierdzeń (AI proponuje, Osa zatwierdza): push, deploy, migracje, koszty, sekrety, force, usuwanie i zmiana zakresu wymagają jawnej zgody. |
| `osa-session-handoff` | Zapis sesji do sessions/YYYY-MM-DD-nazwa.md i wznowienie: ustalone, otwarte, rozjazdy, następny krok. |
| `osa-gmail-draft-log` | Dziennik pracy przez szkice Gmail: jeden szkic na ukończony krok i jeden zbiorczy szkic raportu dziennego. |
| `osa-repo-intake` | Przejęcie cudzego lub nieznanego repo: stan git, stack, komendy build i test, mapa struktury i pierwsze ryzyka, zanim cokolwiek zmienisz. |
| `osa-architecture-lock` | Decyzja architektoniczna zapisana jako ADR przed budową: opcje, wybór, koszt wyjścia, warunek rewizji; wybór technologii i granice modułów. |
| `osa-git-discipline` | Dyscyplina git i monorepo: małe commity, jasne komunikaty, brak force, brak push bez zgody, wersjonowanie i zależności. |
| `osa-skill-authoring` | Tworzenie i utrzymanie skilli OsaTechGPT: format SKILL.md, opis, rejestr, regeneracja indeksu orkiestratora, walidacja. |
| `osatechgpt-product-factory` (zewnętrzny) | Strukturalny workflow Product Factory dla projektów OsaTechGPT: odzyskiwanie kontekstu, plan architektury, komendy, walidacja, sprawdzenie deployu, podsumowanie z jednym krokiem. |

**Jakość, bezpieczeństwo, operacje**

| Skill | Kiedy |
|---|---|
| `osa-change-review` | Przegląd zmiany kodu (własnej lub cudzej): zgodność z zakresem, poprawność, testy, ryzyko, rollback, z werdyktem opartym na dowodzie. |
| `osa-debug-bisect` | Diagnoza błędu metodą dowodu: odtworzenie, zawężenie (git bisect, minimalny przypadek), hipoteza sprawdzona pomiarem, poprawka i test regresyjny. |
| `osa-refactor-safe` | Bezpieczny refactor i dług techniczny: testy charakteryzujące najpierw, małe kroki bez zmiany zachowania, dowód równoważności. |
| `osa-test-strategy` | Strategia testów: co testować, na jakim poziomie, testy własności i fuzzing, kryteria, że test w ogóle coś dowodzi. |
| `osa-deploy-validation` | Walidacja wdrożenia: przed (build, konfiguracja, migracje, rollback), po (smoke test HTTP, logi, metryki) i decyzja rollback. |
| `osa-incident-response` | Reakcja na incydent produkcyjny: ograniczenie skutków, komunikacja, diagnoza, przywrócenie, postmortem bez szukania winnych. |
| `osa-secrets-hygiene` | Higiena sekretów: nigdy w czacie, kodzie ani historii git; skan repo, rotacja po wycieku, zmienne środowiskowe i menedżery sekretów. |
| `osa-security-baseline` | Bazowe bezpieczeństwo: model zagrożeń, uwierzytelnianie, wejście od użytkownika, zależności, kryptografia, kontrola cudzego kodu. |

**AI, agenty, symulacja**

| Skill | Kiedy |
|---|---|
| `osa-agent-design` | Projektowanie agentów AI: pętla decyzji, narzędzia, pamięć, planowanie, warunki stopu, tryby awarii i koszt. |
| `osa-agent-tools-mcp` | Narzędzia dla agentów i serwery MCP: kontrakt narzędzia, schematy, idempotencja, błędy czytelne dla modelu, uprawnienia. |
| `osa-llm-system-design` | Projekt systemu opartego na LLM: dobór modelu, prompty, kontekst, wyjście strukturalne, koszt, opóźnienia, cache, fallbacki. |
| `osa-evals` | Ewaluacja systemów AI i skilli: zestaw przypadków, kryteria, baseline, uruchomienie z i bez, niezależna ocena, próg zaliczenia. |
| `osa-rag` | Systemy RAG i wyszukiwanie: chunkowanie, embeddingi, wyszukiwanie hybrydowe, reranking, cytowanie, ewaluacja retrieval osobno od generacji. |
| `osa-ai-guardrails-sandbox` | Bezpieczeństwo systemów AI: wstrzyknięcie promptu, izolacja wykonania kodu agenta (sandbox), najmniejsze uprawnienia, limity, filtrowanie wyjścia. |
| `osa-proof-governance` | Zarządzanie twierdzeniami: status TARGET, HYPOTHESIS, UNPROVEN, VERIFIED; deklaracja SOTA tylko z benchmarkiem, baseline, metryką i powtarzalnością. |
| `osa-agent-sim-world` | Symulacja wieloagentowa i świat emergentny: determinizm, pętla ticków, dziennik zdarzeń, pamięć agentów, metryki emergencji, ablacje, hipotezy. |

**Platforma i infrastruktura**

| Skill | Kiedy |
|---|---|
| `osa-cloud-decision-finops` | Wybór chmury i runtime'u oraz koszty (FinOps): dopasowanie do czasowników rdzenia, koszt jako liczba z cennika, budżety i alerty, lock-in. |
| `osa-gcp-cloudrun` | Google Cloud i Cloud Run: serwisy kontenerowe, IAM, sekrety w Secret Manager, konfiguracja skalowania, Cloud Build, logi i wdrożenie z rollbackiem. |
| `osa-edge-vercel-cloudflare` | Wdrożenia frontendu i edge: Vercel, Cloudflare Workers, Pages, D1, R2, KV, cache CDN, DNS, zmienne środowiskowe, limity funkcji. |
| `osa-containers-docker` | Kontenery i Docker: Dockerfile, obrazy minimalne, PID 1 i sygnały, cgroups i limity, namespaces, Compose, bezpieczeństwo obrazu. |
| `osa-cicd-iac` | CI/CD i infrastruktura jako kod: pipeline z bramkami, powtarzalne buildy, Terraform i pliki stanu, środowiska, wydania i rollback. |
| `osa-observability-slo` | Obserwowalność i SLO: logi strukturalne, metryki, ślady, alerty na objawy, budżet błędów, runbooki, pojemność. |

**Backend i dane**

| Skill | Kiedy |
|---|---|
| `osa-api-contract` | Projekt API i kontrakty: zasoby, kody błędów, wersjonowanie, paginacja, idempotencja, webhooki, kompatybilność wsteczna, dokumentacja OpenAPI. |
| `osa-backend-reliability` | Niezawodność backendu: kolejki i joby, timeouty, retry, backpressure, cache, transakcje, współbieżność, wydajność zapytań i usług. |
| `osa-postgres-data` | Bazy danych, głównie PostgreSQL: projekt schematu, migracje bez przestoju, indeksy, EXPLAIN, pule połączeń, transakcje, kopie zapasowe i odtwarzanie. |
| `osa-authz-multitenancy` | Autoryzacja i wielodostępność: uwierzytelnianie vs autoryzacja, sesje, tokeny, role, izolacja tenantów, RLS, testy uprawnień. |
| `osa-data-pipelines-quality` | Potoki danych i jakość: ETL/ELT, przetwarzanie wsadowe i strumieniowe, hurtownie, idempotentne ładowanie, testy jakości danych, lineage. |
| `osa-distributed-systems` | Systemy rozproszone: spójność, replikacja, konsensus, zegary, partycjonowanie, sagi, split-brain, kompromis CAP/PACELC z liczbami. |

**Frontend, produkt, gry**

| Skill | Kiedy |
|---|---|
| `osa-frontend-architecture` | Architektura frontendu: React i Next.js, stan, dane z serwera, formularze, routing, komponenty, TypeScript, testowanie UI. |
| `osa-web-perf-a11y-seo` | Wydajność stron, dostępność i SEO: Core Web Vitals, obrazy i czcionki, semantyka HTML, klawiatura i czytniki ekranu, metadane i indeksowanie. |
| `osa-motion-3d-webgl` | Animacje, 3D i grafika w przeglądarce: Three.js, WebGL i WebGPU, shadery, wydajność klatek, GSAP, scroll-driven, potok renderingu i kolor. |
| `osa-premium-ui-style` | Styl interfejsu premium: system projektowy, typografia, rytm i odstępy, kolor, hierarchia, mikrointerakcje, spójność. |
| `osa-mvp-solo-builder` | Produkt i MVP dla solo buildera: cięcie zakresu, specyfikacja, cennik, analityka, wzrost, decyzje produktowe, kolejność pracy jednej osoby. |
| `osa-gamedev-core` | Gamedev i symulacja czasu rzeczywistego: pętla gry, stały krok fizyki, ECS, netcode, determinizm, assety, silniki Unity, Godot, Unreal. |

**Specjalistyczne**

| Skill | Kiedy |
|---|---|
| `osa-industrial-iot` | IoT, edge i przemysł: MQTT, OTA, ROS, czas rzeczywisty, sensory, OPC UA, PLC, integracja fabryczna, bezpieczeństwo OT. |
| `osa-domain-library` | Biblioteka 13 domen specjalistycznych: mobile, web3, algorytmy, OS, kompilatory, sieci, media, data science, HPC i GPU, metody formalne, ERP, prawo. |
<!-- INDEX:END -->

## Rozszerzanie (bez limitu liczby skilli)

Nowy skill = folder `<nazwa>/SKILL.md` z frontmatter (patrz `osa-skill-authoring`), wpis w `registry.json` (grupa), `python3 osa-skill-authoring/scripts/build_index.py <katalog>`, potem `validate_skills.py`. Skill spoza rejestru pojawi się w grupie „Inne”.

## Czego ten skill nie robi

Nie wykonuje pracy, nie zastępuje skilli domenowych, nie gwarantuje, że wybrany skill jest właściwy. Poprawność routingu jest niezmierzona: jeśli trasa poszła obok, popraw wpis w ROUTES (`src/registry.json`, `route_extras`) i zapisz przypadek.
