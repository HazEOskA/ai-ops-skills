# Karty: osa-backend-reliability

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### B04 · Idempotencja i „exactly-once"
**Gdy:** retry, duplikaty, płatności, webhooki przychodzące, kolejki.
**Twarde:** exactly-once delivery nie istnieje — jest at-least-once plus idempotentne przetwarzanie; klucz idempotencji z UNIQUE w bazie; zapis klucza w tej samej transakcji co efekt; powtórka zwraca zapisany wynik; ten sam klucz z innym payloadem to 409; efekty zewnętrzne przez outbox; DLQ z alertem.
**Ekspert wie:** Klucz idempotencji wiąż z hashem żądania, nie tylko z nagłówkiem: ten sam klucz z innym payloadem to błąd klienta (409/422), a nie powtórka. Klucz musi też przetrwać dłużej niż najdłuższy retry klienta lub providera (dla webhooków płatniczych bywa to wiele dni).
**Sprawdź:** `seq 5 | xargs -P5 -I{} curl -sS -X POST -H "Idempotency-Key: k1" -d @p.json $URL` → jeden rekord w bazie.
**Nie:** SELECT sprawdzający istnienie przed INSERT; wysyłka maila wewnątrz transakcji; kasowanie kluczy przed końcem okna retry providera.

### B05 · Współbieżność i transakcje
**Gdy:** race condition, podwójny zapis, ujemny stan, deadlock.
**Twarde:** najpierw usuń wyścig zamiast nim zarządzać (`UPDATE ... WHERE qty >= 1` + sprawdzenie rowcount); niezmiennik chroni constraint w bazie, nie `if` w kodzie; optimistic lock przy niskiej kontencji, `FOR UPDATE` przy wysokiej; globalnie spójna kolejność blokad; zero I/O zewnętrznego w transakcji.
**Ekspert wie:** Domyślny poziom izolacji Postgresa (READ COMMITTED) nie chroni przed lost update we wzorcu odczyt–zmiana–zapis. Naprawą jest atomowy UPDATE z warunkiem, `SELECT … FOR UPDATE` albo SERIALIZABLE z obsługą błędu 40001 i ponowieniem; podniesienie izolacji bez retry zamienia cichy błąd w głośny, ale go nie usuwa.
**Sprawdź:** `ab -n 200 -c 50 ...` na spornym zasobie → dokładnie jeden sukces, niezmiennik trzyma.
**Nie:** `SELECT` → `if` → `UPDATE`; lock w pamięci procesu przy wielu instancjach; Redis-lock bez fencing tokena.

### B06 · Cache i inwalidacja
**Gdy:** stale data, przeciążenie bazy, dodawanie cache.
**Twarde:** najpierw napraw zapytanie, cache to drugie źródło prawdy; klucz zawiera wersję i identyfikator tenanta/użytkownika; TTL z jitterem; ochrona przed stampede na gorących kluczach; awaria cache to degradacja, nie awaria; hit ratio monitorowany.
**Ekspert wie:** Najgroźniejszy błąd cache to nie brak trafień, tylko klucz bez kontekstu autoryzacji — odpowiedź jednego użytkownika serwowana drugiemu. Drugi w kolejce to thundering herd po wygaśnięciu gorącego klucza (coalescing żądań albo wcześniejsze odświeżanie z jitterem).
**Sprawdź:** `redis-cli INFO stats | grep keyspace_` oraz odpowiedź serwisu przy wyłączonym Redisie.
**Nie:** dane per-user pod globalnym kluczem (to wyciek, nie bug wydajności); `FLUSHALL` przy deployu; cache bez pomiaru trafień.

### B08 · Triage wydajności
**Gdy:** „jest wolno", rosnące p95, timeouty.
**Twarde:** bez p50/p95/p99 pracujesz na anegdocie; zawęź warstwę zanim zaczniesz zmieniać; kolejność podejrzanych: N+1, brak indeksu, wysycona pula połączeń, synchroniczne wywołanie zewnętrzne, blokujące I/O w event loopie, GC; profiluj zamiast czytać kod; jedna zmiana na pomiar.
**Ekspert wie:** Wysokie p99 przy niskim p50 to prawie zawsze kolejkowanie (pula połączeń, wątków, GC, blokada), a nie wolny kod — patrz na czas oczekiwania na zasób, nie na czas wykonania. Po dodaniu replik wąskim gardłem zwykle staje się wspólna baza.
**Sprawdź:** `k6 run` przed i po; `SELECT query, mean_exec_time FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 15;`
**Nie:** optymalizacja na średniej; dokładanie replik jako pierwsza reakcja; zwiększanie puli połączeń na wolną bazę.

### B09 · Odporność na awarie
**Gdy:** zależność pada, kaskada, wiszące żądania.
**Twarde:** timeout na każdym kliencie; budżet czasu maleje w dół łańcucha; retry tylko dla idempotentnych i błędów przejściowych, z jitterem, max 3; circuit breaker z metryką stanu; bulkhead per zależność; degradacja zdefiniowana jawnie; load shedding zamiast timeoutów dla wszystkich.
**Ekspert wie:** Retry bez budżetu wzmacnia awarię: trzy warstwy po trzy próby dają 27 wywołań na jedno żądanie do już chorej zależności. Potrzebny jest jeden punkt retry, budżet retry jako procent ruchu i circuit breaker, który ten ruch odcina.
**Sprawdź:** odetnij zależność (`toxiproxy` albo stop kontenera) i zmierz czas odpowiedzi — ma być szybki, nie timeout. Powtórz z opóźnieniem 5 s zamiast zerwania.
**Nie:** retry na trzech warstwach naraz; readiness probe sprawdzający zewnętrzne API; traktowanie timeoutu jako „nie wykonało się".

### B10 · Zadania w tle i cron
**Gdy:** harmonogram, długie zadania, przetwarzanie asynchroniczne.
**Twarde:** cron w wielu instancjach potrzebuje locka (advisory lock albo leader election); zadanie musi być wznawialne i idempotentne; limit czasu wykonania; osobna pula zasobów od ruchu użytkownika; alert na brak wykonania, nie tylko na błąd.
**Ekspert wie:** Najczęstsza cicha awaria crona to zadanie, które przestało się odpalać (zmiana harmonogramu, wyłączony worker, wygasły token). Monitoruj czas ostatniego udanego wykonania z alertem na jego brak, nie tylko błędy; drugi problem to nakładanie się uruchomień, gdy poprzednie jeszcze trwa.
**Sprawdź:** uruchom dwie instancje równolegle — zadanie ma wykonać się raz.
**Nie:** cron bez locka; zadanie bez limitu czasu blokujące następne uruchomienie; brak alertu na „nie odpaliło się w ogóle" (to najczęstsza cicha awaria).

### B11 · Kolejki i brokery
**Gdy:** SQS, Pub/Sub, RabbitMQ, Kafka, przetwarzanie asynchroniczne.
**Twarde:** dobierz po gwarancjach, nie po modzie — kolejka robocza to nie log zdarzeń; ack dopiero po przetworzeniu; visibility timeout dłuższy niż realny czas przetwarzania; DLQ obowiązkowa z alertem na głębokość i wiek najstarszej wiadomości; kolejność jest gwarantowana tylko w obrębie partycji/sesji.
**Ekspert wie:** Kolejka nie ma dna: producent szybszy od konsumenta to rosnące opóźnienie, aż komunikaty przestają mieć sens biznesowy. Potrzebna jest metryka wieku najstarszej wiadomości i polityka (odrzucenie, TTL, backpressure); „trucizna” (wiadomość zawsze failująca) blokuje partycję, jeśli nie ma DLQ i limitu prób.
**Sprawdź:** metryka wieku najstarszej wiadomości i głębokości DLQ na dashboardzie.
**Nie:** Kafka do prostej kolejki zadań; ack przed przetworzeniem; założenie globalnej kolejności zdarzeń.

### B13 · Rate limiting
**Gdy:** ochrona API, nadużycia, koszty.
**Twarde:** limituj po tożsamości, nie po IP (NAT łączy tysiące użytkowników); sliding window albo token bucket, nie licznik na sztywną minutę; zwracaj `429` z `Retry-After` i nagłówkami limitu; osobne limity dla operacji drogich; limit globalny jako ostatnia linia.
**Ekspert wie:** Limit po IP karze wszystkich za jednym NAT-em i nie chroni przed atakiem rozproszonym. Limituj po tożsamości (klucz, konto, tenant), a dla logowania i resetu hasła dodatkowo po koncie docelowym, bo credential stuffing rozkłada próby na tysiące adresów.
**Sprawdź:** `hey -n 500 -c 20 $URL | grep 429` — limit ma się odpalać przewidywalnie.
**Nie:** limit tylko po IP; brak `Retry-After`; ten sam limit dla logowania i dla odczytu listy.

### P07 · Awarie częściowe
**Gdy:** „czasem działa”, timeouty, zawieszone żądania.
**Twarde:** w systemie rozproszonym nie da się odróżnić wolnego węzła od martwego — timeout to decyzja, nie fakt; timeout nie oznacza, że operacja się nie wykonała; wykrywanie awarii przez heartbeat z progiem akceptującym fałszywe alarmy; projektuj pod „szare awarie” (węzeł odpowiada, ale źle lub wolno).
**Ekspert wie:** najgroźniejsza jest metastabilność — system po krótkim przeciążeniu nie wraca do normy, bo retry i kolejki podtrzymują przeciążenie; wyjście to shedding i limity retry, nie więcej zasobów.
**Sprawdź:** wstrzyknięcie opóźnienia (nie awarii) 5 s na jednej zależności i obserwacja całego systemu.
**Nie:** retry bez budżetu; health check, który mówi „OK”, gdy proces żyje, ale nie obsługuje żądań.
