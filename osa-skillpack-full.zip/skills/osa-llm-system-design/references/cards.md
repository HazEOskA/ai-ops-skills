# Karty: osa-llm-system-design

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### G01 · Architektura systemu z LLM
**Gdy:** feature oparty o model, „dodajmy AI".
**Twarde:** sprawdź, czy LLM jest właściwym narzędziem — klasyfikacja przy dużym wolumenie jest tańsza i mierzalna klasycznie; zacznij od najmocniejszego modelu, żeby poznać sufit jakości, potem schodź; wyjście strukturalne wszędzie, gdzie coś ma być przetworzone maszynowo; streamuj, bo pierwszy token decyduje o odbiorze; koszt licz per żądanie z historią, retry i narzędziami.
**Ekspert wie:** Największy zysk jakości zwykle daje lepszy kontekst i przykłady, nie większy model; największy zysk kosztu — cache promptu, krótszy kontekst i tańszy model do prostych kroków, po zmierzeniu na własnym zestawie.
**Sprawdź:** tabela na własnym zestawie: jakość / p95 latencji / koszt na żądanie, dla 2–3 modeli.
**Nie:** wybór modelu po benchmarku z internetu; parsowanie prozy regexem; cała historia rozmowy wysyłana bez przycinania.

### G02 · Prompt jako kontrakt
**Gdy:** prompt produkcyjny.
**Twarde:** prompt to kod — repo, wersja, review, testy; schemat wyjścia zdefiniowany i walidowany po stronie kodu, z zachowaniem przy niezgodności; przykłady biją instrukcje, dwa dobre wystarczą; część stała na początku (cache promptów); jedna zmiana na eksperyment.
**Ekspert wie:** Zmiana modelu bez ponownego uruchomienia ewaluacji to zmiana kodu bez testów: prompty dobrane pod jeden model często zachowują się inaczej na następnym. Trzymaj wersję promptu i wersję modelu razem z wynikiem.
**Sprawdź:** odsetek odpowiedzi niezgodnych ze schematem na zestawie testowym.
**Nie:** prompt edytowany na produkcji bez historii; model jako gwarant formatu zamiast walidatora; zmiana promptu i modelu jednocześnie.

### G10 · Koszt i latencja LLM
**Gdy:** rachunek za model, wolne odpowiedzi.
**Twarde:** licz per żądanie, nie per token — prompt systemowy razy wolumen to realny koszt; cache promptu dla stałych prefiksów; routing po trudności zadania obniża koszt, ale dokłada złożoność; streaming zmienia odbiór latencji bardziej niż realne przyspieszenie; przycinaj historię i wyniki narzędzi; batch tam, gdzie nie potrzeba odpowiedzi natychmiast.
**Ekspert wie:** Koszt dominuje zwykle kontekst wejściowy powtarzany w każdym kroku pętli agenta, nie odpowiedzi. Cache prefiksu i streszczanie historii często obniżają go mocniej niż przejście na tańszy model.
**Sprawdź:** koszt dzienny per funkcja i p95 czasu do pierwszego tokenu.
**Nie:** brak limitu długości wejścia; retry bez limitu na 429; mocny model do zadań, które udźwignie tani.

### G11 · Fine-tuning
**Gdy:** ktoś proponuje douczenie modelu.
**Twarde:** to prawie nigdy nie jest pierwszy krok — najpierw prompt, przykłady, RAG; fine-tuning uczy formy i stylu, nie dodaje wiedzy faktograficznej; potrzebujesz spójnych danych i zestawu oceniającego przed startem; model dostrojony trzeba utrzymywać przy każdej zmianie modelu bazowego; policz koszt utrzymania, nie tylko trening.
**Ekspert wie:** Douczenie zmienia zachowanie i format, słabo wprowadza nowe fakty. Jeśli problemem jest wiedza — RAG; jeśli styl albo sztywny format i masz setki dobrych przykładów, dopiero wtedy warto, po porównaniu z promptem few-shot.
**Sprawdź:** porównanie z dobrze zrobionym promptem plus RAG na tym samym zestawie.
**Nie:** fine-tuning zamiast RAG dla wiedzy firmowej; trening na danych o niespójnej jakości; brak zestawu oceniającego przed rozpoczęciem.

### G12 · Serwowanie modeli
**Gdy:** własny model, GPU, inferencja.
**Twarde:** batching decyduje o przepustowości bardziej niż model GPU; pamięć GPU to twardy limit — policz wagi plus KV cache plus zapas; kwantyzacja obniża koszt kosztem jakości, zmierz oba; zimny start ładowania modelu liczony w minutach, więc skalowanie do zera zwykle odpada; kolejka z limitem zamiast odrzucania na poziomie GPU.
**Ekspert wie:** Pamięć KV cache rośnie liniowo z długością kontekstu i liczbą równoległych żądań, więc przy długim kontekście limitem jest pamięć, nie obliczenia. Continuous batching i paged attention (vLLM) podnoszą przepustowość bez zmiany modelu.
**Sprawdź:** przepustowość i p99 przy realnym rozkładzie długości wejścia, nie na jednym prompcie.
**Nie:** planowanie pamięci bez KV cache; autoskalowanie GPU bez uwzględnienia czasu ładowania; porównanie kwantyzacji tylko po prędkości.
