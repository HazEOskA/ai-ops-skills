# Karty: osa-frontend-architecture

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### D01 · Architektura komponentów
**Gdy:** struktura UI, „gdzie to umieścić".
**Twarde:** dziel po granicy danych i odpowiedzialności, nie po typie pliku; komponent prezentacyjny nie wie o źródle danych; props drilling głębszy niż trzy poziomy to sygnał złej granicy, nie powód do context; kolokacja plików związanych z funkcją bije katalog `components/` z 200 plikami.
**Ekspert wie:** Sygnałem złej granicy jest komponent zmieniany razem z pięcioma innymi przy każdej funkcji. Kolokacja (komponent, styl, test, hook w jednym katalogu) i wyciąganie abstrakcji dopiero przy trzecim użyciu chronią przed przedwczesnym uogólnieniem, które kosztuje więcej niż powielenie.
**Sprawdź:** czy usunięcie funkcji to usunięcie jednego katalogu.
**Nie:** komponent przyjmujący 15 propsów; logika biznesowa w komponencie; abstrakcja wyciągnięta po drugim użyciu, zanim znany jest trzeci przypadek.

### D02 · Zarządzanie stanem
**Gdy:** wybór biblioteki stanu, „stan się rozjeżdża".
**Twarde:** rozdziel cztery rodzaje stanu: serwerowy (cache zdalnych danych), URL, lokalny UI, globalny klienta — każdy ma inne narzędzie; stan serwerowy do biblioteki cache'ującej, nie do globalnego store'a; URL jest stanem i przetrwa odświeżenie; globalny store tylko dla tego, co naprawdę globalne.
**Ekspert wie:** Większość „problemów ze stanem” to stan serwerowy trzymany jak klientowy: ręczne `useEffect` + `useState` na dane z API gubi wyścigi, cache i unieważnianie. Biblioteka do stanu serwerowego (TanStack Query, SWR) usuwa całą klasę błędów, a to, co zostaje po stronie klienta, jest małe.
**Sprawdź:** czy odświeżenie strony w środku przepływu zachowuje sensowny stan.
**Nie:** Redux jako cache odpowiedzi API; duplikacja stanu serwerowego w store; stan filtrów trzymany poza URL-em.

### D03 · Formularze
**Gdy:** formularz, walidacja, wieloetapowy przepływ.
**Twarde:** jedno źródło schematu walidacji, wspólne z backendem; walidacja przy opuszczeniu pola, nie przy każdym znaku; błędy przy polach, nie tylko zbiorczo na górze; blokada podwójnego wysłania; zachowanie danych przy błędzie serwera; walidacja klienta nigdy nie zastępuje serwerowej.
**Ekspert wie:** Podwójne wysłanie i utrata danych po błędzie to dwa błędy, które użytkownik zapamiętuje. Zablokowany przycisk nie wystarcza bez idempotentnego endpointu — odświeżenie i drugie kliknięcie w wolnej sieci i tak wyślą dwa żądania.
**Sprawdź:** wyślij formularz dwa razy szybko i przy wyłączonym JS — zachowanie ma być zdefiniowane.
**Nie:** walidacja tylko po stronie klienta; utrata wypełnionych danych po błędzie; komunikat „coś poszło nie tak" bez wskazania pola.

### D04 · SSR, hydracja, RSC
**Gdy:** Next/Nuxt/Remix, wolny start, błędy hydracji.
**Twarde:** rozstrzygnij per strona: statyczne, serwerowe czy klienckie — nie jedna strategia dla całej aplikacji; niezgodność hydracji bierze się z niedeterminizmu (data, losowość, `window`) — usuń przyczynę, nie wycisz ostrzeżenie; komponenty serwerowe nie mogą trzymać stanu; waterfall zapytań na serwerze kosztuje tyle samo co na kliencie.
**Ekspert wie:** Błędy hydracji biorą się z różnicy między HTML serwera a pierwszym renderem klienta: data i strefa czasowa, `Math.random`, `window`, rozszerzenia modyfikujące DOM. Strumieniowanie z granicami Suspense poprawia TTFB, ale nie usunie waterfalla zapytań, który trzeba spłaszczyć.
**Sprawdź:** porównaj HTML z `curl` z tym, co renderuje przeglądarka; zmierz TTFB osobno od LCP.
**Nie:** `useEffect` do pobierania danych, które da się pobrać na serwerze; hydracja całej strony przy trzech interaktywnych elementach; wyciszanie ostrzeżeń hydracji.

### D05 · Architektura CSS
**Gdy:** style rozjeżdżają się, konflikty, „skąd ten margines".
**Twarde:** jedna strategia w projekcie, nie trzy; zero magicznych liczb — wszystko z tokenów; specyficzność płaska, `!important` jako defekt do naprawy; odstępy zarządzane przez rodzica (layout), nie przez marginesy dziecka; `container queries` zamiast breakpointów tam, gdzie komponent ma być przenośny.
**Ekspert wie:** Specyficzność rośnie, gdy walczysz z kaskadą zamiast ją zaprojektować. Warstwy `@layer` i płaskie selektory rozwiązują to strukturalnie; `!important` ma być wyjątkiem zapisanym w komentarzu, nie metodą.
**Sprawdź:** wyszukaj `!important` i wartości pikselowe spoza skali w repo.
**Nie:** nadpisywanie stylów biblioteki selektorami zagnieżdżonymi; globalne style dodawane „tymczasowo"; wartości kolorów wpisane wprost zamiast z tokenów.

### D10 · Testy frontendu
**Gdy:** co testować w UI.
**Twarde:** testuj zachowanie widziane przez użytkownika, nie implementację; selektory po roli i tekście, nie po klasach CSS; E2E tylko na krytyczne ścieżki; testy komponentów na logikę stanu; wizualna regresja tam, gdzie liczy się wygląd, z akceptacją zmian w PR.
**Ekspert wie:** Test przez rolę i etykietę (`getByRole`) sprawdza przy okazji dostępność. Flake w E2E to najczęściej czekanie na czas (`sleep`) zamiast na stan aplikacji — czekaj na widoczny efekt albo odpowiedź sieci.
**Sprawdź:** `npx playwright test --repeat-each=5` — brak flake.
**Nie:** snapshot całego drzewa jako główny test; selektory po klasach; oczekiwania oparte na `sleep`.

### D17 · PWA i offline
**Gdy:** instalowalna aplikacja, praca bez sieci.
**Twarde:** service worker to trwały stan u użytkownika — zaplanuj aktualizację i wersjonowanie cache zanim wdrożysz; strategia per zasób (statyki cache-first, dane network-first); kolejka zapisów offline z rozstrzyganiem konfliktów; jawny sposób wymuszenia aktualizacji.
**Ekspert wie:** Service worker żyje dłużej niż wdrożenie: użytkownik z nową stroną i starym SW dostaje niezgodne zasoby. Potrzebny jest wersjonowany cache, `skipWaiting` z jawną obsługą albo komunikat „nowa wersja” oraz test aktualizacji z wersji poprzedniej.
**Sprawdź:** tryb offline w DevTools + test aktualizacji z wersji poprzedniej na nową.
**Nie:** cache-first dla API; service worker bez ścieżki wycofania (zostaje u użytkowników na miesiące); brak informacji o dostępnej nowej wersji.

### D18 · Rozszerzenie przeglądarki
**Gdy:** wtyczka Chrome/Firefox.
**Twarde:** Manifest V3, service worker zamiast strony w tle — nie trzyma stanu, każde wybudzenie zaczyna od zera; uprawnienia minimalne i opcjonalne, żądane w kontekście; content script działa w izolowanym świecie i nie widzi zmiennych strony; komunikacja przez `chrome.runtime` z walidacją nadawcy; przygotuj się na review sklepu przy każdej zmianie uprawnień.
**Ekspert wie:** Service worker MV3 jest zabijany po bezczynności, więc stan w zmiennych globalnych znika — trzymaj go w `chrome.storage`, a nasłuchiwacze rejestruj synchronicznie na najwyższym poziomie skryptu, inaczej zdarzenie wybudzające ich nie znajdzie.
**Sprawdź:** działanie po wygaszeniu service workera (`chrome://serviceworker-internals`).
**Nie:** stan trzymany w zmiennej globalnej service workera; `<all_urls>` gdy wystarczy jedna domena; wstrzykiwanie kodu do strony bez izolacji.

### D19 · Internacjonalizacja
**Gdy:** wiele języków, formaty, waluty.
**Twarde:** klucze zamiast tekstów w kodzie od pierwszego dnia; liczba mnoga przez reguły ICU, nie przez `if (n === 1)`; formaty dat, liczb i walut z `Intl`, nigdy ręcznie; teksty rozszerzają się o 30–40% w niemieckim — układ musi to znieść; RTL to nie tylko kierunek tekstu.
**Ekspert wie:** Polski ma cztery kategorie liczby mnogiej (one/few/many/other) — `n === 1` nie wystarczy; obsługują to ICU MessageFormat i `Intl.PluralRules`. Sklejanie zdań z fragmentów łamie się, bo szyk zdania różni się między językami.
**Sprawdź:** przełącz na język z długimi tekstami i na RTL, przejdź kluczowe ekrany.
**Nie:** sklejanie zdań z fragmentów; data formatowana ręcznie; brak fallbacku na brakujące tłumaczenie.

### D20 · Obsługa błędów w UI
**Gdy:** błąd sieci, awaria, pusty stan.
**Twarde:** trzy stany dla każdego widoku danych: ładowanie, pusty, błąd — zaprojektowane, nie domyślne; błąd mówi co się stało i co zrobić dalej; ponowienie dostępne bez przeładowania strony; error boundary izoluje sekcję, nie wywala całej aplikacji; błędy raportowane do monitoringu z kontekstem.
**Ekspert wie:** Stan błędu bez akcji naprawczej to ślepy zaułek. Error boundary łapie błędy renderowania, ale nie błędy w handlerach zdarzeń ani asynchroniczne — te trzeba obsłużyć jawnie i zaraportować z kontekstem.
**Sprawdź:** wyłącz sieć w DevTools i przejdź kluczowe ekrany.
**Nie:** biały ekran przy błędzie; „coś poszło nie tak" jako jedyny komunikat; stan pusty nieodróżnialny od stanu ładowania.
