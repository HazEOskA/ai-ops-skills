---
name: "osa-frontend-architecture"
description: "Architektura frontendu: React i Next.js, stan, dane z serwera, formularze, routing, komponenty, TypeScript, testowanie UI. Użyj przy budowie i strukturze aplikacji webowej, wyborze stanu, refactorze UI. Triggers: React, Next.js, frontend, state, components, TypeScript, forms, routing, UI architecture."
---

# Architektura frontendu

## Procedura

1. **Rdzeń najpierw** (`osa-build-gate`): jakie akcje użytkownika i jakie dane, zanim wybierzesz framework. Strona statyczna nie wykona po stronie serwera tego, czego wymaga rdzeń: sprawdź.
2. **Granica serwer/klient**: dane pobieraj i uwierzytelniaj na serwerze; klient renderuje i obsługuje interakcje. Sekrety nigdy w kodzie klienta (`osa-secrets-hygiene`).
3. **Stan**: trzymaj go możliwie blisko użycia; stan z serwera osobno (cache zapytań) od stanu UI. Globalny magazyn dopiero, gdy prostsze rozwiązanie zawodzi.
4. **Komponenty**: małe, o jednej odpowiedzialności, z jawnym kontraktem propsów w TypeScript (`strict`). Logika poza JSX.
5. **Formularze**: walidacja klienta dla UX, walidacja serwera dla bezpieczeństwa (`osa-security-baseline`); stany: ładowanie, błąd, pusty, sukces.
6. **Dostępność i wydajność od początku** (`osa-web-perf-a11y-seo`), nie jako poprawka na końcu.
7. **Testy**: logika jednostkowo, kluczowe ścieżki w przeglądarce (`osa-test-strategy`). Sprawdź UI w prawdziwej przeglądarce, nie tylko kompilację (`osa-verify-run`): build to `ARTIFACT_PRESENT`.
8. **Zależności**: każda ma koszt (rozmiar, utrzymanie, bezpieczeństwo). Dodaj, gdy oszczędza więcej niż kosztuje.

## Nie

- Opakowywania wszystkiego w globalny stan.
- `any` w TypeScript jako droga na skróty.
- Ogłaszania „UI gotowe” bez uruchomienia i obejrzenia.

## Karty (references/cards.md)

- **D01** · Architektura komponentów — gdy: struktura UI, „gdzie to umieścić"
- **D02** · Zarządzanie stanem — gdy: wybór biblioteki stanu, „stan się rozjeżdża"
- **D03** · Formularze — gdy: formularz, walidacja, wieloetapowy przepływ
- **D04** · SSR, hydracja, RSC — gdy: Next/Nuxt/Remix, wolny start, błędy hydracji
- **D05** · Architektura CSS — gdy: style rozjeżdżają się, konflikty, „skąd ten margines"
- **D10** · Testy frontendu — gdy: co testować w UI
- **D17** · PWA i offline — gdy: instalowalna aplikacja, praca bez sieci
- **D18** · Rozszerzenie przeglądarki — gdy: wtyczka Chrome/Firefox
- **D19** · Internacjonalizacja — gdy: wiele języków, formaty, waluty
- **D20** · Obsługa błędów w UI — gdy: błąd sieci, awaria, pusty stan

Wczytaj tylko karty pasujące do zadania (grep po ID).
