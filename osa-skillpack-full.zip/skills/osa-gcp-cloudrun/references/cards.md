# Karty: osa-gcp-cloudrun

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### F02 · GCP
**Gdy:** decyzja zapadła: GCP.
**Twarde:** Cloud Run domyślnie, GKE Autopilot dopiero przy realnej potrzebie; osobne projekty dla dev/stage/prod; Workload Identity Federation zamiast kluczy JSON w CI; Cloud SQL na prywatnym IP z PITR; Pub/Sub zawsze z dead letter topic; Artifact Registry z obrazami tagowanymi SHA; budżet z alertem nawet przy kredytach.
**Ekspert wie:** Cloud Run skaluje po współbieżności żądań i rozlicza czas wykonania (zależnie od trybu) — minimalna liczba instancji usuwa zimne starty, ale generuje stały koszt. Do Cloud SQL łącz się przez connector lub prywatne IP i pooler, bo skalowanie w górę wyczerpuje limit połączeń.
**Sprawdź:** `gcloud projects get-iam-policy $P --format=json | jq '.bindings[]|select(.role|test("owner|editor"))'` — pusto.
**Nie:** rola `Editor` dla konta usługi; jeden projekt na wszystko; `concurrency=1` w Cloud Run przy aplikacji obsługującej setki połączeń.

### F17 · Serverless
**Gdy:** funkcje, skalowanie do zera, zdarzenia.
**Twarde:** świetne przy ruchu nierównomiernym, drogie przy stałym wysokim; zimny start to problem tylko dla ścieżek interaktywnych — zmierz, nie zakładaj; połączenia do bazy przez pooler, inaczej wysycisz limit przy skalowaniu; limit czasu wykonania kształtuje architekturę; stan zawsze na zewnątrz; koszt rośnie z czasem wykonania, więc wolny kod jest dosłownie droższy.
**Ekspert wie:** Zimny start liczy się w ścieżce interaktywnej i przy dużych paczkach, ale pierwszym realnym problemem jest limit współbieżności i połączeń z bazą przy skoku ruchu (setki instancji to setki połączeń) — potrzebny pooler lub proxy.
**Sprawdź:** koszt i p99 przy docelowym wolumenie, nie przy jednym wywołaniu.
**Nie:** serverless dla stałego obciążenia 24/7; bezpośrednie połączenia do Postgresa z setek instancji; długie zadania wciskane pod limit czasu.
