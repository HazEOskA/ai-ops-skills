# Karty: osa-observability-slo

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### F14 · Obserwowalność i SLO
**Gdy:** alerty, metryki, tracing, „nie wiedzieliśmy że padło".
**Twarde:** SLO na ścieżkę użytkownika, nie na CPU; error budget z realną konsekwencją, inaczej SLO to dekoracja; alerty na wypalanie budżetu (multi-window burn rate), nie na progi techniczne; każdy alert ma adresata i runbook; tracing z propagacją kontekstu przez wszystkie usługi i kolejki; logi strukturalne z `trace_id` i samplingiem.
**Ekspert wie:** Alert na przyczynę (CPU 90%) budzi bez potrzeby, alert na objaw (burn rate budżetu błędów) budzi, gdy użytkownik cierpi. Logów bez `trace_id` w systemie z kolejkami nie da się połączyć w jedno żądanie.
**Sprawdź:** wywołaj alert sztucznie i zmierz, czy i kiedy dotarł do właściwej osoby.
**Nie:** alert na każdą metrykę (zmęczenie i ignorowanie); uptime mierzony pingiem na `/`; dashboard z 60 wykresami, którego nikt nie otwiera.

### I12 · Logowanie
**Gdy:** co i jak logować.
**Twarde:** logi strukturalne (JSON) z identyfikatorem korelacji, inaczej w systemie rozproszonym są bezużyteczne; poziomy używane zgodnie ze znaczeniem — ERROR oznacza, że ktoś ma zareagować; kontekst zamiast treści („zamówienie 123 odrzucone: brak środków", nie „błąd"); zero danych osobowych i sekretów; sampling, bo logi potrafią kosztować więcej niż compute; retencja ustawiona.
**Ekspert wie:** Log bez identyfikatora korelacji i poziomu zgodnego ze znaczeniem to szum. Najdroższe są logi o wysokiej kardynalności bez samplingu oraz dane osobowe w logach (retencja logów rzadko spełnia RODO).
**Sprawdź:** przejdź jedno żądanie przez wszystkie usługi po identyfikatorze korelacji.
**Nie:** `print` w produkcji; ERROR na rzeczy, które są normalne; logowanie całego obiektu żądania z tokenami.

### J06 · Pojemność
**Gdy:** planowanie zasobów, szczyt sprzedażowy.
**Twarde:** planuj od szczytu, nie od średniej; znaj punkt nasycenia z testu obciążeniowego, nie z ekstrapolacji; wąskim gardłem zwykle jest baza albo pula połączeń, nie CPU aplikacji; autoskalowanie ma opóźnienie — sprawdź, czy nadąża za twoim profilem wzrostu; zapas mocy kosztuje mniej niż awaria w szczycie.
**Ekspert wie:** Punkt nasycenia znajdziesz testem obciążeniowym do degradacji, nie ekstrapolacją. Sprawdź też limity, o których nie myślisz: deskryptory plików, porty efemeryczne, limity API dostawcy, limity DNS.
**Sprawdź:** test obciążeniowy do momentu degradacji z zapisanym progiem nasycenia.
**Nie:** planowanie na średnim obciążeniu; autoskalowanie jako odpowiedź na skok w 30 sekund; brak testu do granicy.

### J07 · Chaos i ćwiczenia
**Gdy:** weryfikacja odporności.
**Twarde:** zacznij od ćwiczenia na papierze („co się stanie, gdy padnie X") — zwykle znajdziesz dziury bez psucia czegokolwiek; potem eksperyment na stagingu z hipotezą i miarą; na produkcji dopiero gdy masz obserwowalność i przycisk stop; ćwicz też procedury ludzkie, nie tylko systemy.
**Ekspert wie:** Ćwiczenie na papierze („co jeśli padnie X i jak to zobaczymy”) zwykle znajduje więcej niż eksperyment. Wykrywalność (czy alert zadziałał) sprawdzaj osobno od odporności (czy system przetrwał).
**Sprawdź:** hipoteza zapisana przed eksperymentem i porównana z wynikiem.
**Nie:** losowe wyłączanie na produkcji bez obserwowalności; eksperyment bez hipotezy; ćwiczenia bez udziału osób dyżurujących.
