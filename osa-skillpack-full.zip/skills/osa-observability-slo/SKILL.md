---
name: "osa-observability-slo"
description: "Obserwowalność i SLO: logi strukturalne, metryki, ślady, alerty na objawy, budżet błędów, runbooki, pojemność. Użyj przy monitoringu, alertach, SLO, diagnozie produkcji, planowaniu pojemności. Triggers: observability, monitoring, SLO, SLI, alerts, logging, tracing, metrics, runbook, pojemność."
---

# Obserwowalność i SLO

## Procedura

1. **Zacznij od pytań**: po czym poznam, że użytkownik ma problem? To SLI (dostępność, opóźnienie p95/p99, odsetek błędów, poprawność). SLO to cel liczbowy uzgodniony z Osą; nie zgaduj go, zaproponuj z uzasadnieniem i zatwierdź.
2. **Logi strukturalne** (JSON) z identyfikatorem żądania, poziomem, bez sekretów i danych osobowych (`osa-secrets-hygiene`). Korelacja przez ID.
3. **Metryki** RED (żądania, błędy, czas) dla usług i USE (zużycie, saturacja, błędy) dla zasobów. Percentyle, nie średnie.
4. **Ślady** dla ścieżek między usługami, gdy diagnoza wymaga wglądu w łańcuch wywołań.
5. **Alerty na objawy** (odczuwalne przez użytkownika), nie na każdą przyczynę. Alert bez runbooka i właściciela to hałas: każdy ma akcję.
6. **Budżet błędów**: wydany budżet wstrzymuje ryzykowne zmiany.
7. **Runbook** krótki: objaw → sprawdź → napraw → eskaluj (`osa-incident-response`).
8. **Pojemność i DR**: znany limit obecnego systemu (test obciążenia), plan odtwarzania z zmierzonym RTO/RPO, przetestowany (kopie zapasowe, które nie były odtwarzane, nie istnieją).

## Nie

- Dashboardów bez pytania, na które odpowiadają.
- Alertów bez akcji.
- Logowania całych ciał żądań z danymi użytkowników.

## Karty (references/cards.md)

- **F14** · Obserwowalność i SLO — gdy: alerty, metryki, tracing, „nie wiedzieliśmy że padło"
- **I12** · Logowanie — gdy: co i jak logować
- **J06** · Pojemność — gdy: planowanie zasobów, szczyt sprzedażowy
- **J07** · Chaos i ćwiczenia — gdy: weryfikacja odporności

Wczytaj tylko karty pasujące do zadania (grep po ID).
