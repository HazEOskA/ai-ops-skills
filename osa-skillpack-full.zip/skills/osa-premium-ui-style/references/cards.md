# Karty: osa-premium-ui-style

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### D06 · Design tokens
**Gdy:** system projektowy, motywy, spójność.
**Twarde:** tokeny semantyczne nad surowymi (`surface-raised`, nie `gray-200`); jedno źródło, generowane do CSS/JS/natywnych; motyw jako zamiana wartości tokenów, nie osobny arkusz; skala odstępów i typografii ograniczona (5–7 kroków), nie ciągła.
**Ekspert wie:** Tokeny bez warstwy semantycznej nie przetrwają rebrandu ani trybu ciemnego: komponent czyta `--color-surface`, nie `--gray-900`, więc motyw zmienia mapowanie w jednym miejscu. Zmiana nazwy tokenu to zmiana breaking dla wszystkich konsumentów.
**Sprawdź:** czy zmiana jednego tokenu przechodzi przez całą aplikację bez ręcznych poprawek.
**Nie:** tokeny nazwane od wyglądu zamiast od roli; równoległe zestawy dla web i mobile; kolory dodawane ad hoc poza paletą.
