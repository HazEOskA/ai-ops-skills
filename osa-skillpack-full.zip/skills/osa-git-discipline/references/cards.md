# Karty: osa-git-discipline

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### I05 · Git
**Gdy:** historia, branche, konflikty, cofnięcie zmiany.
**Twarde:** commit robi jedną rzecz i ma opis mówiący dlaczego, nie co; krótkie gałęzie, bo długie to konflikty i ryzyko; `revert` na publicznej historii, `reset`/`rebase` tylko na własnej; `--force-with-lease` zamiast `--force`; przed każdą destrukcyjną operacją sprawdź `git reflog` jako siatkę bezpieczeństwa.
**Ekspert wie:** `git reflog` pozwala odzyskać niemal wszystko po złym resecie do czasu wygaśnięcia wpisów; `--force-with-lease` odmówi, jeśli ktoś dopchnął zmiany, których nie widziałeś; a `git bisect run` z automatycznym testem znajdzie commit psujący w logarytmicznej liczbie kroków.
**Sprawdź:** `git log --oneline -20`, `git reflog | head -20`, `git diff --stat main...HEAD`
**Nie:** `git push --force` na wspólnej gałęzi; commit „fixes" bez treści; historia przepisywana po merge'u do main.

### I06 · Monorepo
**Gdy:** wiele pakietów w jednym repo.
**Twarde:** monorepo ma sens, gdy pakiety zmieniają się razem — inaczej to tylko wspólny katalog; build i test tylko tego, co zmienione (graf zależności), inaczej CI rośnie liniowo z repo; granice pakietów wymuszone narzędziem, nie umową; wersjonowanie ustalone: wspólna wersja albo niezależne, nie oba naraz.
**Ekspert wie:** Bez grafu zależności i cache’owania build CI rośnie liniowo z repo. Granice pakietów egzekwuje narzędzie (reguły importów), a wspólny pakiet „utils” bez właściciela staje się miejscem, do którego wszystko zależy i którego nikt nie może zmienić.
**Sprawdź:** czas CI dla zmiany w jednym pakiecie — powinien być bliski czasowi tego pakietu.
**Nie:** pełny build przy każdej zmianie; import przez ścieżki względne przekraczające granice pakietu; współdzielony pakiet `utils` bez właściciela.
