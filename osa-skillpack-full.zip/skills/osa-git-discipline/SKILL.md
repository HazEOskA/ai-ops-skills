---
name: "osa-git-discipline"
description: "Dyscyplina git i monorepo: małe commity, jasne komunikaty, brak force, brak push bez zgody, wersjonowanie i zależności. Użyj przy commitach, branchach, PR-ach, monorepo, publikacji pakietów. Triggers: git, commit, branch, PR, merge, rebase, monorepo, semver."
---

# Dyscyplina git

## Reguły

1. Jeden commit = jedna zmiana logiczna. Komunikat mówi **dlaczego**, nie tylko co.
2. Przed commitem: `git status`, `git diff --stat` zgodny z deklaracją zakresu (`osa-scope-guard`).
3. **Push, force, rebase opublikowanej historii, merge do głównej gałęzi: tylko za zgodą Osy** (`osa-god-layer-approvals`). Domyślnie commituj lokalnie na gałęzi roboczej.
4. Nie commituj sekretów, `.env`, kluczy (`osa-secrets-hygiene`). Wyciek w historii wymaga rotacji klucza, samo usunięcie pliku nie wystarcza.
5. Nie używaj `git add -A` na ślepo. Dodawaj pliki z listy zakresu.
6. Atrybucja commitów i PR według instrukcji środowiska (Co-Authored-By, link sesji), o ile ją podano.
7. Cofanie: `git revert` dla opublikowanego, `git reset` tylko lokalnie i za zgodą przy utracie pracy.

## Kiedy sięgnąć po karty

Monorepo (graf zależności, build tylko zmienionego), wersjonowanie pakietów i publikacja: zobacz karty niżej.

## Karty (references/cards.md)

- **I05** · Git — gdy: historia, branche, konflikty, cofnięcie zmiany
- **I06** · Monorepo — gdy: wiele pakietów w jednym repo

Wczytaj tylko karty pasujące do zadania (grep po ID).
