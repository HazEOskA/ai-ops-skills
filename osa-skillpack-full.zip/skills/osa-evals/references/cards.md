# Karty: osa-evals

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### G03 · Ewaluacje
**Gdy:** „czy to działa lepiej".
**Twarde:** minimum 20–30 realnych przypadków, w tym brzegowe, złośliwe i takie, gdzie poprawną odpowiedzią jest odmowa; trzy poziomy oceny: deterministyczna, model jako sędzia z rubryką, człowiek na próbce; mierz wariancję przez powtórzenia — jeden przebieg nie mówi nic; produkcyjne porażki wracają do zestawu.
**Ekspert wie:** Sędzia-model ma bias (długość, pozycja, styl własny) — kalibruj go na próbce ocen ludzkich i losuj kolejność odpowiedzi. Zestaw, który przechodzi w 100%, jest za łatwy i nie mierzy postępu.
**Sprawdź:** wynik i wariancja z 3 powtórzeń, przed i po zmianie, na tym samym zestawie.
**Nie:** „wygląda lepiej" jako ocena; zestaw złożony z przypadków, które już działają; sędzia-model bez kalibracji wobec ocen ludzkich.

### G14 · Monitoring modelu
**Gdy:** model na produkcji.
**Twarde:** monitoruj rozkład wejścia i wyjścia, nie tylko dostępność usługi; dryf danych poprzedza spadek jakości i jest wykrywalny wcześniej; etykiety spływają z opóźnieniem, więc potrzebujesz proxy jakości; zapisuj wejście i predykcję, żeby dało się odtworzyć decyzję; próg alertu ustalony z danych historycznych, nie z sufitu.
**Ekspert wie:** Dryf wejścia widać wcześniej niż spadek jakości, bo etykiety przychodzą z opóźnieniem. Porównuj rozkłady (PSI, KS) tydzień do tygodnia i zapisuj wejście z predykcją, żeby po incydencie dało się odtworzyć decyzję.
**Sprawdź:** porównanie rozkładu cech tydzień do tygodnia + odsetek predykcji przy skrajnych wartościach.
**Nie:** monitoring wyłącznie latencji i błędów HTTP; ocena jakości dopiero po skardze użytkownika; brak zapisu predykcji.

### G15 · Dane treningowe i etykiety
**Gdy:** budujesz zbiór.
**Twarde:** zgodność między etykietującymi zmierzona przed skalowaniem — niska oznacza, że zadanie jest źle zdefiniowane, nie że ludzie są słabi; instrukcja etykietowania z przypadkami brzegowymi; zbiór testowy zamrożony i nietykany; źródło i prawa do danych udokumentowane; duplikaty i wycieki między zbiorami sprawdzone.
**Ekspert wie:** Niska zgodność etykietujących zwykle oznacza niejasną definicję zadania. Przed skalowaniem zmierz zgodność (np. kappa Cohena) na próbce oznaczonej podwójnie i dopisz przypadki brzegowe do instrukcji.
**Sprawdź:** zgodność na próbce podwójnie etykietowanej + sprawdzenie duplikatów między train i test.
**Nie:** etykietowanie bez instrukcji; zestaw testowy poprawiany, gdy wyniki są słabe; dane bez ustalonego pochodzenia.
