---
name: "osa-architecture-lock"
description: "Decyzja architektoniczna zapisana jako ADR przed budową: opcje, wybór, koszt wyjścia, warunek rewizji; wybór technologii i granice modułów. Użyj przy wyborze, który będzie kosztowny do cofnięcia. Triggers: architecture, ADR, tech choice, stack, monolith, microservices, wybór technologii."
---

# Blokada architektury

Architektura jest zablokowana, zanim powstanie pierwszy plik. Rozstrzygnięcie zamiast przeglądu opcji.

## Procedura

1. Zaczynaj od `osa-build-gate` (rdzeń i inwentarz). Architektura odpowiada na czasowniki rdzenia, nie na rzeczownik.
2. Odróżnij decyzję odwracalną (dwa zdania w commicie) od nieodwracalnej (pełny ADR: `assets/ADR_template.md`, jedna strona).
3. W ADR: kontekst, 2–3 realne opcje, wybór, konsekwencje, **koszt wyjścia**, **warunek rewizji** („wracamy, gdy X”). Kompromis nazwany liczbą (koszt, latencja, godziny pracy).
4. Domyślnie: rozbudowa istniejącego projektu, jeśli robi to samo lub prawie (krok 3 bramki). Nowy projekt obok wymaga powodu.
5. Solo builder: wybieraj najmniej ruchomych części, które spełniają rdzeń (`osa-mvp-solo-builder`). Skomplikowane tylko z liczbą, która to uzasadnia.
6. Zapisz ADR w repo (`docs/adr/NNNN-tytul.md`) i wskaż w raporcie.

## Nie

- Decyzji uzasadnionej popularnością.
- ADR pisanego po fakcie jako uzasadnienie.
- Wyboru technologii bez sprawdzenia, że wybrany runtime wykonuje wszystkie czasowniki rdzenia.

## Karty (references/cards.md)

- **A03** · Decyzja architektoniczna (ADR) — gdy: wybór między rozwiązaniami, który będzie kosztowny do cofnięcia
- **A07** · Wybór technologii — gdy: „czego użyć"
- **B18** · Event sourcing i CQRS — gdy: ktoś proponuje event sourcing
- **B19** · DDD w praktyce — gdy: złożona domena, spory o model

Wczytaj tylko karty pasujące do zadania (grep po ID).
