# ADR NNNN: <tytuł decyzji>

Data: YYYY-MM-DD · Status: propozycja / przyjęta / zastąpiona przez NNNN · Decyduje: Osa

## Kontekst
Jaki problem, jakie ograniczenia (czasowniki rdzenia, budżet, czas, runtime).

## Opcje
1. <opcja> — koszt wejścia, koszt wyjścia, ryzyko
2. <opcja> — …
3. <opcja> — …

## Decyzja
Wybieramy <opcja>, bo <powód mierzalny>.

## Konsekwencje
Co zyskujemy, co tracimy (liczby).

## Warunek rewizji
Wracamy do tej decyzji, gdy <mierzalny warunek>.

## Koszt wyjścia
Ile kosztuje wycofanie (godziny, migracja, dane).
