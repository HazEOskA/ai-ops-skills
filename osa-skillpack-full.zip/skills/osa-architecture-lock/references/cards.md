# Karty: osa-architecture-lock

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### A03 · Decyzja architektoniczna (ADR)
**Gdy:** wybór między rozwiązaniami, który będzie kosztowny do cofnięcia.
**Twarde:** zapisz kontekst, opcje, wybór, konsekwencje i warunek rewizji; wyceniaj koszt wyjścia, nie tylko koszt wejścia; decyzje odwracalne podejmuj szybko, nieodwracalne wolno; jedna strona, nie dziesięć.
**Ekspert wie:** ADR ma wartość dopiero z sekcją „co skłoni nas do zmiany decyzji” — bez niej to uzasadnienie po fakcie. Przy decyzjach odwracalnych wystarczą dwa zdania w commicie; pełny ADR jest dla tego, co kosztuje tydzień lub więcej do cofnięcia.
**Sprawdź:** ADR w repo z datą, statusem i alternatywami, które faktycznie rozważono.
**Nie:** decyzja uzasadniona popularnością; brak warunku „wracamy do tematu gdy X"; ADR pisany po fakcie jako uzasadnienie.

### A07 · Wybór technologii
**Gdy:** „czego użyć".
**Twarde:** kryterium pierwsze to kto to utrzyma, nie co jest lepsze; licz koszt operacyjny, nie benchmark; nudna technologia z żywym ekosystemem bije nową w 90% przypadków; policz koszt wyjścia.
**Ekspert wie:** Koszt technologii ujawnia się przy pierwszej awarii o trzeciej w nocy i przy pierwszej migracji wersji major, nie przy prototypie. Zapytaj, kto to naprawi i jak wygląda ścieżka aktualizacji, zanim zapytasz o wydajność.
**Sprawdź:** data ostatniego wydania, liczba maintainerów, liczba otwartych krytycznych issue, rozmiar zależności.
**Nie:** wybór po benchmarku z bloga; nowa baza dla jednego przypadku użycia; „to standard" jako argument bez wskazania czyj.

### B18 · Event sourcing i CQRS
**Gdy:** ktoś proponuje event sourcing.
**Twarde:** to nie jest domyślna architektura — bierz tylko gdy audyt zdarzeń albo odtwarzanie stanu w czasie jest wymogiem, nie ozdobą; zdarzenia są niezmienne, więc schemat zdarzenia to kontrakt na zawsze; projekcje bywają nieaktualne i UI musi to znieść; migracja zdarzeń jest znacznie trudniejsza niż migracja tabeli.
**Ekspert wie:** Prawdziwy koszt to ewolucja zdarzeń (upcasting starych wersji), odtwarzanie długich strumieni (snapshoty) oraz konflikt niezmienności z prawem do usunięcia danych osobowych. Jeśli nie masz odpowiedzi na te trzy pytania, tabela historii zmian daje większość wartości za ułamek kosztu.
**Sprawdź:** czy zespół umie odpowiedzieć, jak zmieni kształt zdarzenia sprzed roku.
**Nie:** CQRS dla CRUD-a; event sourcing bez snapshotów przy długich strumieniach; traktowanie kolejki jako store'u zdarzeń.

### B19 · DDD w praktyce
**Gdy:** złożona domena, spory o model.
**Twarde:** wartość jest w języku i granicach, nie w katalogach nazwanych `domain/`; agregat wyznacza granicę transakcji — jedna transakcja, jeden agregat; między agregatami zdarzenia, nie bezpośrednie referencje; anemiczny model to nie porażka, jeśli domena jest prosta.
**Ekspert wie:** Najcenniejszy element DDD to język wszechobecny i granica kontekstu — spisz z biznesem słownik pojęć. Spór, czy „klient” w rozliczeniach to to samo co w supporcie, zwykle wskazuje, gdzie ma przebiegać granica serwisu.
**Sprawdź:** czy nazwy w kodzie zgadzają się z nazwami, których używa biznes w rozmowie.
**Nie:** taktyczne wzorce DDD nałożone na CRUD; agregat obejmujący pół systemu; warstwy dla samych warstw.
