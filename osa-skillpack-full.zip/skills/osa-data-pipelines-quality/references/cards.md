# Karty: osa-data-pipelines-quality

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### C05 · Hurtownia i model analityczny
**Gdy:** raportowanie, BI, analityka.
**Twarde:** oddziel warstwę surową, oczyszczoną i prezentacyjną; wymiary i fakty zamiast kopiowania schematu produkcyjnego; ziarno tabeli faktów zdefiniowane jednym zdaniem; czas ładowania i świeżość danych to część kontraktu z odbiorcą.
**Ekspert wie:** Metryka liczona w trzech miejscach da trzy liczby — trzymaj definicję w jednym modelu (warstwa semantyczna, model dbt), a ziarno faktu zapisz jednym zdaniem. „Liczby się nie zgadzają” najczęściej znaczy inne ziarno albo filtr, nie błąd danych.
**Sprawdź:** test świeżości i test unikalności klucza ziarna na każdej tabeli faktów.
**Nie:** raporty odpytujące bazę produkcyjną; brak zdefiniowanego ziarna; metryka liczona inaczej w dwóch dashboardach.

### C06 · ETL / ELT
**Gdy:** pipeline danych, ładowanie, transformacje.
**Twarde:** idempotentne przebiegi z możliwością ponownego uruchomienia dla dowolnego okna; ładowanie przyrostowe z watermarkiem, nie pełne przy każdym uruchomieniu; transformacje wersjonowane w repo; awaria zatrzymuje pipeline, nie ładuje połowy danych po cichu.
**Ekspert wie:** Idempotencja to nadpisanie partycji lub okna (`MERGE`, `INSERT OVERWRITE`), nie dopisywanie — powtórka po awarii inaczej podwaja dane. Watermark oparty na `updated_at` gubi rekordy, gdy zapis z długiej transakcji dostaje wcześniejszy znacznik niż już przetworzony (potrzebny zapas na spóźnienie).
**Sprawdź:** ponowne uruchomienie tego samego okna nie zmienia wyniku (test idempotencji).
**Nie:** transformacja w kodzie zadania bez wersjonowania; częściowe ładowanie bez oznaczenia; pipeline bez alertu na brak uruchomienia.

### C07 · Streaming
**Gdy:** Kafka, Kinesis, przetwarzanie ciągłe.
**Twarde:** rozróżnij czas zdarzenia od czasu przetworzenia — od tego zależy poprawność okien; spóźnione zdarzenia to reguła, nie wyjątek (zdefiniuj politykę); partycjonuj po kluczu, który daje równomierny rozkład; stan operatorów wymaga checkpointów; schema registry z kompatybilnością wsteczną.
**Ekspert wie:** Exactly-once w streamingu oznacza efektywnie jedno przetworzenie dzięki idempotentnemu ujściu albo transakcyjnemu commitowi offsetu razem z wynikiem. Rebalans grupy konsumentów to moment duplikatów i przestoju; zbyt długie przetwarzanie jednej wiadomości potrafi rozbić grupę.
**Sprawdź:** lag konsumenta na dashboardzie + test z celowo spóźnionym zdarzeniem.
**Nie:** okna po czasie przetworzenia w systemie rozliczeniowym; klucz partycji o niskiej kardynalności; zmiana schematu bez sprawdzenia kompatybilności.

### C08 · Jakość danych
**Gdy:** „liczby się nie zgadzają".
**Twarde:** testy danych obok testów kodu: unikalność klucza, brak nulli tam gdzie nie wolno, zakresy, spójność referencyjna, świeżość, wolumen w oczekiwanym przedziale; test odpala się przy każdym ładowaniu i blokuje publikację; właściciel każdego zbioru nazwany.
**Ekspert wie:** Najpewniejszy wczesny alarm to wolumen i świeżość, nie wartości: pusta lub o połowę mniejsza tabela to awaria źródła, którą testy „not null” przepuszczą. Test danych bez właściciela i ścieżki eskalacji przestaje być czytany po kilku tygodniach.
**Sprawdź:** liczba rekordów dzień do dnia — nagły spadek o 40% to awaria, nie sezonowość.
**Nie:** wykrywanie problemów przez odbiorcę raportu; testy danych uruchamiane ręcznie; brak alertu na pustą tabelę.
