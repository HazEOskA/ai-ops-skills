# Karty: osa-cicd-iac

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### F08 · Terraform / IaC
**Gdy:** infrastruktura jako kod, state, drift.
**Twarde:** state zdalny z blokadą, wersjonowaniem i szyfrowaniem; osobny state per środowisko; wersje providerów pinowane, lock file w repo; `plan` czytany linia po linii, szczególnie `destroy` i `forces replacement`; `prevent_destroy` na zasobach ze stanem; sekrety nie należą do IaC (lądują w state jawnie); `for_each` zamiast `count`.
**Ekspert wie:** State zawiera sekrety jawnie i jest źródłem prawdy o tożsamości zasobów — `terraform state rm` i ręczne zmiany w konsoli powodują dryf. W `plan` szukaj „must be replaced”: to usunięcie i utworzenie, czyli utrata danych dla zasobów ze stanem.
**Sprawdź:** `terraform plan -out=tf.plan && terraform show -no-color tf.plan | grep -E 'destroy|forces replacement'`; po `apply` plan musi być pusty.
**Nie:** `-auto-approve` na produkcji z laptopa; jeden state dla wszystkich środowisk; ręczna poprawka w konsoli.

### F09 · CI/CD i bramki
**Gdy:** pipeline, deploy, rollback.
**Twarde:** buduj raz, promuj ten sam artefakt; tag SHA, nigdy `latest`; bramki od najtańszych (lint, typy) do najdroższych (E2E); feedback dla developera poniżej 10 minut; migracje wstecznie kompatybilne i osobno od deployu kodu; rollback przećwiczony w ostatnim kwartale; smoke test i okno obserwacji z automatycznym cofnięciem.
**Ekspert wie:** Pipeline, który przechodzi tylko z cache i nigdy z czystego środowiska, kłamie — co jakiś czas buduj bez cache. Sekrety dla forków to klasyczna dziura: `pull_request_target` z checkoutem kodu z forka uruchamia obcy kod z twoimi sekretami.
**Sprawdź:** `gh run list`; przećwiczony rollback z zapisanym czasem od decyzji do przywrócenia.
**Nie:** przebudowa obrazu dla produkcji; pomijanie bramek „bo pilne"; rollback opisany w dokumencie, nigdy nie wykonany.

### I07 · Build i zależności
**Gdy:** wolny build, „u mnie działa", konflikt wersji.
**Twarde:** build musi być deterministyczny — lock file, przypięte wersje narzędzi, ta sama wersja runtime lokalnie i w CI; cache warstw i zależności z jawnym kluczem; build lokalny i w CI to ta sama komenda; artefakt budowany raz i promowany między środowiskami.
**Ekspert wie:** Powtarzalny build wymaga przypiętych wersji narzędzi, nie tylko bibliotek: wersja Node, Pythona czy kompilatora jest częścią wejścia. W CI `npm ci` zamiast `npm install`, bo to drugie może zmienić lockfile.
**Sprawdź:** dwa buildy z tego samego commita dają identyczny artefakt (albo przynajmniej identyczny zestaw zależności).
**Nie:** wersje narzędzi zależne od tego, co ma developer; `latest` w zależnościach; osobne komendy do buildu lokalnego i CI.

### I08 · Publikacja paczki
**Gdy:** biblioteka, pakiet publiczny lub wewnętrzny.
**Twarde:** semver traktowany poważnie — breaking change to major, zawsze; changelog generowany z commitów, nie pisany z pamięci; publikacja z CI z tagu, nigdy z laptopa; deprecation z okresem przejściowym i komunikatem w runtime; testuj instalację w czystym środowisku, bo to najczęstsze źródło niespodzianek.
**Ekspert wie:** Zły wpis w `exports` albo `files` daje paczkę, która działa lokalnie i psuje się u użytkownika. Zawsze `npm pack` i instalacja tarballa w pustym projekcie, a publikacja z tagu w CI z provenance zamiast z laptopa.
**Sprawdź:** instalacja opublikowanej paczki w pustym projekcie i uruchomienie przykładu z README.
**Nie:** breaking change w patchu; publikacja z niezacommitowanymi zmianami; brak `files`/`exports` (paczka waży 40 MB albo nie eksportuje tego, co trzeba).
