---
name: "osa-cicd-iac"
description: "CI/CD i infrastruktura jako kod: pipeline z bramkami, powtarzalne buildy, Terraform i pliki stanu, środowiska, wydania i rollback. Użyj przy GitHub Actions, potokach wdrożeń, Terraform, wersjonowaniu wydań. Triggers: CI, CD, GitHub Actions, pipeline, Terraform, IaC, release, build, workflow."
---

# CI/CD i IaC

## Procedura

1. **Pipeline minimalny i szybki**: instalacja z zamrożonych zależności → lint → testy → build → artefakt. Każdy etap ma exit code i blokuje kolejne (`osa-verify-run`).
2. **Powtarzalność**: przypięte wersje narzędzi i akcji, cache kluczowany hashem lockfile, ten sam build lokalnie i w CI.
3. **Sekrety w CI**: wyłącznie w magazynie sekretów platformy. Nie drukuj ich w logach (`osa-secrets-hygiene`). Uprawnienia tokena workflow: minimalne.
4. **Wdrożenie**: osobny etap wyzwalany świadomie, z zatwierdzeniem dla produkcji (`osa-god-layer-approvals`). Ten sam artefakt przechodzi przez środowiska.
5. **IaC**: stan zdalny z blokadą, `plan` przeglądany przed `apply`. `apply` na produkcji tylko za zgodą. Rozbieżność (drift) wykrywaj planem, nie ręcznymi zmianami w konsoli.
6. **Wydania**: semver, changelog, tag na konkretnym SHA, rollback = wdrożenie poprzedniego artefaktu (`osa-deploy-validation`).
7. **Czas CI jako metryka**: rośnie liniowo z repo? Buduj i testuj tylko zmienione (`osa-git-discipline`, monorepo).

## Nie

- `terraform apply -auto-approve` na produkcji.
- Pipeline'u, który przechodzi na zero uruchomionych testów.
- Zmian infrastruktury poza kodem.

## Karty (references/cards.md)

- **F08** · Terraform / IaC — gdy: infrastruktura jako kod, state, drift
- **F09** · CI/CD i bramki — gdy: pipeline, deploy, rollback
- **I07** · Build i zależności — gdy: wolny build, „u mnie działa", konflikt wersji
- **I08** · Publikacja paczki — gdy: biblioteka, pakiet publiczny lub wewnętrzny

Wczytaj tylko karty pasujące do zadania (grep po ID).
