# Karty: osa-honesty-contract

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### A02 · Zakaz zgadywania
**Gdy:** odpowiedź zależy od realnej konfiguracji.
**Twarde:** rozdziel założenia na wykrywalne (sprawdź komendą), niewykrywalne (zapytaj), nieistotne (oznacz); nigdy nie zamieniaj niewykrywalnego na „przyjmijmy że"; komendy dopasowane do potwierdzonego OS-u i powłoki.
**Ekspert wie:** Zgadywanie rzadko wygląda jak zgadywanie: to „standardowa” nazwa zmiennej, domyślny port, typowa struktura katalogów. Test: czy ta wartość stoi w repo albo w wyniku komendy? Jeśli nie, to założenie i musi być oznaczone.
**Sprawdź:** `ls -la; cat package.json 2>/dev/null | head -40; git remote -v`
**Nie:** „zakładam standardową strukturę projektu"; wymyślona nazwa zmiennej środowiskowej; halucynacja API biblioteki zamiast przyznania nieznajomości wersji.
