---
name: "osa-build-gate"
description: "Bramka budowy przed pierwszym plikiem: czasowniki rdzenia, inwentarz narzędzi, istniejący projekt, mapa i werdykt BUDUJĘ albo STOP. Użyj przy każdym zamówieniu na działającą rzecz. Triggers: build, create, deploy, implement, zbuduj, zrób aplikację, dashboard, pipeline."
---

# Bramka budowy

**Kiedy:** każde zadanie, którego wynikiem jest działająca rzecz: aplikacja, dashboard, skrypt, pipeline, integracja, deploy, zmiana w repo. Nie dotyczy pytań o wiedzę.

**Krok 1 — Rdzeń.** Wypisz czasowniki z zamówienia dosłownie, słowami użytkownika. „AI podpowiada kroki, robi testy, proponuje zmiany, sandbox” = cztery czasowniki, nie jeden „dashboard”. Rzeczownik (dashboard, apka) to opakowanie; rdzeń to czasowniki.

**Krok 2 — Inwentarz.** Zanim zaproponujesz architekturę, przejrzyj co realnie masz: narzędzia i connectory w tej sesji, podpięte konta (GitHub, Vercel, GCP, Supabase…), podłączony komputer, runtime'y (sandbox, CI, VPS). Dla każdego czasownika rdzenia szukaj narzędzia, które go wykonuje naprawdę — nie symuluje.

**Krok 3 — Istniejące.** Sprawdź, czy użytkownik już ma projekt, który to robi lub prawie robi. Jest → domyślnie rozbudowa. Nowy projekt obok wymaga podanego powodu.

**Krok 4 — Mapa.** Blok jawny w odpowiedzi:
```
RDZEŃ:    <czasownik 1> | <czasownik 2> | …
RUNTIME:  <gdzie to działa>
MAPA:     <czasownik> → TAK / NIE / NIE SPRAWDZONE → <czym konkretnie>
ISTNIEJE: <projekt> → rozbudowa | nowy, bo <powód>
WERDYKT:  BUDUJĘ | STOP — <który czasownik = NIE> → <alternatywy>
```

**Twarde reguły:**
- Czasownik rdzenia = NIE → **zakaz budowy.** Przedstaw runtime'y, w których jest TAK, z kosztem każdego.
- Czasownik rdzenia = NIE SPRAWDZONE → **najpierw jeden test**, który to rozstrzyga (jedno wywołanie narzędzia, jedna komenda), potem mapa od nowa.
- **Rekomendacja w pytaniu do użytkownika** może wskazywać tylko opcję z samymi TAK. Łatwość wykonania dla ciebie nie jest kryterium. Żadna opcja nie przechodzi → rekomenduj tę, która obcina najmniej rdzenia, i napisz wprost, co odpada.
- **Obcięcie rdzenia** (np. „testy w v2”) to decyzja użytkownika, nie twoja — i musi być nazwane jako obcięcie, nie jako „opcja”.
- Użytkownik wybrał opcję na podstawie twojej błędnej rekomendacji → powiedz to i cofnij, zanim zbudujesz.
- Odkryłeś blokadę w trakcie budowy → stop, pierwsze zdanie następnej wiadomości, nie sekcja „ryzyka” na końcu.

**Anty-wzorzec (realny przypadek, 2026-09-28):** zamówienie „dashboard repo z AI review, testami, sandboxem, AI proponuje zmiany”. Zbudowano stronę-artefakt bez dostępu do kodu repo i bez możliwości uruchomienia testów, choć w sesji były narzędzia do odpalania sesji Claude Code w chmurze (klon repo + testy w kontenerze) i Vercel Sandbox. Bramka dałaby STOP przy wyborze runtime'u.

## Karty (references/cards.md)

- **A04** · Szacowanie — gdy: „ile to zajmie"
- **A05** · Cięcie zakresu — gdy: za dużo do zrobienia, deadline, MVP

Wczytaj tylko karty pasujące do zadania (grep po ID).
