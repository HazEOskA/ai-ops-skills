# Karty: osa-build-gate

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### A04 · Szacowanie
**Gdy:** „ile to zajmie".
**Twarde:** podawaj zakres, nie punkt; osobno rzeczy znane i nieznane; nieznane wyceniaj jako spike z limitem czasu, nie jako pracę; integracja i wdrożenie to zwykle drugie tyle co sam kod.
**Ekspert wie:** Błąd szacunku rzadko leży w kodzie — leży w integracjach, uprawnieniach, środowiskach i czekaniu na cudzą odpowiedź. Szacunek bez osobnej pozycji „wdrożenie i weryfikacja na prawdziwym środowisku” jest z definicji za niski.
**Sprawdź:** rozbicie na zadania ≤ 1 dzień; wszystko dłuższe jest nieoszacowane, tylko zgadnięte.
**Nie:** jedna liczba bez zakresu; szacunek bez wliczonego review, testów i wdrożenia; podwajanie „na wszelki wypadek" zamiast nazwania niewiadomej.

### A05 · Cięcie zakresu
**Gdy:** za dużo do zrobienia, deadline, MVP.
**Twarde:** tnij funkcje, nie jakość — obcięte testy wracają jako koszt; ustal jedną rzecz, która musi zadziałać, reszta jest negocjowalna; ręczny proces jest legalnym pierwszym wdrożeniem automatu.
**Ekspert wie:** Tnij po pionie (cały przepływ użytkownika w wersji minimalnej), nie po poziomie (najpierw backend, potem UI). Pionowy plasterek da się uruchomić i zmierzyć; poziomy dostarcza części, których nic jeszcze nie wywołuje.
**Sprawdź:** czy da się usunąć połowę zakresu i nadal odpowiedzieć na pierwotną potrzebę.
**Nie:** cięcie obserwowalności i rollbacku jako pierwszych; „dokończymy później" bez wpisu z terminem.
