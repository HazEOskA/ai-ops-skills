---
name: "osa-gmail-draft-log"
description: "Dziennik pracy przez szkice Gmail: jeden szkic na ukończony krok i jeden zbiorczy szkic raportu dziennego. Tylko szkice, nigdy wysyłka. Użyj po zakończeniu kroku lub dnia pracy, gdy Osa używa Gmaila. Triggers: gmail, draft, daily report, dziennik, szkic maila."
---

# Dziennik w szkicach Gmail

Zasady Osy: **szkic na każdy ukończony krok** plus **jeden zbiorczy szkic raportu dziennego**. Tylko szkice. Wysyłka wymaga zgody (`osa-god-layer-approvals`).

## Procedura

1. Załaduj narzędzie tworzenia szkiców przez ToolSearch (`select:mcp__Gmail__create_draft`). Brak konektora Gmail w sesji: powiedz to i zapisz treść do pliku `sessions/` (`osa-session-handoff`). Nie udawaj, że szkic powstał.
2. **Szkic kroku** (po każdym ukończonym kroku):
   - Temat: `[OSA] <projekt> · <krok> · <GOTOWE|CZĘŚCIOWE>`
   - Treść: struktura z `osa-report-format`, skrócona. Tabela czasowników, dowody, ryzyka, Next Smallest Task.
3. **Szkic dzienny** (koniec dnia, jeden na dzień): temat `[OSA] Raport dzienny YYYY-MM-DD`. Lista kroków z linkiem do szkiców kroków, ustalone, otwarte, rozjazdy, następny krok jutro.
4. Odbiorca: zostaw pusty, jeśli narzędzie na to pozwala. Adres Osy tylko gdy Osa go poda albo narzędzie wymaga. Nie zgaduj adresów.
5. Po utworzeniu podaj Osie potwierdzenie z identyfikatorem szkicu zwróconym przez narzędzie. Brak identyfikatora = szkic nie powstał.

## Zakazy

- Zero sekretów, tokenów, danych osobowych w treści (`osa-secrets-hygiene`).
- Zero wysyłki, forwardu, usuwania cudzych maili.
- Nie twórz szkicu za coś, co nie zostało zakończone (CZĘŚCIOWE to też wpis, ale z etykietą CZĘŚCIOWE).
