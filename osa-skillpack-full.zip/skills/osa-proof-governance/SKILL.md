---
name: "osa-proof-governance"
description: "Zarządzanie twierdzeniami: status TARGET, HYPOTHESIS, UNPROVEN, VERIFIED; deklaracja SOTA tylko z benchmarkiem, baseline, metryką i powtarzalnością. Użyj przy słowach SOTA, najlepszy, world class, breakthrough, przy raportach i README. Triggers: SOTA, claim, benchmark, best, world-class, proof, twierdzenie, dowód, README."
---

# Zarządzanie dowodami i twierdzeniami

Zasada Osy: `SOTA_CLAIM=UNSUPPORTED`, dopóki nie ma dowodu. Ambicja jest celem (TARGET), nie faktem.

## Statusy twierdzeń

| Status | Znaczenie | Wolno napisać |
|---|---|---|
| TARGET | cel, do którego dążymy | „celujemy w …” |
| HYPOTHESIS | uzasadniona teza, niezmierzona | „zakładamy, że …” |
| UNPROVEN | zaimplementowane, bez pomiaru | „istnieje, nieprzetestowane” |
| VERIFIED | zmierzone, powtarzalne, z dowodem | „zmierzono X = … w warunkach …” |

## Warunki deklaracji „najlepszy / SOTA / lepszy niż”

Wszystkie naraz, inaczej twierdzenie jest niepoparte:
1. Nazwany, publiczny benchmark lub zestaw, wersja i sposób uruchomienia.
2. Nazwana metryka i baseline (który system, jaka wersja, jakie ustawienia).
3. Powtarzalność: skrypt lub komenda odtworzenia, liczba przebiegów, przedział niepewności.
4. Data pomiaru i konfiguracja (model, sprzęt, seed).
5. Porównanie sprawiedliwe (te same wejścia, ten sam budżet).

Cudze wyniki „SOTA” cytuj z linkiem i datą, nie z pamięci. Nie umiesz sprawdzić: `unknown`.

## Zastosowanie

- README, raporty, opisy projektów, wiadomości: skanuj słowa „SOTA, najlepszy, świat, breakthrough, gwarantuje”. Zamień na status z tabeli.
- Projekt badawczy (`osa-agent-sim-world`): każdy wynik ma status; hipotezy oddziel od ustaleń.
- Wynik zapisany w repo z komendą odtworzenia (`osa-evals`, `osa-verify-run`).

## Nie

- Marketingowych superlatywów bez pomiaru.
- Mieszania celu z osiągnięciem w jednym zdaniu.
- Uśredniania po najlepszych przebiegach (cherry-picking).
