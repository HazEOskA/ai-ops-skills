---
name: "osa-debug-bisect"
description: "Diagnoza błędu metodą dowodu: odtworzenie, zawężenie (git bisect, minimalny przypadek), hipoteza sprawdzona pomiarem, poprawka i test regresyjny. Użyj przy „nie działa”, błędach, nieznanych regresjach. Triggers: bug, debug, not working, error, crash, regression, bisect, nie działa, błąd."
---

# Diagnoza błędu

Najpierw diagnoza, nie poprawka. Zgadywanie przyczyny jest zakazane: przyczyna to hipoteza, dopóki jej nie zmierzysz.

## Procedura

1. **Odtwórz.** Dokładne kroki, wejście, środowisko, wersje. Nie da się odtworzyć: zapytaj o brakujące dane (log, wersja, konfiguracja). Nie zgaduj.
2. **Zbierz fakty.** Pełny komunikat błędu, stack trace, log z czasem. `osa-observability-slo` dla logów produkcyjnych.
3. **Zawęź.** Minimalny przypadek. Regresja: `git bisect` (`git bisect start; git bisect bad; git bisect good <sha>; git bisect run <komenda testu>`).
4. **Hipoteza → test.** Jedna hipoteza naraz, sprawdzona pomiarem lub eksperymentem, który ją obala. Zapisz, co wykluczono.
5. **Poprawka minimalna** w granicach zakresu (`osa-scope-guard`) i **test regresyjny**, który pada bez poprawki (`osa-verify-run`).
6. **Root Cause** do raportu (`osa-report-format`): jedno zdanie, dowód.

## Nie

- Poprawki „na oko” bez odtworzenia.
- Wielu zmian naraz (nie wiesz, która pomogła).
- Ogłoszenia naprawy bez uruchomienia odtworzenia po poprawce.
- Zwalania na środowisko bez dowodu.

Awaria produkcyjna z użytkownikami w tle: `osa-incident-response` idzie pierwsza (najpierw ograniczenie szkód, potem przyczyna).

## Karty (references/cards.md)

- **I11** · Debugowanie — gdy: błąd nie do odtworzenia, dziwne zachowanie
- **Q02** · Diagnostyka Linuksa (pierwsze 60 sekund) — gdy: serwer wolny, obciążony, „coś zżera zasoby”
- **N04** · Profilowanie — gdy: optymalizacja, wąskie gardło

Wczytaj tylko karty pasujące do zadania (grep po ID).
