# Karty: osa-debug-bisect

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### I11 · Debugowanie
**Gdy:** błąd nie do odtworzenia, dziwne zachowanie.
**Twarde:** najpierw odtwórz, potem naprawiaj — naprawa bez odtworzenia to zgadywanie; zawężaj przez bisekcję (kod, dane, czas, konfiguracja), nie przez czytanie wszystkiego; zmieniaj jedną rzecz naraz; różnica działa/nie działa jest cenniejsza niż sam przypadek błędny; `git bisect` gdy wiadomo, że kiedyś działało; loguj hipotezy, bo po godzinie zapomnisz, co już wykluczyłeś.
**Ekspert wie:** Najkrótsza droga to zawężanie przestrzeni bisekcją (commit, dane wejściowe, konfiguracja, warstwa) zamiast czytania. Hipoteza, którą można sfalsyfikować jednym poleceniem, jest warta więcej niż trzy „prawdopodobne” zmiany naraz.
**Sprawdź:** minimalny przypadek odtwarzający + `git bisect run <skrypt>`
**Nie:** poprawka, która „chyba pomogła" bez zrozumienia przyczyny; trzy zmiany naraz; debugowanie na produkcji, gdy da się odtworzyć lokalnie.

### Q02 · Diagnostyka Linuksa (pierwsze 60 sekund)
**Gdy:** serwer wolny, obciążony, „coś zżera zasoby”.
**Twarde:** kolejność: `uptime` (load vs liczba CPU) → `dmesg -T | tail` (OOM, błędy dysku) → `vmstat 1` (run queue, swap, iowait) → `mpstat -P ALL 1` (nierówne rdzenie) → `pidstat 1` → `iostat -xz 1` (await, %util) → `free -m` → `sar -n DEV 1` / `ss -s`; metoda USE: dla każdego zasobu wykorzystanie, nasycenie, błędy.
**Ekspert wie:** wysoki load przy niskim CPU to procesy w stanie D (czekające na I/O), nie „za mało CPU”; `%util` 100% na dysku SSD/NVMe nie oznacza nasycenia — patrz na `await` i głębokość kolejki.
**Sprawdź:** powyższa sekwencja wklejona jako dowód przed jakąkolwiek zmianą.
**Nie:** restart jako diagnoza; wniosek z `top` bez sprawdzenia iowait i dmesg.

### N04 · Profilowanie
**Gdy:** optymalizacja, wąskie gardło.
**Twarde:** mierz przed zmianą i po, na tym samym obciążeniu; profil próbkujący na start (tani, reprezentatywny), instrumentacja gdy potrzeba szczegółu; flame graph pokazuje prawdę szybciej niż czytanie kodu; optymalizuj to, co dominuje profil, a nie to, co wygląda nieelegancko; wydajność mierzona na debug buildzie jest bezwartościowa.
**Ekspert wie:** Profil próbkujący (perf, py-spy) ma niski narzut i pokazuje, gdzie jest czas na CPU, ale nie czas czekania (off-CPU). Wolne zapytanie bez zużycia CPU wymaga profilu off-CPU albo śledzenia.
**Sprawdź:** `perf record -g` / `py-spy` / profiler platformy + porównanie dwóch profili.
**Nie:** mikrooptymalizacja przy 95% czasu w I/O; jeden pomiar bez powtórzeń; wnioski z benchmarku bez rozgrzewki.
