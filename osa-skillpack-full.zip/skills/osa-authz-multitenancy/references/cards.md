# Karty: osa-authz-multitenancy

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### B07 · Uwierzytelnianie i autoryzacja
**Gdy:** logowanie, tokeny, role, uprawnienia, multi-tenant.
**Twarde:** Authorization Code + PKCE dla SPA i mobile, Client Credentials dla server-to-server; token dostępowy krótki, refresh rotowany z wykrywaniem reuse; token w httpOnly cookie, nie w localStorage; `alg` z whitelisty; autoryzacja przy każdym dostępie do zasobu, nie przy endpoincie; izolacja tenanta wymuszona w warstwie danych.
**Ekspert wie:** Większość incydentów autoryzacji to IDOR: endpoint sprawdza, że użytkownik jest zalogowany, ale nie że zasób należy do niego. Jedyna skuteczna obrona to test w CI, który bierze token użytkownika A i odpytuje o identyfikatory użytkownika B na każdym endpoincie.
**Sprawdź:** token użytkownika A na zasobie użytkownika B musi dać 403/404 — jako test w CI, nie ręczny curl.
**Nie:** `tenant_id` brany z body zamiast z tokena; rola zamrożona w tokenie na 30 dni; różne komunikaty dla złego hasła i nieistniejącego konta.

### B16 · Multi-tenancy
**Gdy:** wielu klientów w jednym systemie.
**Twarde:** wybierz model świadomie: wspólny schemat z `tenant_id` (najtańszy, największe ryzyko wycieku), schemat per tenant, baza per tenant (najdroższy, najłatwiejszy do izolacji i eksportu); izolację wymuś mechanicznie — RLS albo obowiązkowy filtr w warstwie repozytorium; klucze cache i pliki też mają tenanta.
**Ekspert wie:** RLS w Postgresie wymaga, żeby połączenie ustawiało kontekst tenanta (`SET LOCAL`), a przy poolerze w trybie transaction musi to być w tej samej transakcji. Właściciel tabeli omija RLS, chyba że jest `FORCE ROW LEVEL SECURITY`; superuser i rola z BYPASSRLS omijają je zawsze — test musi łączyć się rolą aplikacji, nie administratora.
**Sprawdź:** test integracyjny, który próbuje odczytu bez kontekstu tenanta i musi paść.
**Nie:** poleganie na tym, że programista pamięta o `WHERE tenant_id`; migracje uruchamiane na części tenantów; brak planu na eksport i usunięcie danych jednego klienta.

### C09 · Retencja i RODO
**Gdy:** dane osobowe, żądanie usunięcia, audyt.
**Twarde:** każdy zbiór ma podstawę przetwarzania, właściciela i okres retencji; usunięcie musi objąć backupy, logi, cache, hurtownię i systemy zewnętrzne — wypisz je zawczasu; pseudonimizacja to nie anonimizacja; eksport danych użytkownika jako funkcja, nie jako operacja ręczna.
**Ekspert wie:** Największe ryzyko RODO leży w kopiach, nie w bazie głównej: logi, backupy, hurtownia, narzędzia analityczne, eksporty CSV, cache. Mapę przepływów danych osobowych zrób, zanim przyjdzie pierwsze żądanie usunięcia — wtedy termin (miesiąc) już biegnie.
**Sprawdź:** przejdź ścieżkę usunięcia jednego konta i policz systemy, w których dane zostały.
**Nie:** dane osobowe w logach aplikacyjnych; brak retencji na logach; „usunięte" oznaczone flagą, przy zachowaniu danych w hurtowni.
