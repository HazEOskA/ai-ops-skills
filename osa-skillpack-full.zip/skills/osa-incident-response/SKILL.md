---
name: "osa-incident-response"
description: "Reakcja na incydent produkcyjny: ograniczenie skutków, komunikacja, diagnoza, przywrócenie, postmortem bez szukania winnych. Użyj przy awarii, alercie, wycieku, przestoju. Triggers: incident, outage, down, alert, postmortem, SEV, awaria, przestój, wyciek."
---

# Reakcja na incydent

Kolejność: **ogranicz → przywróć → zrozum → napraw trwale → naucz się.** Diagnoza przyczyny nie blokuje przywrócenia usługi.

## Procedura

1. **Ogłoś** i nadaj wagę (SEV1 użytkownicy nie mogą korzystać, SEV2 degradacja, SEV3 kosmetyka). Jeden dowodzący (solo: Ty i Osa jako zatwierdzający).
2. **Ogranicz**: rollback ostatniej zmiany (`osa-deploy-validation`), wyłączenie flagi, odcięcie ruchu. Akcje kosztowne lub nieodwracalne: zgoda (`osa-god-layer-approvals`), chyba że Osa wcześniej dał zasadę na ten przypadek.
3. **Fakty**: oś czasu (co zmieniono, kiedy zaczęło się psuć), logi, metryki. Bez zgadywania (`osa-debug-bisect`).
4. **Przywróć** i potwierdź smoke testem (`osa-deploy-validation`).
5. **Wyciek danych lub sekretów**: rotuj klucze natychmiast (`osa-secrets-hygiene`), oceń zakres, zapisz, co i kiedy uciekło. Obowiązki prawne (RODO, NIS2): zobacz `osa-domain-library` (Y), to orientacja, nie porada prawna.
6. **Postmortem** w ciągu kilku dni: `assets/postmortem_template.md`. Przyczyna systemowa, nie osoba. Akcje z właścicielem i terminem.

## Nie

- Deploya „szybkiej poprawki” w trakcie incydentu bez rollbacku w zanadrzu.
- Wielu zmian naraz.
- Ogłoszenia końca incydentu bez dowodu z uruchomienia.

## Karty (references/cards.md)

- **J01** · Incydent — gdy: produkcja padła
- **J02** · Postmortem — gdy: po awarii, w ciągu 48 godzin
- **J03** · Oncall — gdy: dyżury, zmęczenie alertami
- **J04** · Runbook — gdy: procedura powtarzalna, przygotowanie do dyżuru
- **H09** · Reakcja na wyciek — gdy: podejrzenie kompromitacji, wyciek sekretu

Wczytaj tylko karty pasujące do zadania (grep po ID).
