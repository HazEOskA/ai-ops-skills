# Postmortem: <krótki tytuł> (SEV?)

Data incydentu: YYYY-MM-DD · Czas trwania: ? · Wpływ: ? (użytkownicy, dane, pieniądze; wpisz unknown, jeśli nie zmierzono)

## Oś czasu (czas — zdarzenie — źródło dowodu)

## Przyczyna (systemowa, z dowodem)

## Co zadziałało / co nie

## Jak wykryto (i jak mogło wykryć się wcześniej)

## Akcje (właściciel · termin · dowód wykonania)

## Czego nie wiemy (unknown)
