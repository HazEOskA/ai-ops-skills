# Karty: osa-incident-response

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### J01 · Incydent
**Gdy:** produkcja padła.
**Twarde:** najpierw przywróć, potem zrozum — rollback jest właściwą pierwszą reakcją, nawet bez diagnozy; jedna osoba dowodzi; oś czasu prowadzona na bieżąco; sprawdzaj w kolejności: ostatni deploy, flagi, migracje, zależności, wysycenie, certyfikaty i limity; komunikuj wcześnie bez pełnej wiedzy; nie zmieniaj wielu rzeczy naraz.
**Ekspert wie:** Rollback jest właściwą pierwszą reakcją, gdy incydent zaczął się po wdrożeniu — diagnoza po przywróceniu. Jedna osoba dowodzi, druga wykonuje, trzecia prowadzi oś czasu; każdą zmianę zapisuj z godziną, bo później nie rozróżnisz skutku od przyczyny.
**Sprawdź:** `git log --since="6 hours ago" --oneline`; `kubectl get events --sort-by=.lastTimestamp | tail -50`
**Nie:** diagnoza przed przywróceniem, gdy rollback jest dostępny; dwie osoby naprawiające bez koordynacji; cisza wobec użytkowników.

### J02 · Postmortem
**Gdy:** po awarii, w ciągu 48 godzin.
**Twarde:** bez winnych — człowiek, który wcisnął deploy, nie jest przyczyną; przyczyną jest system, który na to pozwolił; wpływ wyrażony liczbami (ilu, jak długo, ile transakcji); osobno oceń wykrycie — jeśli dowiedzieliście się od klienta, to odrębny defekt; maksimum 3–5 działań z właścicielem i terminem; „dlaczego" ciągnij do warstwy systemowej.
**Ekspert wie:** Pytaj, dlaczego system pozwolił na błąd i dlaczego nie wykrył go wcześniej, nie kto go popełnił. Działania bez właściciela i terminu są życzeniem — trzy z terminem lepsze niż dwadzieścia bez.
**Sprawdź:** czas do wykrycia i czas do mitygacji jako liczby w dokumencie.
**Nie:** „root cause: błąd ludzki"; dwadzieścia działań bez właścicieli; postmortem pisany tydzień później z pamięci.

### J03 · Oncall
**Gdy:** dyżury, zmęczenie alertami.
**Twarde:** alert budzący człowieka musi mieć akcję i runbook, inaczej to log; mierz liczbę wybudzeń na dyżur i traktuj wzrost jako defekt systemu; rotacja z realnym odpoczynkiem po nocy; przekazanie dyżuru z listą otwartych spraw; uprawnienia dyżurnego wystarczające do naprawy bez eskalacji o trzeciej w nocy.
**Ekspert wie:** Zmęczenie alertami niszczy dyżur skuteczniej niż awarie: jeśli większość alertów nie wymaga działania, wyłącz je albo zamień na raport. Solo operator potrzebuje dodatkowo alertu na brak sygnału (heartbeat, dead man’s switch), bo cisza może znaczyć, że monitoring też padł.
**Sprawdź:** liczba alertów per dyżur i odsetek tych, które wymagały działania.
**Nie:** alerty bez runbooka; dyżur jednej osoby bez zastępstwa; alert na e-mail w nocy.

### J04 · Runbook
**Gdy:** procedura powtarzalna, przygotowanie do dyżuru.
**Twarde:** dokładne komendy do skopiowania, nie opis intencji; warunki wejścia i wyjścia; co zrobić, gdy krok się nie uda; ścieżka eskalacji z nazwiskiem i kanałem; runbook testowany przez kogoś, kto go nie pisał; data ostatniej weryfikacji widoczna.
**Ekspert wie:** Runbook napisany przez autora systemu pomija to, co dla niego oczywiste — testuje go ktoś, kto go nie pisał, a data ostatniego wykonania stoi w nagłówku. Runbook sprzed roku jest podejrzany.
**Sprawdź:** ktoś inny wykonuje procedurę wyłącznie z runbooka, bez pytań.
**Nie:** „zrestartuj usługę" bez podania jak; runbook bez daty weryfikacji; procedura opisana tylko w głowie jednej osoby.

### H09 · Reakcja na wyciek
**Gdy:** podejrzenie kompromitacji, wyciek sekretu.
**Twarde:** zakładaj kompromitację, dopóki nie udowodnisz inaczej; rotuj sekret natychmiast, dopiero potem analizuj zasięg; zachowaj dowody przed czyszczeniem (obrazy, logi, snapshoty); sekret w publicznym repo traktuj jako przejęty w ciągu minut, niezależnie od tego jak szybko usunąłeś commit; obowiązki zgłoszeniowe mają twarde terminy — sprawdź je zanim będą potrzebne.
**Ekspert wie:** Kolejność: unieważnij (rotacja), zabezpiecz dowody, ustal zasięg, dopiero potem sprzątaj. Sekret w publicznym repo skanują boty w minutach, a obowiązek zgłoszenia naruszenia danych osobowych (RODO — 72 godziny od stwierdzenia) biegnie od wykrycia.
**Sprawdź:** oś czasu dostępu do zasobu w logach audytowych od momentu ujawnienia.
**Nie:** usunięcie commita jako „naprawa"; analiza przed rotacją; czyszczenie systemu przed zebraniem dowodów.
