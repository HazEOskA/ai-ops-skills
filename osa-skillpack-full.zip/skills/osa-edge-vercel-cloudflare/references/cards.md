# Karty: osa-edge-vercel-cloudflare

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### F05 · Edge i Cloudflare
**Gdy:** Workers, edge functions, ochrona przed ruchem.
**Twarde:** edge nadaje się do transformacji, autoryzacji i cache — nie do ciężkich obliczeń ani do stanu; limity czasu CPU są ostre; zimne starty są małe, ale dostęp do bazy z edge bywa wolniejszy niż z regionu; WAF i rate limiting przed aplikacją to najtańsza warstwa obrony.
**Ekspert wie:** Workers mają limity CPU na żądanie i nie zachowują stanu w pamięci między żądaniami — stan trzymasz w KV, Durable Objects lub D1, a KV jest ostatecznie spójne. Jeśli logika czyta bazę w innym regionie, edge nie skróci opóźnienia.
**Sprawdź:** czas odpowiedzi z kilku regionów + zużycie CPU na wywołanie.
**Nie:** logika biznesowa wymagająca bazy w regionie, przeniesiona na edge; założenie, że edge zastąpi backend.

### F11 · DNS i TLS
**Gdy:** domena, certyfikat, migracja, wygasły cert.
**Twarde:** TTL obniż na dobę przed migracją, podnieś po; certyfikaty odnawiane automatycznie z alertem na 30 dni przed wygaśnięciem (wygasły cert to klasyczna cicha awaria); CAA, SPF, DKIM i DMARC ustawione zanim wyślesz pierwszego maila; propagacja to nie magia, to TTL.
**Ekspert wie:** Wygasły certyfikat to awaria w pełni przewidywalna — alert 30 dni przed `notAfter` i monitoring całego łańcucha, nie tylko liścia. Zmiana rekordu przy TTL 86400 to do doby niespójności u części klientów, więc TTL obniżasz z wyprzedzeniem.
**Sprawdź:** `dig +trace domena`, `openssl s_client -connect host:443 -servername host </dev/null | openssl x509 -noout -dates`
**Nie:** migracja przy TTL 86400; certyfikat odnawiany ręcznie; brak monitoringu daty wygaśnięcia.

### F12 · CDN i cache HTTP
**Gdy:** cache brzegowy, „stara wersja u użytkownika".
**Twarde:** statyki z hashem w nazwie i długim `max-age` plus `immutable`; HTML nigdy długo cache'owany; `stale-while-revalidate` dla treści; unieważnianie po tagach, nie przez czyszczenie wszystkiego; `Vary` ustawiony świadomie — zły `Vary` niszczy skuteczność cache; ciasteczka wyłączają cache brzegowy.
**Ekspert wie:** Ciasteczka i `Set-Cookie` wyłączają cache brzegowy. Hash w nazwie pliku z `immutable` pozwala na rok cache, ale HTML musi być krótki lub z rewalidacją, inaczej użytkownik dostaje stary HTML wskazujący nieistniejące zasoby.
**Sprawdź:** `curl -sSI $URL | grep -iE 'cache-control|age|vary|cf-cache-status'`
**Nie:** cache HTML z długim TTL; purge całego CDN przy każdym deployu; te same nazwy plików między wersjami.
