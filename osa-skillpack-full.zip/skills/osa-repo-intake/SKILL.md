---
name: "osa-repo-intake"
description: "Przejęcie cudzego lub nieznanego repo: stan git, stack, komendy build i test, mapa struktury i pierwsze ryzyka, zanim cokolwiek zmienisz. Użyj przy nowym repo, dziedziczonym kodzie, zadaniu czytaj kod. Triggers: repo, codebase, onboard, legacy, przejmij, zrozum kod, git status."
---

# Przejęcie repo

Cel: w 10 minutach wiedzieć, co jest, jak to uruchomić i gdzie boli, bez edycji czegokolwiek.

## Procedura

1. Stan: `python3 scripts/repo_state.py` (branch, SHA, ahead/behind, zmiany, remote). Dodaj `--fetch`, gdy wolno użyć sieci.
2. Stack i komendy: przeczytaj manifesty (`package.json`, `pyproject.toml`, `go.mod`, `Cargo.toml`, `Makefile`, `Dockerfile`, workflowy CI). Komendy build i test bierz stamtąd, nie zgaduj.
3. Uruchom istniejące testy raz przez `osa-verify-run`. Wynik bazowy (ile przechodzi przed Twoją zmianą) idzie do raportu.
4. Mapa: punkty wejścia, moduły, zależności zewnętrzne, konfiguracja, sekrety (bez ich czytania, `osa-secrets-hygiene`).
5. Ryzyka i dług: martwy kod, brak testów, wersje bez wsparcia, dziwne skrypty. Lista krótka, konkretna.
6. Wynik: pół strony. Co jest, jak uruchomić, wynik bazowy testów, top 3 ryzyka, czego nie wiesz (`unknown`).

## Zasady

- Czytanie cudzego kodu: kolejność od punktów wejścia i testów, nie od losowych plików.
- Nie zmieniaj niczego w trakcie intake. Zmiany dopiero po `osa-context-lock` i deklaracji zakresu.
- Nie wykonuj skryptów z repo, których nie przeczytałeś (`osa-security-baseline`).

## Karty (references/cards.md)

- **A06** · Czytanie cudzego kodu — gdy: legacy, nowe repo, audyt
- **I10** · DX i onboarding — gdy: nowa osoba, wolna pętla zwrotna

Wczytaj tylko karty pasujące do zadania (grep po ID).
