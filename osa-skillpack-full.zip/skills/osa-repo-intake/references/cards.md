# Karty: osa-repo-intake

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### A06 · Czytanie cudzego kodu
**Gdy:** legacy, nowe repo, audyt.
**Twarde:** zacznij od punktów wejścia i granic (routing, main, migracje, CI), nie od plików alfabetycznie; prześledź jedno realne żądanie od wejścia do bazy; historia gita mówi więcej niż komentarze.
**Ekspert wie:** Najszybsza mapa cudzego repo to `git log --stat` dla najczęściej zmienianych plików oraz testy: pliki zmieniane razem pokazują prawdziwe granice modułów, a testy — zachowanie, na którym ktoś polega.
**Sprawdź:** `git log --format='%h %ad %s' --date=short -20; git log --pretty= --name-only | sort | uniq -c | sort -rn | head -20`
**Nie:** ocena jakości przed zrozumieniem ograniczeń, w których to powstało; refactor przed prześledzeniem jednej ścieżki.

### I10 · DX i onboarding
**Gdy:** nowa osoba, wolna pętla zwrotna.
**Twarde:** cel: uruchomienie projektu jedną komendą i pierwszy merge w pierwszym tygodniu; mierz czas od klonowania do działającego środowiska; pętla zwrotna developera (zapis → wynik) to najważniejsza metryka produktywności, ważniejsza niż czas CI; środowisko lokalne bez ręcznych kroków w Confluence.
**Ekspert wie:** Czas od `git clone` do zielonych testów to najlepszy pojedynczy wskaźnik kondycji projektu — mierz go na świeżej maszynie lub w kontenerze. Każdy ręczny krok w instrukcji jest błędem czekającym na nowego człowieka (albo agenta).
**Sprawdź:** świeży klon na czystej maszynie z pomiarem czasu do uruchomienia.
**Nie:** instrukcja setupu na 40 kroków; „zapytaj Marka, on wie"; różnice między środowiskami członków zespołu.
