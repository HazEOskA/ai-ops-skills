#!/usr/bin/env python3
"""Stan repo git w jednym bloku. Exit 0 = repo git, 2 = nie repo.

Użycie: python3 repo_state.py [--repo .] [--fetch]
"""
import argparse, subprocess, sys


def git(repo, *args):
    r = subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True)
    return (r.returncode, r.stdout.strip(), r.stderr.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--fetch", action="store_true")
    a = ap.parse_args()
    rc, top, err = git(a.repo, "rev-parse", "--show-toplevel")
    if rc:
        print("To nie jest repo git (albo brak git):", err or "unknown")
        sys.exit(2)
    if a.fetch:
        rc2, _, e2 = git(a.repo, "fetch", "--quiet")
        if rc2:
            print("UWAGA: fetch nieudany:", e2)
    _, branch, _ = git(a.repo, "rev-parse", "--abbrev-ref", "HEAD")
    rc, sha, _ = git(a.repo, "rev-parse", "HEAD")
    _, dirty, _ = git(a.repo, "status", "--porcelain")
    _, remotes, _ = git(a.repo, "remote", "-v")
    up_rc, up, _ = git(a.repo, "rev-parse", "--abbrev-ref", "@{u}")
    ahead = behind = "unknown"
    if up_rc == 0:
        _, lr, _ = git(a.repo, "rev-list", "--left-right", "--count", "HEAD...@{u}")
        try:
            ahead, behind = lr.split()
        except ValueError:
            pass
    print(f"repo:     {top}")
    print(f"branch:   {branch}")
    print(f"SHA:      {sha if rc == 0 else 'brak commitów'}")
    print(f"upstream: {up if up_rc == 0 else 'brak'}   ahead: {ahead}   behind: {behind}" + ("" if a.fetch else "   (bez fetch: może być nieaktualne)"))
    print(f"zmiany:   {len(dirty.splitlines())} plików niezacommitowanych")
    for l in dirty.splitlines()[:20]:
        print("  ", l)
    print("remote:  ", remotes.replace("\n", " | ") if remotes else "brak")


if __name__ == "__main__":
    main()
