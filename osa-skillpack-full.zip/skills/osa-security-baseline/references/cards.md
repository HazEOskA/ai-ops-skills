# Karty: osa-security-baseline

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### H01 · Model zagrożeń
**Gdy:** nowy system, przegląd bezpieczeństwa.
**Twarde:** cztery pytania w 30 minut: co jest cenne, kto to chce, przez co wejdzie, co zauważymy; przeciwnik oportunistyczny (skanery, boty) to inny przeciwnik niż ukierunkowany — broń się najpierw przed pierwszym; wypisz powierzchnię publiczną jako listę, nie jako „strona i API"; największym ryzykiem zwykle jest tożsamość i zależności, nie egzotyczne exploity.
**Ekspert wie:** Największe realne ryzyko to zwykle skradzione poświadczenia i nadmierne uprawnienia, nie exploit zero-day. Zacznij od pytania „co się stanie, gdy ten token wycieknie” dla każdego sekretu i konta usługi.
**Sprawdź:** lista powierzchni publicznej porównana z rzeczywistym skanem portów i subdomen.
**Nie:** trzydziestostronicowy dokument zamiast czterech odpowiedzi; skupienie na exploitach przy otwartym panelu admina.

### H02 · OWASP w praktyce
**Gdy:** przegląd aplikacji webowej.
**Twarde:** najczęstsze realne dziury to złamana kontrola dostępu (IDOR), błędna konfiguracja i podatne zależności — sprawdź je najpierw; autoryzacja przy każdym zasobie, nie przy endpointcie; walidacja wejścia po stronie serwera zawsze; nagłówki bezpieczeństwa (CSP, HSTS, X-Frame-Options) ustawione i zweryfikowane; SSRF przy każdym miejscu, gdzie serwer pobiera URL od użytkownika.
**Ekspert wie:** Najczęstsza dziura to brak sprawdzenia własności zasobu (IDOR/BOLA) oraz mass assignment (klient ustawia w body pole `role`). Testuj to jako zachowanie w CI, bo skaner tego nie widzi.
**Sprawdź:** `curl -sSI $URL | grep -iE 'content-security|strict-transport|x-frame'` + test IDOR z tokenem innego użytkownika.
**Nie:** poleganie na ukryciu endpointu; walidacja tylko po stronie klienta; pobieranie dowolnego URL-a podanego przez użytkownika bez whitelisty.

### H03 · Injection
**Gdy:** SQL, komendy, szablony, LDAP, XSS.
**Twarde:** parametryzacja zamiast sklejania — zawsze, bez wyjątków dla „zaufanych" danych; nazwy tabel i kolumn nie da się sparametryzować, więc whitelista; escaping dopasowany do kontekstu wyjścia (HTML, atrybut, JS, URL to cztery różne konteksty); CSP jako druga warstwa przy XSS; komendy systemowe bez powłoki, z tablicą argumentów.
**Ekspert wie:** Injection drugiego rzędu: dane bezpiecznie zapisane trafiają potem do zapytania sklejanego w innym miejscu. Parametryzacja obowiązuje przy każdym odczycie i zapisie, a `ORDER BY` z parametru użytkownika wymaga whitelisty kolumn.
**Sprawdź:** wstrzyknięcie znaków kontrolnych w każde pole wejściowe + test XSS w polach renderowanych jako HTML.
**Nie:** escaping ręczny zamiast parametryzacji; `shell=True` z danymi użytkownika; założenie, że dane z własnej bazy są bezpieczne (second-order injection).

### H05 · Supply chain
**Gdy:** zależności, obrazy, CI.
**Twarde:** lock file commitowany, zależności przypięte, obrazy bazowe do digestu; skan w CI z blokadą na krytyczne; SBOM generowany przy buildzie; uprawnienia w CI minimalne — workflow z dostępem do sekretów nie powinien uruchamiać kodu z forka; nowa zależność to decyzja, nie odruch (sprawdź maintainerów i częstotliwość wydań).
**Ekspert wie:** Zależności przechodnie to większość powierzchni. `npm audit` widzi znane CVE, ale nie przejęcie konta maintainera — pomaga lockfile z sumami, blokada skryptów instalacyjnych tam, gdzie się da, i przegląd zmian przy aktualizacji zależności o dużym zasięgu.
**Sprawdź:** `trivy fs --scanners vuln,secret,misconfig .`, `syft . -o spdx-json`, `npm audit --audit-level=high`
**Nie:** automatyczna aktualizacja zależności mergowana bez testów; `curl | bash` w pipeline; zależność z jednym maintainerem w krytycznej ścieżce bez planu B.

### H06 · Hartowanie środowiska
**Gdy:** przygotowanie do produkcji.
**Twarde:** MFA na wszystkich kontach z dostępem do produkcji; konto root/global admin zablokowane z alertem na użycie; uprawnienia przycięte do faktycznie używanych, mierzone a nie deklarowane; logi audytowe w osobnym koncie z retencją (atakujący najpierw czyści logi); domyślne hasła i konta usunięte; dostęp administracyjny przez VPN/IAP, nie przez nieoczywisty URL.
**Ekspert wie:** Kompromitacja jednego konta CI albo laptopa ze stałym kluczem to typowy początek włamania. Dostęp administracyjny przez tożsamość (SSO, IAP) z MFA odporną na phishing (klucz sprzętowy, passkey) i krótkotrwałe poświadczenia ograniczają zasięg.
**Sprawdź:** przegląd realnie używanych uprawnień vs nadanych + próba dostępu do panelu spoza sieci.
**Nie:** uprawnienia nadane szeroko „żeby odblokować" z zamiarem przycięcia później; logi w tym samym koncie co system; panel chroniony wyłącznie adresem.

### H07 · Audyt i pentest
**Gdy:** zamawiasz albo robisz przegląd.
**Twarde:** ustal zakres i zasady zaangażowania na piśmie przed startem; testy na środowisku odzwierciedlającym produkcję, z danymi syntetycznymi; wynik bez priorytetyzacji według realnego ryzyka jest bezużyteczny; retest po naprawie jest częścią zlecenia, nie dodatkiem; automatyczny skan to nie pentest.
**Ekspert wie:** Raport bez retestu nie zamyka ryzyka. Ustal, czy zlecasz test czarnej skrzynki (co widzi obcy), czy szarej (z kontem) — wyniki i koszty różnią się znacząco, a skan automatyczny nie znajdzie błędów logiki biznesowej.
**Sprawdź:** lista ustaleń z oceną wykorzystywalności i wpływu, nie tylko z oceną CVSS.
**Nie:** pentest na produkcji bez zgody i okna; raport zamknięty bez retestu; traktowanie skanu podatności jako audytu.

### H08 · Compliance
**Gdy:** SOC 2, ISO, RODO, wymagania klienta.
**Twarde:** zgodność to nie bezpieczeństwo — można mieć certyfikat i być dziurawym; zacznij od rejestru danych i przepływów, bo z niego wynika reszta; dowody zbierane automatycznie z systemów, nie kompletowane przed audytem; polityka, której nikt nie stosuje, jest gorsza niż jej brak, bo tworzy fałszywe poczucie porządku.
**Ekspert wie:** Kontrole zbierające dowody automatycznie (logi zmian, konfiguracje, przeglądy dostępów) są tańsze niż przygotowanie przed audytem. Audytor pyta o próbkę — losowa kontrola musi mieć dowód dostępny w minuty.
**Sprawdź:** czy dowód dla losowo wybranej kontroli da się wygenerować z systemu w 5 minut.
**Nie:** polityki kopiowane z szablonu bez dopasowania; przygotowanie do audytu jako projekt jednorazowy; certyfikat traktowany jako cel zamiast jako skutek.

### S04 · VPN i zero trust
**Gdy:** dostęp do zasobów wewnętrznych, praca zdalna, sieć między serwerami.
**Twarde:** zero trust = każde żądanie uwierzytelnione i autoryzowane po tożsamości i stanie urządzenia, nie po tym, że jest „w sieci”; dla dostępu admina: proxy tożsamościowe (IAP, Cloudflare Access, Tailscale ACL) zamiast otwartych portów; WireGuard jako prosty i szybki tunel; segmentacja sieci ogranicza zasięg włamania.
**Ekspert wie:** płaska sieć VPN, w której każdy widzi wszystko, to najczęstsza ścieżka od jednego skompromitowanego laptopa do całej infrastruktury.
**Sprawdź:** z konta zwykłego użytkownika VPN — skan, co jest osiągalne.
**Nie:** SSH wystawione na świat z hasłem; VPN jako jedyna warstwa ochrony paneli.
