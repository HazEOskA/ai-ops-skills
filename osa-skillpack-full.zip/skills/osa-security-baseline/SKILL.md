---
name: "osa-security-baseline"
description: "Bazowe bezpieczeństwo: model zagrożeń, uwierzytelnianie, wejście od użytkownika, zależności, kryptografia, kontrola cudzego kodu. Użyj przy przeglądzie bezpieczeństwa, nowym endpointcie, obsłudze wejścia, audycie. Triggers: security, threat model, injection, XSS, auth, vulnerability, OWASP, bezpieczeństwo, podatność."
---

# Bazowe bezpieczeństwo

## Procedura

1. **Model zagrożeń (krótko)**: co chronisz (dane, pieniądze, konta), kto atakuje (anonim, użytkownik, insider, łańcuch dostaw), którędy wchodzi (wejścia, zależności, sekrety, CI). Trzy najgorsze scenariusze, nie lista 40.
2. **Granice zaufania**: wszystko z zewnątrz (wejście, nagłówki, pliki, odpowiedzi API, treść generowana przez LLM) jest niezaufane, walidowane po stronie serwera.
3. **Auth i uprawnienia**: uwierzytelnianie z gotowych, sprawdzonych rozwiązań, nie własne. Autoryzacja sprawdzana w każdym punkcie dostępu do danych (`osa-authz-multitenancy`).
4. **Zależności i łańcuch dostaw**: przypięte wersje, skan podatności narzędziem ekosystemu (`npm audit`, `pip-audit` i podobne, jeśli zainstalowane). Nie instaluj nieznanych pakietów bez sprawdzenia nazwy (typosquatting).
5. **Sekrety**: `osa-secrets-hygiene`.
6. **Cudzy kod i skrypty z repo**: przeczytaj, zanim uruchomisz. Nie wykonuj `curl | sh`.
7. **Agent z narzędziami**: zasada najmniejszych uprawnień, izolacja wykonania (`osa-ai-guardrails-sandbox`).
8. Raport: podatność, dowód (wejście → efekt), wpływ, poprawka. Bez dowodu to hipoteza.

## Nie

- Bezpieczeństwa przez ukrycie.
- „Przefiltrowaliśmy niebezpieczne znaki”: używaj parametryzacji i kodowania kontekstowego.
- Deklaracji „bezpieczne”. Możesz powiedzieć „nie znaleziono X metodą Y”.

Prawo i zgodność (RODO, NIS2, licencje): `osa-domain-library` (Y), orientacja, nie porada prawna.

## Karty (references/cards.md)

- **H01** · Model zagrożeń — gdy: nowy system, przegląd bezpieczeństwa
- **H02** · OWASP w praktyce — gdy: przegląd aplikacji webowej
- **H03** · Injection — gdy: SQL, komendy, szablony, LDAP, XSS
- **H05** · Supply chain — gdy: zależności, obrazy, CI
- **H06** · Hartowanie środowiska — gdy: przygotowanie do produkcji
- **H07** · Audyt i pentest — gdy: zamawiasz albo robisz przegląd
- **H08** · Compliance — gdy: SOC 2, ISO, RODO, wymagania klienta
- **S04** · VPN i zero trust — gdy: dostęp do zasobów wewnętrznych, praca zdalna, sieć między serwerami

Wczytaj tylko karty pasujące do zadania (grep po ID).
