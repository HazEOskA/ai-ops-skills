---
name: "osa-agent-design"
description: "Projektowanie agentów AI: pętla decyzji, narzędzia, pamięć, planowanie, warunki stopu, tryby awarii i koszt. Użyj przy budowie agenta, systemu wieloagentowego, orkiestracji. Triggers: agent, multi-agent, planner, tool use, agent loop, memory, orchestration, agent AI."
---

# Projektowanie agentów

## Procedura

1. Zacznij od `osa-build-gate`: czasowniki rdzenia agenta (np. „czyta repo, uruchamia testy, proponuje zmiany”) muszą mieć narzędzia, które je *naprawdę* wykonują, nie symulują.
2. **Najprostszy agent, który działa**: pojedyncza pętla (obserwuj → decyduj → działaj → sprawdź) przed wieloagentowością. Wiele agentów uzasadnia zmierzony zysk (równoległość, izolacja kontekstu), nie moda.
3. **Warunki stopu jawne**: limit kroków, budżet tokenów i czasu, wykrywanie pętli (powtarzające się akcje), eskalacja do człowieka.
4. **Narzędzia**: wąskie, z jednoznacznym kontraktem wejścia i wyjścia (`osa-agent-tools-mcp`). Akcje nieodwracalne za bramką zgody (`osa-god-layer-approvals`).
5. **Pamięć**: co agent wie (kontekst), co zapisuje (magazyn), co zapomina. Zapis tylko rzeczy zweryfikowanych, z pochodzeniem.
6. **Weryfikacja wyniku niezależna od autora**: agent nie ocenia sam siebie. Testy, drugi agent bez wglądu w tok pracy, człowiek.
7. **Tryby awarii** wypisz przed budową: halucynowane narzędzie, pętla, dryf celu, wstrzyknięcie promptu z danych, eksplozja kosztów. Każdy z mitygacją.
8. Ocena: `osa-evals`. Bez zestawu ewaluacyjnego nie twierdź, że agent jest dobry.

## Nie

- Agenta z narzędziem „wykonaj dowolną komendę” bez sandboxa (`osa-ai-guardrails-sandbox`).
- Autonomii bez warunku stopu.
- Sukcesu ogłaszanego przez agenta bez dowodu z uruchomienia.

## Karty (references/cards.md)

- **G06** · Agenty — gdy: pętla z narzędziami, autonomia
- **R04** · Interpretery i runtime — gdy: własny silnik wykonania, VM, runtime agentów, silnik reguł

Wczytaj tylko karty pasujące do zadania (grep po ID).
