# Karty: osa-agent-design

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### G06 · Agenty
**Gdy:** pętla z narzędziami, autonomia.
**Twarde:** najprostsza architektura, która działa — większość „systemów wieloagentowych" to pętla z narzędziami plus dodatkowa warstwa awarii; twarde limity kroków, tokenów, czasu i kosztu; akcje nieodwracalne za bramką zatwierdzenia; stan trwały poza kontekstem, żeby dało się wznowić; wykrywanie zapętlenia i eskalacja; uprawnienia egzekwowane systemowo, nie promptem.
**Ekspert wie:** Agent zawodzi zwykle w długim ogonie: zapętlenie, dryf celu i akumulacja błędów w kontekście. Twarde limity kroków i budżetu, jawny warunek zakończenia i checkpoint stanu poza kontekstem są ważniejsze niż sprytniejszy prompt planera.
**Sprawdź:** ślad wykonania 10 realnych zadań z licznikiem kroków i kosztu + test próby przekroczenia uprawnień.
**Nie:** wieloagentowość jako pierwszy wybór; zabezpieczenia wyłącznie w prompcie; ocena na jednym udanym demo.

### R04 · Interpretery i runtime
**Gdy:** własny silnik wykonania, VM, runtime agentów, silnik reguł.
**Twarde:** drzewo AST jest proste, bytecode + VM szybsze o rząd wielkości; deterministyczność wymaga kontroli nad czasem, losowością i I/O (wstrzykiwane, nie globalne); limity kroków, pamięci i czasu wbudowane w pętlę wykonania; stan wykonania serializowalny, jeśli ma dać się wznowić.
**Ekspert wie:** deterministyczne powtórzenie (record/replay) jest najcenniejszą cechą runtime'u do debugowania systemów agentowych i symulacji — dodanie go później jest bardzo drogie.
**Sprawdź:** dwa uruchomienia z tym samym seedem i wejściem dają identyczny ślad.
**Nie:** `eval` jako interpreter; globalny stan w interpreterze; brak limitu kroków dla kodu z zewnątrz.
