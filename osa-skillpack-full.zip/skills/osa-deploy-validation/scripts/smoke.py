#!/usr/bin/env python3
"""Smoke test HTTP. Exit 0 = wszystkie OK, 1 = któreś nie przeszło, 2 = błąd wejścia.

Użycie: python3 smoke.py --url URL [--expect 200] [--contains TEKST] [--timeout 10] [--retries 3]
        [--max-latency-ms N]   (można powtarzać --url; --expect/--contains dotyczą wszystkich)
"""
import argparse, sys, time, urllib.request, urllib.error


def check(url, expect, contains, timeout, retries, max_ms):
    last = "brak próby"
    for attempt in range(1, retries + 1):
        t0 = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "osa-smoke/1"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                status, body = r.status, r.read(200000).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            status, body = e.code, ""
        except Exception as e:  # noqa
            last = f"próba {attempt}: {type(e).__name__}: {e}"
            time.sleep(min(2 * attempt, 5))
            continue
        ms = int((time.time() - t0) * 1000)
        problems = []
        if status != expect:
            problems.append(f"status {status} != {expect}")
        if contains and contains not in body:
            problems.append(f"brak tekstu '{contains}' w odpowiedzi")
        if max_ms and ms > max_ms:
            problems.append(f"latencja {ms}ms > {max_ms}ms")
        if not problems:
            return True, f"OK status={status} {ms}ms"
        last = f"próba {attempt}: " + "; ".join(problems)
        time.sleep(min(2 * attempt, 5))
    return False, last


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", action="append", required=True)
    ap.add_argument("--expect", type=int, default=200)
    ap.add_argument("--contains")
    ap.add_argument("--timeout", type=float, default=10)
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--max-latency-ms", type=int, default=0)
    a = ap.parse_args()
    bad = 0
    for u in a.url:
        ok, msg = check(u, a.expect, a.contains, a.timeout, a.retries, a.max_latency_ms)
        print(("PASS " if ok else "FAIL ") + u + " — " + msg)
        bad += 0 if ok else 1
    print(f"WYNIK: {len(a.url) - bad}/{len(a.url)} przeszło")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
