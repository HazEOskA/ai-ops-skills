# Karty: osa-deploy-validation

Czytaj selektywnie: `grep -n "^### <ID>" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.

### J05 · Cutover i migracja
**Gdy:** przejście na nowy system, migracja danych.
**Twarde:** okres podwójnego zapisu i porównywanie wyników przed przełączeniem; migracja danych z możliwością ponowienia i weryfikacją liczby rekordów oraz sum kontrolnych; przełączenie stopniowe (procent ruchu), nie jednorazowe; punkt bez powrotu zdefiniowany jawnie i zaakceptowany; okno wycofania z terminem.
**Ekspert wie:** Najbezpieczniejszy wzorzec to podwójny zapis albo odczyt cieniowy z porównaniem wyników przed przełączeniem. Punkt bez powrotu zdefiniuj jawnie i miej przed nim sprawdzony rollback, bo po nim koszt cofnięcia rośnie skokowo.
**Sprawdź:** porównanie starego i nowego systemu na tym samym ruchu z raportem rozbieżności.
**Nie:** migracja typu „wielki wybuch"; brak weryfikacji kompletności danych; usunięcie starego systemu w dniu przełączenia.

### F16 · Multi-region i DR
**Gdy:** wysoka dostępność, katastrofa, drugi region.
**Twarde:** zdefiniuj RTO i RPO liczbami, zanim wybierzesz architekturę — one wyznaczają koszt; active-passive z przetestowanym przełączeniem bije active-active, który nikt nie rozumie; dane replikowane asynchronicznie oznaczają utratę okna przy awarii — nazwij ile; przełączenie musi być ćwiczone, nie opisane; zależności zewnętrzne też potrzebują planu.
**Ekspert wie:** Przełączenie działa tylko wtedy, gdy ćwiczysz je razem z zależnościami (DNS, sekrety, baza, kolejki). Najczęstsza porażka DR to region zapasowy bez uprawnień, limitów albo aktualnych sekretów — o czym dowiadujesz się w trakcie katastrofy.
**Sprawdź:** ćwiczenie przełączenia z pomiarem czasu, minimum raz na kwartał.
**Nie:** multi-region bez policzonego RPO; failover automatyczny bez testu (przełączy się w złym momencie); replika, z której nikt nigdy nie czytał.

### B17 · Feature flags
**Gdy:** stopniowe wdrożenie, rozdzielenie deployu od release'u.
**Twarde:** flaga ma właściciela i datę usunięcia; domyślna wartość bezpieczna, gdy dostawca flag nie odpowiada; flagi nie zagnieżdżają się (dwie flagi to cztery ścieżki do przetestowania); killswitch dla ryzykownych funkcji.
**Ekspert wie:** Flaga bez daty usunięcia staje się trwałą gałęzią logiki, której nikt nie testuje w obu wariantach. Najgroźniejsza jest flaga włączona „tymczasowo” na produkcji, gdy ścieżka z flagą wyłączoną nie była uruchamiana od miesięcy.
**Sprawdź:** lista flag starszych niż 90 dni — powinna być pusta.
**Nie:** flaga jako trwała konfiguracja; logika biznesowa zależna od trzech flag naraz; brak testu ścieżki z flagą wyłączoną.
