---
name: "osa-deploy-validation"
description: "Walidacja wdrożenia: przed (build, konfiguracja, migracje, rollback), po (smoke test HTTP, logi, metryki) i decyzja rollback. Wdrożenie tylko za zgodą Osy. Użyj przy deployu, cutoverze, wydaniu. Triggers: deploy, release, cutover, smoke test, go live, wdrożenie, produkcja."
---

# Walidacja wdrożenia

Deploy to akcja z listy zgód (`osa-god-layer-approvals`). Ten skill przygotowuje dowód przed i po.

## Przed

1. Czysty build z zamrożonych zależności, testy zielone (`osa-verify-run`).
2. Konfiguracja i sekrety dla środowiska docelowego istnieją (nazwy, nie wartości; `osa-secrets-hygiene`). Nieznana nazwa zmiennej: zapytaj.
3. Migracje danych: kompatybilne wstecz (expand → migrate → contract), przetestowane na kopii (`osa-postgres-data`).
4. Rollback gotowy i sprawdzony: poprzedni artefakt/SHA znany, komenda cofnięcia zapisana.
5. Zgoda Osy z formatem prośby.

## Po

`python3 scripts/smoke.py --url https://host/health --expect 200 [--contains ok] [--url ...] [--retries 5]`
Exit 0 = wszystkie sprawdzenia przeszły, exit 1 = któreś nie. Wynik idzie do raportu.

Potem: logi błędów i metryki (`osa-observability-slo`) przez okno obserwacji. Ścieżka krytyczna użytkownika przepuszczona ręcznie lub testem e2e.

## Decyzja

Smoke pada albo błędy rosną: **rollback najpierw, diagnoza potem**. Zapisz powód. Status wdrożenia pisz według `osa-definition-of-done`: 200 na `/health` to `ARTIFACT_PRESENT` aplikacji, nie dowód poprawności funkcji.

## Karty (references/cards.md)

- **J05** · Cutover i migracja — gdy: przejście na nowy system, migracja danych
- **F16** · Multi-region i DR — gdy: wysoka dostępność, katastrofa, drugi region
- **B17** · Feature flags — gdy: stopniowe wdrożenie, rozdzielenie deployu od release'u

Wczytaj tylko karty pasujące do zadania (grep po ID).
