---
name: "osa-agent-sim-world"
description: "Symulacja wieloagentowa i świat emergentny: determinizm, pętla ticków, dziennik zdarzeń, pamięć agentów, metryki emergencji, ablacje, hipotezy. Użyj przy budowie i badaniu świata agentów lub AI Scientist. Triggers: simulation, multi-agent world, emergent, tick, agent society, AI scientist, symulacja, świat agentów."
---

# Świat agentów i AI Scientist

Cel projektu: generatywna symulacja wieloagentowa z emergentnym zachowaniem i agentem badawczym. To badania, więc **twierdzenia wymagają dowodu** (`osa-proof-governance`).

## Architektura minimalna (od niej zacznij)

1. **Rdzeń deterministyczny**: stan świata + krok ticka jako czysta funkcja (stan, zdarzenia, seed) → nowy stan. Jeden generator liczb losowych z seedem, zapisanym w każdym przebiegu. Ten sam seed i wejścia dają ten sam wynik (sprawdź: dwa przebiegi, porównanie skrótów stanu).
2. **Dziennik zdarzeń append-only**: każda zmiana stanu i decyzja agenta jako zdarzenie z tickiem i przyczyną. Stan da się odtworzyć z dziennika (event sourcing). To podstawa analizy i debugowania.
3. **Granica LLM**: wywołania modeli są niedeterministyczne i drogie. Zapisuj wejście i wyjście każdego wywołania (nagrywanie), by przebieg dało się odtworzyć bez modelu. Budżet tokenów na tick.
4. **Agent**: percepcja (ograniczony widok świata) → pamięć (krótka + długa, zapis tylko zweryfikowanych faktów z pochodzeniem) → decyzja → akcja walidowana przez świat. Świat jest autorytatywny: agent nie zmienia stanu bezpośrednio.
5. **Skalowanie później**: najpierw 5–10 agentów, zmierzony koszt i tick/s, potem więcej. Optymalizuj po pomiarze (`osa-distributed-systems`, `osa-observability-slo`).

## Metodologia badawcza

1. **Hipoteza zapisana przed przebiegiem**, z kryterium obalenia.
2. **Baseline i ablacje**: wyłącz mechanizm (pamięć, komunikację, ekonomię) i porównaj. „Emergencja” bez ablacji to anegdota.
3. **Metryki emergencji** zdefiniowane z góry (np. rozkład interakcji, specjalizacja ról, stabilność norm), liczone z dziennika, nie z opisu LLM.
4. **Wiele seedów**, raport z rozrzutem. Jeden imponujący przebieg to nie wynik.
5. **AI Scientist**: agent proponuje hipotezy i eksperymenty, ale wykonanie w sandboxie (`osa-ai-guardrails-sandbox`), a ocena wyniku niezależna od autora (`osa-evals`). Zatwierdzenia zmian: `osa-god-layer-approvals`.
6. Status wyników: TARGET / HYPOTHESIS / UNPROVEN / VERIFIED. Nazwy w stylu „world-first”, „SOTA” bez benchmarku: zakaz.

## Nie

- Symulacji bez seeda i dziennika (nie da się jej zbadać).
- Oceny emergencji przez LLM czytający własne logi bez metryk ilościowych.
- Skalowania przed pomiarem kosztu jednego ticka.

Powiązane: `osa-agent-design`, `osa-distributed-systems` (jeśli rozproszona), `osa-gamedev-core` (pętla, ECS, determinizm).
