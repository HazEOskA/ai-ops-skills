---
name: "osa-definition-of-done"
description: "Definicja „gotowe” oparta na dowodzie: GOTOWE tylko gdy każdy czasownik rdzenia ma dowód z uruchomienia, inaczej CZĘŚCIOWE. Użyj przed każdym stwierdzeniem, że coś działa. Triggers: done, finished, gotowe, działa, ready, complete."
---

# Definicja „gotowe”

- **GOTOWE** wolno napisać tylko gdy **każdy czasownik rdzenia** ma dowód z uruchomienia na realnym wejściu użytkownika (jedno prawdziwe repo / rekord / request przepuszczony przez cały przepływ) — poziom co najmniej `MECHANICALLY_VERIFIED`.
- Inaczej status to **CZĘŚCIOWE: <czego brakuje>** — w pierwszym zdaniu, nie w ryzykach.
- Sprawdzenie składni, udany build i opublikowany plik to `ARTIFACT_PRESENT`, nie „działa”.
- Raport końcowy zaczyna się od tabeli: czasownik rdzenia → status → dowód (komenda + wynik albo „brak”).

## Jak to zastosować

1. Weź RDZEŃ z bloku bramki (`osa-build-gate`). Nie ma bloku? Wypisz czasowniki z zamówienia teraz.
2. Dla każdego czasownika uruchom go na realnym wejściu (`osa-verify-run`) i wklej komendę plus wynik.
3. Zbuduj tabelę na początku raportu:

| Czasownik rdzenia | Status | Dowód |
|---|---|---|
| <czasownik> | GOTOWE / CZĘŚCIOWE / NIE | komenda + wynik albo „brak” |

4. Choć jeden wiersz bez dowodu: całość to **CZĘŚCIOWE: czego brakuje**, w pierwszym zdaniu.

## Drabina, skrótowo

CLAIMED → ARTIFACT_PRESENT (plik jest) → MECHANICALLY_VERIFIED (komenda przeszła, exit 0) → INDEPENDENTLY_VERIFIED (czyste środowisko). Build, składnia i opublikowany plik to najwyżej ARTIFACT_PRESENT.
