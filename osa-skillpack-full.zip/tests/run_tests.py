#!/usr/bin/env python3
"""Testy paczki: integralność kart, wierność kontraktu względem źródła, skrypty na żywych wejściach,
rozszerzalność indeksu. Exit 0 = wszystko przeszło. Wynik: tests/RESULTS.md (generowany)."""
import http.server, json, os, re, shutil, subprocess, sys, tempfile, threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SK = ROOT / "skills"
SRC = Path("/mnt/skills/plugins/osa-godmode/SKILL.md")
PY = sys.executable
results = []


def t(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (f" — {detail}" if detail else ""))


def run(args, cwd=None, timeout=60):
    r = subprocess.run(args, capture_output=True, text=True, cwd=cwd, timeout=timeout)
    return r.returncode, r.stdout + r.stderr


# ---------- integralność ----------
all_ids = {}
for f in SK.rglob("references/*.md"):
    for m in re.finditer(r"^### ([A-Z]\d\d) · ", f.read_text(encoding="utf-8"), re.M):
        all_ids.setdefault(m.group(1), []).append(str(f.relative_to(SK)))
t("215 kart w paczce", len(all_ids) == 215, f"{len(all_ids)}")
t("każda karta dokładnie w jednym pliku", all(len(v) == 1 for v in all_ids.values()))
noexp = []
for f in SK.rglob("references/*.md"):
    txt = f.read_text(encoding="utf-8")
    for blk in re.split(r"(?m)^(?=### [A-Z]\d\d · )", txt)[1:]:
        cid = blk[4:7]
        if "**Ekspert wie:**" not in blk:
            noexp.append(cid)
t("każda z 215 kart ma pole Ekspert wie", not noexp, f"brak: {noexp[:5]}")
src = SRC.read_text(encoding="utf-8")
src_expert_af = len(re.findall(r"^\*\*Ekspert wie:\*\*", src, re.M))
t("źródło miało Ekspert wie tylko w 65 kartach (O–Z)", src_expert_af == 65, f"{src_expert_af}")

# wierność kontraktu: linie z §0/§B/§D/§2 obecne dosłownie
def block(start, end_pat):
    lines = src.split("\n")
    s = next(i for i, l in enumerate(lines) if l.startswith(start))
    e = next(i for i in range(s + 1, len(lines)) if re.match(end_pat, lines[i]))
    return [l for l in lines[s + 1:e] if l.strip() and l.strip() != "---" and not l.startswith("###")]
def contains_all(skill, lines):
    body = (SK / skill / "SKILL.md").read_text(encoding="utf-8")
    missing = [l for l in lines if l not in body]
    return missing
for skill, start, endp in [("osa-honesty-contract", "## §0 ", r"^## §B "), ("osa-build-gate", "## §B ", r"^## §D "),
                           ("osa-definition-of-done", "## §D ", r"^## §1 "), ("osa-evals", "## §2 ", r"^## Nie")]:
    lines = block(start, endp) if skill != "osa-evals" else [l for l in src.split("\n")[src.split("\n").index(next(x for x in src.split("\n") if x.startswith("## §2 "))) + 1:] if l.strip()]
    if skill == "osa-honesty-contract":
        # honesty-contract zawiera podzbiór §0 (Refleksy, Bezpiecznik, Kotwica, Drabina, Zakazy) — sprawdź te bloki, bez Granicy zakresu
        lines = [l for l in lines]
        sc = contains_all("osa-scope-guard", [l for l in lines if l.startswith("Przed edycją") or l.startswith("Zero push")] or [])
        missing = contains_all(skill, [l for l in lines if not (l.startswith("Przed edycją") or l.startswith("Zero push") or l.startswith("### Granica"))])
        t("kontrakt §0 dosłownie w honesty-contract (bez Granicy zakresu)", not missing, f"brak {len(missing)}: {missing[:1]}")
        t("Granica zakresu §0 dosłownie w scope-guard", not sc)
    else:
        missing = contains_all(skill, lines)
        t(f"{skill}: blok źródłowy dosłownie", not missing, f"brak {len(missing)}: {[m[:60] for m in missing[:1]]}")

# ---------- skrypty ----------
tmp = Path(tempfile.mkdtemp(prefix="osatest-"))
repo = tmp / "repo"
repo.mkdir()
def g(*a): return subprocess.run(["git", "-C", str(repo), *a], capture_output=True, text=True)
g("init", "-q"); g("config", "user.email", "t@t"); g("config", "user.name", "t")
(repo / "a.py").write_text("print(1)\n"); (repo / "b.py").write_text("print(2)\n")
g("add", "."); g("commit", "-qm", "init")

rc, out = run([PY, str(SK / "osa-repo-intake/scripts/repo_state.py"), "--repo", str(repo)])
t("repo_state: repo git → exit 0 i SHA", rc == 0 and re.search(r"SHA:\s+[0-9a-f]{40}", out) is not None)
rc, out = run([PY, str(SK / "osa-repo-intake/scripts/repo_state.py"), "--repo", str(tmp)])
t("repo_state: nie-repo → exit 2", rc == 2, out.strip()[:60])

(repo / "a.py").write_text("print(11)\n")
(tmp / "scope.txt").write_text("a.py\n")
rc, out = run([PY, str(SK / "osa-scope-guard/scripts/scope_check.py"), "--declared", str(tmp / "scope.txt"), "--repo", str(repo)])
t("scope_check: zmiana w zakresie → exit 0", rc == 0, out.strip().splitlines()[-1])
(repo / "b.py").write_text("print(22)\n"); (repo / "new.txt").write_text("x")
rc, out = run([PY, str(SK / "osa-scope-guard/scripts/scope_check.py"), "--declared", str(tmp / "scope.txt"), "--repo", str(repo)])
t("scope_check: b.py i new.txt spoza listy → exit 1", rc == 1 and "b.py" in out and "new.txt" in out, out.strip().splitlines()[-1])
rc, out = run([PY, str(SK / "osa-scope-guard/scripts/scope_check.py"), "--declared", str(tmp / "nie-ma.txt"), "--repo", str(repo)])
t("scope_check: brak pliku deklaracji → exit 2", rc == 2)

log = tmp / "ev.jsonl"
V = str(SK / "osa-verify-run/scripts/verify.py")
rc, out = run([PY, V, "--label", "ok", "--log", str(log), "--", PY, "-c", "print('hi')"])
t("verify: komenda exit 0 → MECHANICALLY_VERIFIED", rc == 0 and "MECHANICALLY_VERIFIED" in out)
rc, out = run([PY, V, "--label", "fail", "--log", str(log), "--", PY, "-c", "import sys; sys.exit(3)"])
t("verify: exit 3 propagowany, poziom FAILED", rc == 3 and "FAILED" in out)
rc, out = run([PY, V, "--label", "to", "--timeout", "1", "--log", str(log), "--", PY, "-c", "import time; time.sleep(5)"])
t("verify: timeout → exit 124", rc == 124)
rc, out = run([PY, V, "--label", "nf", "--log", str(log), "--", "nie-istniejaca-komenda-xyz"])
t("verify: brak komendy → exit 127", rc == 127)
recs = [json.loads(l) for l in log.read_text().splitlines()]
t("verify: 4 rekordy w evidence.jsonl", len(recs) == 4 and [r["exit"] for r in recs] == [0, 3, 124, 127], str([r["exit"] for r in recs]))

sec = tmp / "sec"; sec.mkdir()
(sec / "clean.py").write_text("key = os.environ['API_KEY']\npassword = 'changeme_example'\n")
rc, out = run([PY, str(SK / "osa-secrets-hygiene/scripts/scan_secrets.py"), str(sec)])
t("scan_secrets: plik czysty/placeholder → exit 0", rc == 0, out.strip().splitlines()[-1][:70])
fake_aws = "AKIA" + "ABCDEFGHIJKLMNOP"
fake_gh = "ghp_" + "a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8"
(sec / "bad.env").write_text(f"AWS={fake_aws}\nGH={fake_gh}\napi_key = \"Zx9Qw8Er7Ty6Ui5O\"\n")
rc, out = run([PY, str(SK / "osa-secrets-hygiene/scripts/scan_secrets.py"), str(sec)])
t("scan_secrets: 3 trafienia → exit 1", rc == 1 and "trafień: 3" in out, out.strip().splitlines()[-1][:70])
t("scan_secrets: wyniki zamaskowane (brak pełnego klucza w wyjściu)", fake_aws not in out and fake_gh not in out)

# smoke: lokalny serwer
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/ok": body, code = b"status: ok", 200
        elif self.path == "/bad": body, code = b"boom", 500
        else: body, code = b"nf", 404
        self.send_response(code); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *a): pass
srv = http.server.HTTPServer(("127.0.0.1", 0), H); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
S = str(SK / "osa-deploy-validation/scripts/smoke.py")
b = f"http://127.0.0.1:{port}"
rc, out = run([PY, S, "--url", b + "/ok", "--contains", "ok", "--retries", "1"])
t("smoke: /ok 200 + treść → exit 0", rc == 0)
rc, out = run([PY, S, "--url", b + "/bad", "--retries", "1"])
t("smoke: /bad 500 → exit 1", rc == 1, out.strip().splitlines()[0][:60])
rc, out = run([PY, S, "--url", b + "/ok", "--contains", "NIE-MA", "--retries", "1"])
t("smoke: brak wymaganego tekstu → exit 1", rc == 1)
rc, out = run([PY, S, "--url", b + "/ok", "--url", b + "/bad", "--retries", "1"])
t("smoke: dwa URL, jeden zły → exit 1 i '1/2'", rc == 1 and "1/2" in out)
rc, out = run([PY, S, "--url", "http://127.0.0.1:1/x", "--retries", "1", "--timeout", "2"])
t("smoke: martwy port → exit 1", rc == 1)
srv.shutdown()

W = str(SK / "osa-session-handoff/scripts/write_session_file.py")
rc, out = run([PY, W, "--name", "Test Sesji", "--repo", str(repo), "--ustalone", "a;b", "--next", "c"])
sess = list((repo / "sessions").glob("*-test-sesji.md"))
txt = sess[0].read_text(encoding="utf-8") if sess else ""
t("write_session_file: tworzy plik z SHA i sekcjami", rc == 0 and sess and "SHA: " in txt and "- a" in txt and "NASTĘPNY KROK" in txt)
rc, out = run([PY, W, "--name", "Test Sesji", "--repo", str(repo)])
t("write_session_file: istniejący plik → exit 1 (bez nadpisania)", rc == 1)
rc, out = run([PY, W, "--name", "sekret", "--repo", str(repo), "--ustalone", fake_gh])
t("write_session_file: wartość-sekret odrzucona → exit 2", rc == 2)

# ---------- rozszerzalność ----------
pk = tmp / "pack"; shutil.copytree(SK, pk)
nd = pk / "osa-nowy-test"; nd.mkdir()
(nd / "SKILL.md").write_text('---\nname: "osa-nowy-test"\ndescription: "Skill testowy dodany bez limitu. Triggers: test."\n---\n# t\n', encoding="utf-8")
rc, out = run([PY, str(pk / "osa-skill-authoring/scripts/build_index.py"), str(pk)])
idx = (pk / "osa-orchestrator/SKILL.md").read_text(encoding="utf-8")
t("dodanie skilla: build_index wpisuje go do 'Inne (niezarejestrowane)'", rc == 0 and "`osa-nowy-test`" in idx and "Inne (niezarejestrowane)" in idx)
rc, out = run([PY, str(pk / "osa-skill-authoring/scripts/validate_skills.py"), str(pk)])
t("walidator zgłasza skill spoza registry (exit 1)", rc == 1 and "osa-nowy-test" in out)
reg = json.loads((pk / "registry.json").read_text()); reg["groups"][-1]["skills"].append("osa-nowy-test")
(pk / "registry.json").write_text(json.dumps(reg, ensure_ascii=False))
run([PY, str(pk / "osa-skill-authoring/scripts/build_index.py"), str(pk)])
rc, out = run([PY, str(pk / "osa-skill-authoring/scripts/validate_skills.py"), str(pk)])
t("po wpisie do registry: walidator exit 0", rc == 0, out.strip()[:40])
(nd / "SKILL.md").write_text('---\nname: "zla nazwa"\ndescription: "bad <tag>"\n---\n', encoding="utf-8")
rc, out = run([PY, str(pk / "osa-skill-authoring/scripts/validate_skills.py"), str(pk)])
t("walidator łapie złą nazwę i nawiasy kątowe", rc == 1 and "niedozwolona nazwa" in out and "nawiasy" in out)

fails = [r for r in results if not r[1]]
md = ["# Wyniki testów paczki", "", f"Uruchomienie: `python3 tests/run_tests.py` · Python {sys.version.split()[0]}", "", f"**{len(results) - len(fails)}/{len(results)} przeszło**", "", "| # | Test | Wynik | Szczegół |", "|---|---|---|---|"]
for i, (n, ok, d) in enumerate(results, 1):
    md.append(f"| {i} | {n} | {'PASS' if ok else 'FAIL'} | {d.replace('|', '/')} |")
md += ["", "Uwaga: to testy struktury i skryptów. Nie mierzą jakości routingu ani skuteczności skilli u agenta (patrz README)."]
(ROOT / "tests" / "RESULTS.md").write_text("\n".join(md), encoding="utf-8")
shutil.rmtree(tmp, ignore_errors=True)
print(f"\n{len(results) - len(fails)}/{len(results)} przeszło")
sys.exit(1 if fails else 0)
