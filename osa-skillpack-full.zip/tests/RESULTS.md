# Wyniki testów paczki

Uruchomienie: `python3 tests/run_tests.py` · Python 3.11.15

**34/34 przeszło**

| # | Test | Wynik | Szczegół |
|---|---|---|---|
| 1 | 215 kart w paczce | PASS | 215 |
| 2 | każda karta dokładnie w jednym pliku | PASS |  |
| 3 | każda z 215 kart ma pole Ekspert wie | PASS | brak: [] |
| 4 | źródło miało Ekspert wie tylko w 65 kartach (O–Z) | PASS | 65 |
| 5 | kontrakt §0 dosłownie w honesty-contract (bez Granicy zakresu) | PASS | brak 0: [] |
| 6 | Granica zakresu §0 dosłownie w scope-guard | PASS |  |
| 7 | osa-build-gate: blok źródłowy dosłownie | PASS | brak 0: [] |
| 8 | osa-definition-of-done: blok źródłowy dosłownie | PASS | brak 0: [] |
| 9 | osa-evals: blok źródłowy dosłownie | PASS | brak 0: [] |
| 10 | repo_state: repo git → exit 0 i SHA | PASS |  |
| 11 | repo_state: nie-repo → exit 2 | PASS | To nie jest repo git (albo brak git): fatal: not a git repos |
| 12 | scope_check: zmiana w zakresie → exit 0 | PASS | WYNIK: zakres zgodny |
| 13 | scope_check: b.py i new.txt spoza listy → exit 1 | PASS | WYNIK: NARUSZENIE ZAKRESU |
| 14 | scope_check: brak pliku deklaracji → exit 2 | PASS |  |
| 15 | verify: komenda exit 0 → MECHANICALLY_VERIFIED | PASS |  |
| 16 | verify: exit 3 propagowany, poziom FAILED | PASS |  |
| 17 | verify: timeout → exit 124 | PASS |  |
| 18 | verify: brak komendy → exit 127 | PASS |  |
| 19 | verify: 4 rekordy w evidence.jsonl | PASS | [0, 3, 124, 127] |
| 20 | scan_secrets: plik czysty/placeholder → exit 0 | PASS | WYNIK: przeskanowano 1 plików, trafień: 0 (heurystyka; brak trafień ni |
| 21 | scan_secrets: 3 trafienia → exit 1 | PASS | WYNIK: przeskanowano 2 plików, trafień: 3 |
| 22 | scan_secrets: wyniki zamaskowane (brak pełnego klucza w wyjściu) | PASS |  |
| 23 | smoke: /ok 200 + treść → exit 0 | PASS |  |
| 24 | smoke: /bad 500 → exit 1 | PASS | FAIL http://127.0.0.1:36155/bad — próba 1: status 500 != 200 |
| 25 | smoke: brak wymaganego tekstu → exit 1 | PASS |  |
| 26 | smoke: dwa URL, jeden zły → exit 1 i '1/2' | PASS |  |
| 27 | smoke: martwy port → exit 1 | PASS |  |
| 28 | write_session_file: tworzy plik z SHA i sekcjami | PASS |  |
| 29 | write_session_file: istniejący plik → exit 1 (bez nadpisania) | PASS |  |
| 30 | write_session_file: wartość-sekret odrzucona → exit 2 | PASS |  |
| 31 | dodanie skilla: build_index wpisuje go do 'Inne (niezarejestrowane)' | PASS |  |
| 32 | walidator zgłasza skill spoza registry (exit 1) | PASS |  |
| 33 | po wpisie do registry: walidator exit 0 | PASS | OK: 52 skilli |
| 34 | walidator łapie złą nazwę i nawiasy kątowe | PASS |  |

Uwaga: to testy struktury i skryptów. Nie mierzą jakości routingu ani skuteczności skilli u agenta (patrz README).