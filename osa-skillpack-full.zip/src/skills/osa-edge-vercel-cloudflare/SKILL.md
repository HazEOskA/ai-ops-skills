---
name: "osa-edge-vercel-cloudflare"
description: "Wdrożenia frontendu i edge: Vercel, Cloudflare Workers, Pages, D1, R2, KV, cache CDN, DNS, zmienne środowiskowe, limity funkcji. Użyj przy hostingu aplikacji webowych i funkcji na krawędzi. Triggers: Vercel, Cloudflare, Workers, edge, CDN, DNS, serverless, Pages, D1, R2, hosting."
---

# Vercel i Cloudflare (edge)

## Procedura

1. **Sprawdź konektory w sesji**: narzędzia Vercel i Cloudflare mogą być dostępne. Użyj ich do odczytu stanu (projekty, wdrożenia, logi) zanim cokolwiek zmienisz. Konektor jest dowodem stanu, zgadywanie nie.
2. **Dopasuj do rdzenia** (`osa-build-gate`): funkcje na krawędzi mają limity czasu, pamięci i dostępnych API; długie zadania, ciężkie biblioteki natywne i trwałe połączenia bywają problemem. Zweryfikuj limity w aktualnej dokumentacji platformy (`unknown`, jeśli nie sprawdzone).
3. **Zmienne i sekrety**: ustawiane w panelu/CLI platformy, osobno dla podglądu i produkcji. Nazwy w kodzie, wartości nigdzie w repo (`osa-secrets-hygiene`).
4. **Cache**: jawne nagłówki `Cache-Control`, rozróżnij zasoby statyczne (długi TTL, hash w nazwie) od dynamicznych. Unieważnianie planuj z góry.
5. **DNS i domeny**: zmiana DNS to akcja z listy zgód (`osa-god-layer-approvals`). Zanotuj poprzednie rekordy przed zmianą (rollback).
6. **Podgląd przed produkcją**: deployment podglądowy, smoke test (`osa-deploy-validation`), dopiero promocja. Rollback: poprzednie wdrożenie.
7. **Dane na Cloudflare**: D1 (SQL), KV (klucz-wartość, ostateczna spójność), R2 (obiekty). Dobierz do wzorca dostępu, pamiętając o modelu spójności (`osa-distributed-systems`).

## Nie

- Deployu na produkcję bez zgody.
- Zakładania, że kod działający w Node działa w runtime edge: sprawdź.
- Przechowywania sekretów w zmiennych publicznych (prefiksy typu `NEXT_PUBLIC_` trafiają do przeglądarki).

{{CARDS_TOC}}
