---
name: "osa-god-layer-approvals"
description: "Warstwa zatwierdzeń (AI proponuje, Osa zatwierdza): push, deploy, migracje, koszty, sekrety, force, usuwanie i zmiana zakresu wymagają jawnej zgody. Użyj przed każdą akcją nieodwracalną lub kosztową. Triggers: approve, push, deploy, delete, force, migrate, production, zgoda, zatwierdź."
---

# Warstwa zatwierdzeń (God Layer)

Zasada: **AI proponuje, Osa zatwierdza.** Akcje z listy niżej nie wykonują się bez jawnej zgody w tej rozmowie. Zgoda z poprzedniej sesji nie liczy się.

## Wymagają zgody

- `git push`, `--force`, przepisanie historii, merge do głównej gałęzi, tag/release
- deploy (produkcja i staging), zmiana DNS, zmiana konfiguracji chmury
- migracje danych i schematu, `DROP`, `DELETE` bez `WHERE` ograniczonego do testu
- cokolwiek, co kosztuje pieniądze (płatne API, zasoby chmurowe, zakup domeny)
- dotknięcie sekretów, kluczy, tokenów (`osa-secrets-hygiene`)
- rozszerzenie zakresu poza zadeklarowaną listę plików (`osa-scope-guard`)
- wysłanie czegokolwiek na zewnątrz (e-mail, wiadomość, post). Domyślnie tylko szkic (`osa-gmail-draft-log`)

## Format prośby (krótko)

```
ZGODA?  <akcja jednym zdaniem>
Skutek: <co się zmieni> | Odwracalne: TAK (jak) / NIE
Koszt:  <pieniądze/czas albo brak>
Dowód gotowości: <komenda + wynik z osa-verify-run>
Rollback: <komenda>
```

Czekaj na odpowiedź. Cisza to nie zgoda. Nie proś o zgodę na rzeczy spoza listy: to hałas.

## Zabezpieczenia

- Zgoda dotyczy dokładnie opisanej akcji. Inna gałąź, inne środowisko albo dodatkowy plik to nowa prośba.
- Proponuj w wersji „dry-run” najpierw (`--dry-run`, `plan`, podgląd diffa), jeśli narzędzie ma taki tryb.
- Gdy Osa jest nieobecny (sesja bez nadzoru): przygotuj wszystko, zatrzymaj się przed akcją i opisz, co czeka na zatwierdzenie.

{{CARDS_TOC}}
