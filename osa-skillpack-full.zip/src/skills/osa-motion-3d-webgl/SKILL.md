---
name: "osa-motion-3d-webgl"
description: "Animacje, 3D i grafika w przeglądarce: Three.js, WebGL i WebGPU, shadery, wydajność klatek, GSAP, scroll-driven, potok renderingu i kolor. Użyj przy efektach premium, scenach 3D, shaderach, animacjach. Triggers: WebGL, Three.js, shader, GLSL, animation, GSAP, 3D, WebGPU, canvas, motion, animacje."
---

# Ruch, 3D, WebGL

## Procedura

1. **Budżet klatki**: 60 fps to ok. 16 ms na klatkę; ustal budżet na CPU i GPU i **mierz** (narzędzia deweloperskie przeglądarki, licznik klatek). Testuj na słabszym urządzeniu, nie tylko na własnej maszynie.
2. **Najpierw prostota**: CSS/transform i opacity (kompozytor) przed JS; canvas/WebGL, gdy efekt tego wymaga. Animuj właściwości tanie (`transform`, `opacity`), nie układ.
3. **Three.js/WebGL**: ogranicz liczbę wywołań rysowania (instancjonowanie, łączenie geometrii), zwalniaj zasoby (`dispose`), kompresja tekstur i modeli, `requestAnimationFrame` z wstrzymaniem w ukrytej karcie.
4. **Shadery**: zacznij od działającego minimum, dodawaj efekt po efekcie; uważaj na precyzję i gałęzie na GPU. Kolor: rozróżnij przestrzeń liniową i sRGB (karty T).
5. **Ruch z szacunkiem dla użytkownika**: respektuj `prefers-reduced-motion`; animacja pełni funkcję (kierunek uwagi, sprzężenie zwrotne), nie ozdabia bez końca (`osa-premium-ui-style`).
6. **Zgodność**: wykrywanie możliwości (WebGL2/WebGPU), wersja zastępcza statyczna.
7. **Dowód**: uruchom w przeglądarce i obejrzyj (zrzut ekranu/nagranie), zmierz fps (`osa-verify-run`). Kod, który się kompiluje, nie dowodzi, że efekt wygląda dobrze.

## Nie

- Animowania układu (width/top/left) w pętli.
- Nieskończonych pętli bez wstrzymania poza widokiem.
- Ciężkich zasobów bez kompresji i ładowania leniwego.

{{CARDS_TOC}}
