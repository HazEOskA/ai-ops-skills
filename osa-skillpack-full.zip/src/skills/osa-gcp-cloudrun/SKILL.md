---
name: "osa-gcp-cloudrun"
description: "Google Cloud i Cloud Run: serwisy kontenerowe, IAM, sekrety w Secret Manager, konfiguracja skalowania, Cloud Build, logi i wdrożenie z rollbackiem. Użyj przy pracy na GCP, Cloud Run, Artifact Registry, Cloud SQL. Triggers: GCP, Cloud Run, gcloud, Cloud Build, IAM, Secret Manager, Google Cloud, Artifact Registry."
---

# GCP i Cloud Run

## Procedura

1. **Kontekst**: projekt, region, konto, aktywna konfiguracja (`gcloud config list`, `gcloud projects list`). Nie zgaduj identyfikatora projektu: sprawdź lub zapytaj. Nie masz `gcloud`? Powiedz to i przygotuj komendy do uruchomienia przez Osę, oznaczone jako nieuruchomione.
2. **Kontener**: mały obraz, proces jako PID 1 z obsługą sygnałów, nasłuch na porcie z zmiennej `PORT`, bezstanowy (`osa-containers-docker`).
3. **Tożsamość**: dedykowane konto usługi z minimalnymi rolami. Nie używaj domyślnego konta z szerokimi uprawnieniami.
4. **Sekrety**: Secret Manager, podpięte jako zmienne lub wolumen. Nigdy w obrazie ani w zmiennych w kodzie (`osa-secrets-hygiene`).
5. **Skalowanie i koszt**: ustaw maksymalną liczbę instancji (ochrona rachunku), współbieżność dopasowaną do aplikacji, min-instances tylko gdy zimny start szkodzi (kosztuje). Wartości dobieraj pomiarem, nie zgadywaniem.
6. **Wdrożenie**: zgoda Osy (`osa-god-layer-approvals`), rewizje zachowują poprzednią wersję, więc rollback = przekierowanie ruchu na poprzednią rewizję. Sprawdź smoke testem (`osa-deploy-validation`).
7. **Logi i błędy**: Cloud Logging, alerty na 5xx i opóźnienia (`osa-observability-slo`).
8. **Baza**: Cloud SQL przez konektor/Unix socket, pula połączeń dopasowana do liczby instancji (`osa-postgres-data`).

## Nie

- Publicznego dostępu (allow-unauthenticated) bez decyzji, że usługa ma być publiczna.
- Kluczy JSON kont usługi w repo.
- Komend `gcloud` bez sprawdzonego projektu i regionu.

{{CARDS_TOC}}
