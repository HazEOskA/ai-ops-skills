---
name: "osa-evals"
description: "Ewaluacja systemów AI i skilli: zestaw przypadków, kryteria, baseline, uruchomienie z i bez, niezależna ocena, próg zaliczenia. Użyj przy ocenie modelu, promptu, agenta lub skilla oraz przy sondach kontraktu. Triggers: eval, benchmark, A/B, grader, baseline, ewaluacja, test skilla, metryki."
---

# Ewaluacje

Nie ufaj systemowi AI (ani skillowi) bez pomiaru. Twierdzenie „jest lepszy” wymaga baseline i liczby.

## Procedura

1. **Zestaw przypadków** z realnych zadań, także trudnych i brzegowych. Zapisz oczekiwane zachowanie *przed* uruchomieniem.
2. **Baseline**: to samo bez badanej zmiany (bez skilla, poprzedni prompt, inny model).
3. **Uruchom oba warianty** w identycznych warunkach. Zapisz surowe wyjścia.
4. **Ocena niezależna od autora**: osobny grader (człowiek lub osobny agent bez wglądu w tok pracy) z kryteriami zapisanymi z góry. Autor nie ocenia własnej pracy.
5. **Próg** ustalony z góry (np. 10/12). Wynik: liczba zaliczonych w każdym wariancie, lista niezaliczonych z powodem.
6. **Wiarygodność**: powtórzenia dla niedeterminizmu (min. kilka przebiegów), przedziały niepewności zamiast jednej liczby, jeśli próbka jest mała. Mała próbka nie dowodzi niczego ogólnego: napisz to.
7. **Zapis wyniku** w repo (data, wersje, wejścia, wyjścia, ocena). Bez zapisu wynik nie istnieje.
8. Po wyniku: popraw kontrakt lub instrukcję, nie dopisuj wiedzy „na siłę”. Powtórz.

## Nie

- Strojenia pod zestaw testowy (przeuczenie): trzymaj część przypadków w ukryciu.
- Ogłaszania poprawy bez baseline.
- Miary, którą model potrafi „wygrać” bez wykonania zadania.

## Sondy kontraktu OSA (gotowa bateria)

{{INCLUDE:S2}}

{{CARDS_TOC}}
