---
name: "osa-test-strategy"
description: "Strategia testów: co testować, na jakim poziomie, testy własności i fuzzing, kryteria, że test w ogóle coś dowodzi. Użyj przy pisaniu testów, projektowaniu pokrycia, niestabilnych testach. Triggers: tests, test plan, coverage, flaky, property-based, fuzzing, testy, pokrycie."
---

# Strategia testów

Test ma wartość, gdy potrafi zawieść. Sprawdź to zawsze.

## Procedura

1. Zacznij od ryzyka: co kosztuje najwięcej, jeśli się zepsuje. Tam testy najgłębsze.
2. Poziomy: jednostkowe dla logiki, integracyjne dla granic (baza, kolejka, HTTP), kilka end-to-end dla ścieżek krytycznych. Nie odwracaj piramidy bez powodu.
3. **Test musi padać bez zmiany, którą chroni** (`osa-verify-run`: uruchom przed i po). Test, który nigdy nie padł, jest niezweryfikowany.
4. Dane realne, nie idealne: puste, ogromne, unicode, granice, duplikaty, kolejność zdarzeń.
5. Niestabilne testy (flaky): to defekt, nie „pech”. Znajdź źródło (czas, kolejność, współdzielony stan, sieć), nie dokładaj retry.
6. Ścieżki krytyczne i algorytmy: testy własności i fuzzing (karty W).
7. Pokrycie to wskaźnik, nie cel. 100% linii z pustymi asercjami dowodzi zera.

## Nie

- Mockowania tego, co testujesz.
- Testów zależnych od kolejności lub zegara systemowego.
- Zielonego wyniku przy 0 uruchomionych testach.

{{CARDS_TOC}}
