---
name: "osa-web-perf-a11y-seo"
description: "Wydajność stron, dostępność i SEO: Core Web Vitals, obrazy i czcionki, semantyka HTML, klawiatura i czytniki ekranu, metadane i indeksowanie. Użyj przy optymalizacji strony, audycie a11y, poprawie SEO. Triggers: performance, Lighthouse, Core Web Vitals, LCP, CLS, accessibility, a11y, SEO, WCAG, wydajność strony."
---

# Wydajność, dostępność, SEO

## Procedura

1. **Zmierz najpierw**: Lighthouse/PageSpeed lub pomiary z prawdziwych użytkowników; zapisz wyniki przed zmianą. Nie masz narzędzia w sesji: `unknown` i przygotuj komendę dla Osy.
2. **Wydajność**: największy element widoczny (LCP) szybko (obrazy w nowoczesnych formatach, właściwe rozmiary, priorytet dla hero), stabilny układ (CLS: rezerwuj miejsce), reaktywność (INP: mniej JS na głównym wątku). Dzielenie kodu, leniwe ładowanie, czcionki z `font-display`.
3. **Dostępność**: semantyczny HTML zanim ARIA; pełna obsługa klawiaturą z widocznym fokusem; kontrast; alternatywy tekstowe; etykiety formularzy; szanuj `prefers-reduced-motion`. Test: przejdź stronę samą klawiaturą.
4. **SEO techniczne**: unikalny `title` i `description`, kanoniczne adresy, `sitemap.xml`, `robots.txt`, dane strukturalne tam, gdzie pasują, renderowanie treści po stronie serwera dla stron, które mają być indeksowane.
5. **Po zmianie zmierz ponownie** i porównaj (`osa-verify-run`). Poprawa bez liczby to opinia.
6. **Treść i ruch (SEO produktowe)**: intencja wyszukiwania i realne strony, nie sztuczki; decyzje zakresu w `osa-mvp-solo-builder`.

## Nie

- Optymalizacji „na oko”.
- ARIA jako łatki na niesemantyczny HTML.
- Wyłączania animacji tylko w CSS bez respektowania preferencji użytkownika w ruchu (`osa-motion-3d-webgl`).

{{CARDS_TOC}}
