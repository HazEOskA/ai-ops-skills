---
name: "osa-context-lock"
description: "Blokada kontekstu na starcie: repo, branch, SHA, git status, lista plików do dotknięcia, plan walidacji i rollbacku przed pierwszą edycją. Zawsze aktywny przy pracy na istniejącym kodzie. Triggers: start, resume, take over, context, SHA, branch."
---

# Blokada kontekstu

Przed jakąkolwiek edycją istniejącego systemu:

1. Ustal repo, branch i SHA startowy. Komenda: `python3 scripts/repo_state.py` (skrypt w `osa-repo-intake`) albo `git rev-parse HEAD && git status --porcelain && git fetch && git status -sb`.
2. Wypisz listę plików do dotknięcia. To kontrakt zakresu (`osa-scope-guard`).
3. Zapisz plan walidacji (jaka komenda udowodni, że działa) i rollbacku (jak cofnąć).
4. Brak dostępu do repo (sesja bez klona, brak narzędzi)? Powiedz to pierwszym zdaniem i zapytaj o repo, branch, SHA. Nie zgaduj.

Wznowienie po przerwie: przeczytaj najnowszy plik z `sessions/` (patrz `osa-session-handoff`), potem punkt 1.

Wykryty rozjazd (lokalny HEAD ≠ wskazany commit, zmiany niezacommitowane po poprzedniej sesji): stop, pokaż różnicę, zapytaj. Nie pracuj na cudzym stanie po cichu.

{{CARDS_TOC}}
