---
name: "osa-secrets-hygiene"
description: "Higiena sekretów: nigdy w czacie, kodzie ani historii git; skan repo, rotacja po wycieku, zmienne środowiskowe i menedżery sekretów. Użyj przy kluczach API, tokenach, .env, konfiguracji, podejrzeniu wycieku. Triggers: secrets, API key, token, .env, leak, credentials, rotate, sekrety, klucz."
---

# Higiena sekretów

## Reguły

1. **Sekretów nie wklejamy w czacie, raporcie, szkicu maila ani logu.** Prosząc o konfigurację, proś o *nazwy* zmiennych, nie wartości.
2. Sekrety w zmiennych środowiskowych lub menedżerze sekretów platformy. Nigdy w repo. `.env` w `.gitignore`, w repo tylko `.env.example` z pustymi wartościami.
3. Nie czytaj plików z sekretami bez potrzeby. Musisz sprawdzić, że zmienna istnieje: sprawdź obecność, nie wypisuj wartości (długość albo pierwsze 2 znaki maksymalnie).
4. Skan przed commitem i przed publikacją: `python3 scripts/scan_secrets.py <ścieżka>`. Exit 1 = znaleziono kandydatów (wyniki zamaskowane). Fałszywe alarmy zdarzają się; brak alarmu nie dowodzi braku sekretu.
5. **Wyciek**: uznaj klucz za spalony. Kolejność: rotacja/unieważnienie u dostawcy → sprawdzenie logów użycia → dopiero czyszczenie historii git. Usunięcie pliku z repo nie unieważnia klucza.
6. Sekret podany przez Osę w czacie: nie powtarzaj go, nie zapisuj do plików, przypomnij o rotacji, jeśli trafił w miejsce publiczne.

## Zakres skryptu (uczciwie)

Wzorce: klucze AWS, prywatne klucze PEM, tokeny GitHub, Slack, Google API, Stripe, klucze w stylu `sk-`, przypisania `password/secret/api_key = "..."`. Pomija katalogi `.git`, `node_modules`, pliki binarne. To heurystyka, nie audyt.

{{CARDS_TOC}}
