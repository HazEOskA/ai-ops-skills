---
name: "osa-premium-ui-style"
description: "Styl interfejsu premium: system projektowy, typografia, rytm i odstępy, kolor, hierarchia, mikrointerakcje, spójność. Użyj przy projektowaniu wyglądu aplikacji, landing page, dashboardu, poprawie estetyki. Triggers: UI design, design system, typography, layout, premium, landing page, styling, wygląd, estetyka."
---

# Styl UI premium

„Premium” to dyscyplina, nie efekty. Wynika ze spójnego systemu, nie z liczby animacji.

## Procedura

1. **Zacznij od systemu**: tokeny (kolory, odstępy, promienie, cienie, typografia) zdefiniowane raz i użyte wszędzie. Jeśli Osa ma już system projektowy lub styl (repo, Figma, artefakt Design System), **użyj go**, nie wymyślaj nowego.
2. **Typografia**: dwie rodziny maksymalnie, skala rozmiarów o stałym stosunku, komfortowa długość linii, kontrast tekstu (dostępność, `osa-web-perf-a11y-seo`).
3. **Rytm**: siatka odstępów (np. wielokrotności 4 lub 8 px), konsekwentne marginesy; powietrze zamiast ozdób.
4. **Hierarchia**: jedna główna akcja na ekran, wyraźna różnica między pierwszo- i drugorzędnym. Kolor akcentu oszczędnie.
5. **Stany**: hover, fokus, aktywny, nieaktywny, ładowanie, błąd, pusty, wszystkie zaprojektowane.
6. **Tryb ciemny i responsywność** od początku: tokeny kolorów z wariantami, układ sprawdzony na telefonie.
7. **Ruch**: subtelny, funkcjonalny (`osa-motion-3d-webgl`).
8. **Dowód**: obejrzyj w przeglądarce na trzech szerokościach i w obu motywach (zrzuty). „Wygląda dobrze w kodzie” to nie dowód.

## Nie

- Kopiowania cudzego znaku, logotypu ani układu 1:1.
- Dziesięciu kolorów akcentu, wielu krojów pisma.
- Ozdób bez funkcji.

{{CARDS_TOC}}
