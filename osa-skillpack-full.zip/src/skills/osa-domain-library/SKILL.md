---
name: "osa-domain-library"
description: "Biblioteka 13 domen specjalistycznych: mobile, web3, algorytmy, OS, kompilatory, sieci, media, data science, HPC i GPU, metody formalne, ERP, prawo. Użyj do wąskiego pytania z tych domen. Triggers: iOS, Android, Solidity, CUDA, kompilator, BGP, DSP, ERP, EU AI Act, algorytm, kernel, GPU."
---

# Biblioteka domen specjalistycznych

Rzadziej używane domeny, każda w osobnym pliku. **Wczytaj tylko plik pasujący do pytania**, potem grep po ID karty.

## Mapa

{{LIBRARY_TOC}}

## Procedura

1. Dobierz plik z tabeli po nazwie domeny. Pytanie dotyczy dwóch domen: wczytaj oba pliki, nie inne.
2. W pliku `grep -n "^### <ID>" references/<plik>` → zakres linii → czytaj kartę.
3. Karta mówi, co ekspert sprawdza w pierwszej kolejności (Gdy / Twarde / Ekspert wie / Sprawdź / Nie). Nie zastępuje myślenia ani aktualnej dokumentacji.
4. Zadanie budowy? Najpierw `osa-build-gate`. Karty domenowe wspierają decyzje, nie omijają bramki.

## Uwaga o statusie

Karty O–Z (algorytmy, sieci, HPC, prawo itd.) pochodzą z osa-godmode v2 z polem „Ekspert wie”. Karty E, L, N, Q, R, S, T, U (G13) i W (W01, W04) miały to pole dopisane 2026-09-29 i **nie zostały zweryfikowane wykonaniem**. Prawo (Y) to orientacja, nie porada prawna. Wersje bibliotek, limity i ceny sprawdzaj w źródle.

## Nie

- Odpowiedzi z karty bez sprawdzenia wersji i dokumentacji, gdy zależy od nich wynik.
- Ładowania wszystkich 13 plików naraz.
