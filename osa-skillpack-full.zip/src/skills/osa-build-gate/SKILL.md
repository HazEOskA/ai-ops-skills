---
name: "osa-build-gate"
description: "Bramka budowy przed pierwszym plikiem: czasowniki rdzenia, inwentarz narzędzi, istniejący projekt, mapa i werdykt BUDUJĘ albo STOP. Użyj przy każdym zamówieniu na działającą rzecz. Triggers: build, create, deploy, implement, zbuduj, zrób aplikację, dashboard, pipeline."
---

# Bramka budowy

{{INCLUDE:SB}}

{{CARDS_TOC}}
