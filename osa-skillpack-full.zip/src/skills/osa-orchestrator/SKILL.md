---
name: "osa-orchestrator"
description: "Spis treści i router skilli OsaTechGPT: wybiera, które skille wczytać do zadania, zamiast czytać wszystkie. Użyj jako PIERWSZY na każdym zadaniu technicznym. Triggers: route, which skill, orchestrate, start task, zadanie, zbuduj, napraw, wdróż, zaplanuj."
---

# OSA Orchestrator (spis treści skilli)

Wersja paczki i status: patrz `registry.json` (status TARGET/UNPROVEN: routing nie był mierzony).

## Protokół (5 kroków, w tej kolejności)

1. **Zawsze aktywne:** `osa-honesty-contract` i `osa-context-lock` (krótkie; wczytaj je, jeśli jeszcze nie są w kontekście).
2. **Sklasyfikuj zadanie** jednym z trzech typów:
   - **BUDOWA / ZMIANA / WDROŻENIE** (wynik to działająca rzecz) → najpierw `osa-build-gate`. Na koniec `osa-verify-run`, `osa-definition-of-done`, `osa-report-format`.
   - **PYTANIE O WIEDZĘ** → bez bramki. Wybierz 1 skill z indeksu po opisie.
   - **AWARIA** → `osa-incident-response` i `osa-debug-bisect`.
3. **Sprawdź trasy** (tabela ROUTES niżej). Trafia typ zadania → wczytaj skille z kolumny w podanej kolejności.
4. **Nie ma trasy → wybierz z INDEX po opisie.** Maksymalnie 3 skille naraz na start. Kolejne dokładaj, gdy zadanie ich dotknie.
5. **Skill z kartami** (`references/cards.md`): nie czytaj całości. `grep -n "^### <ID>" references/cards.md`, potem zakres linii.

Nic nie pasuje: nie naciągaj. Pracuj na `osa-honesty-contract` + `osa-build-gate` i powiedz „brak skilla dla: X”. To sygnał do `osa-skill-authoring`.

## Kolejność ważności (przy konflikcie wygrywa wyższy)

1. Instrukcja Osy w tej rozmowie
2. `osa-god-layer-approvals` (AI proponuje, Osa zatwierdza; push, deploy, koszty, sekrety)
3. `osa-honesty-contract`
4. `osa-build-gate`
5. Skille domenowe

## Trasy (wygenerowane z pakietów osa-godmode v2)

<!-- ROUTES:START -->
<!-- ROUTES:END -->

## Indeks skilli

<!-- INDEX:START -->
<!-- INDEX:END -->

## Rozszerzanie (bez limitu liczby skilli)

Nowy skill = folder `<nazwa>/SKILL.md` z frontmatter (patrz `osa-skill-authoring`), wpis w `registry.json` (grupa), `python3 osa-skill-authoring/scripts/build_index.py <katalog>`, potem `validate_skills.py`. Skill spoza rejestru pojawi się w grupie „Inne”.

## Czego ten skill nie robi

Nie wykonuje pracy, nie zastępuje skilli domenowych, nie gwarantuje, że wybrany skill jest właściwy. Poprawność routingu jest niezmierzona: jeśli trasa poszła obok, popraw wpis w ROUTES (`src/registry.json`, `route_extras`) i zapisz przypadek.
