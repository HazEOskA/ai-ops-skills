---
name: "osa-data-pipelines-quality"
description: "Potoki danych i jakość: ETL/ELT, przetwarzanie wsadowe i strumieniowe, hurtownie, idempotentne ładowanie, testy jakości danych, lineage. Użyj przy budowie potoku, hurtowni, ładowaniu danych, zaufaniu do metryk. Triggers: ETL, pipeline, data warehouse, streaming, batch, dbt, data quality, dane, potok danych."
---

# Potoki danych i jakość

## Procedura

1. **Cel potoku** (jakie pytanie biznesowe, jaka świeżość, jaka poprawność) zapisany przed kodem (`osa-build-gate`).
2. **Idempotentne ładowanie**: ponowne uruchomienie daje ten sam wynik (upsert po kluczu, zapis partycjami z nadpisaniem). Zakładaj, że każdy krok wykona się więcej niż raz.
3. **Ewolucja schematu**: kontrakt źródła, wykrywanie zmian, kompatybilność wsteczna.
4. **Testy jakości danych** jako część potoku: unikalność kluczy, brak nulli tam, gdzie nie wolno, zakresy, świeżość, zgodność liczby wierszy ze źródłem. Padnięty test zatrzymuje publikację.
5. **Zgodność z rzeczywistością**: pobierz próbkę realnych danych i sprawdź wynik potoku na niej, nie tylko na danych syntetycznych (`osa-verify-run`).
6. **Batch vs streaming**: strumień tylko gdy wymagana świeżość tego wymaga; koszt złożoności jest duży. Dla strumieni: semantyka dostarczenia (co najmniej raz + deduplikacja), znaki wodne dla zdarzeń spóźnionych.
7. **Lineage i własność**: skąd pochodzi liczba i kto za nią odpowiada. Metryka bez definicji zapisanej w jednym miejscu rozjedzie się.
8. **Koszt i wydajność**: partycjonowanie, przetwarzanie przyrostowe zamiast pełnego przeliczania.

## Nie

- Potoków, które tylko dopisują, bez możliwości ponowienia.
- Ciche pomijanie błędnych wierszy (kolejka odrzuceń z powodem).
- Raportowania metryki bez definicji i testów.

{{CARDS_TOC}}
