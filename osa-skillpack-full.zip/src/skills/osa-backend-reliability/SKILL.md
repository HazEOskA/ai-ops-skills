---
name: "osa-backend-reliability"
description: "Niezawodność backendu: kolejki i joby, timeouty, retry, backpressure, cache, transakcje, współbieżność, wydajność zapytań i usług. Użyj przy serwisach, workerach, wolnych endpointach, kolejkach. Triggers: backend, queue, job, retry, timeout, cache, concurrency, transaction, performance, wydajność backendu."
---

# Niezawodność backendu

## Procedura

1. **Zmierz, zanim optymalizujesz**: profil i metryki (`osa-observability-slo`). Wąskie gardło zgadnięte to zwykle złe gardło. Wydajność: p95/p99, nie średnia.
2. **Timeouty wszędzie**: każde wywołanie zewnętrzne ma limit czasu krótszy niż limit wywołującego. Retry tylko dla operacji idempotentnych, z backoffem i losowym rozrzutem, z limitem prób.
3. **Backpressure**: ograniczona kolejka i pula; przy przeciążeniu odrzucaj szybko z czytelnym błędem zamiast gromadzić do awarii pamięci.
4. **Joby**: idempotentne, z potwierdzeniem po wykonaniu, kolejką martwych listów, widocznym stanem. Zakładaj, że job wykona się więcej niż raz.
5. **Transakcje i współbieżność**: krótkie transakcje, spójny porządek blokad, poziom izolacji świadomie wybrany (`osa-postgres-data`). Wyścigi testuj celowo, nie licz na szczęście.
6. **Cache**: jawna strategia unieważniania i TTL; cache to optymalizacja, nie źródło prawdy. Zabezpiecz się przed lawiną zapytań po wygaśnięciu (stampede).
7. **Łagodne zamykanie**: obsługa `SIGTERM`, dokończenie bieżących żądań (`osa-containers-docker`).
8. **Dowód**: test obciążenia i test awarii zależności (wyłącz bazę/API, sprawdź zachowanie) (`osa-verify-run`).

## Nie

- Nieograniczonych kolejek, pętli retry bez limitu, globalnych blokad „na wszelki wypadek”.
- Cache bez planu unieważnienia.
- Optymalizacji bez pomiaru przed i po.

{{CARDS_TOC}}
