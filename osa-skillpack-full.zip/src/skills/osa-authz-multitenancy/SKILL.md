---
name: "osa-authz-multitenancy"
description: "Autoryzacja i wielodostępność: uwierzytelnianie vs autoryzacja, sesje, tokeny, role, izolacja tenantów, RLS, testy uprawnień. Użyj przy logowaniu, rolach, SaaS z wieloma klientami, wycieku danych między kontami. Triggers: auth, authorization, RBAC, multi-tenant, session, JWT, OAuth, RLS, tenant, uprawnienia."
---

# Autoryzacja i wielodostępność

## Procedura

1. **Nie pisz własnej kryptografii ani własnego auth**: użyj sprawdzonego dostawcy lub biblioteki frameworka (`osa-security-baseline`).
2. **Rozdziel**: uwierzytelnianie (kim jesteś) i autoryzacja (co wolno). Autoryzacja sprawdzana **po stronie serwera przy każdym dostępie do danych**, nie tylko w interfejsie.
3. **Sesje i tokeny**: krótkie życie tokenów dostępu, rotacja, unieważnianie; przechowywanie odporne na kradzież (ciasteczka `HttpOnly`, `Secure`, `SameSite` dla sesji w przeglądarce). JWT nie zastępuje sesji, gdy potrzebujesz unieważniania.
4. **Model uprawnień**: zacznij od prostych ról; atrybuty/zasady dopiero gdy role nie wystarczają. Zasada najmniejszych uprawnień.
5. **Wielodostępność**: identyfikator tenanta w każdym wierszu i zapytaniu; wymuszenie na poziomie bazy (RLS) lub warstwy dostępu, której nie da się ominąć przypadkiem (`osa-postgres-data`).
6. **Testy negatywne obowiązkowe**: użytkownik A próbuje odczytać/zmienić dane B (IDOR), zwykły użytkownik wywołuje akcję admina, wygasły token, brak tokenu. Uruchom (`osa-verify-run`). Brak testu negatywnego = brak dowodu izolacji.
7. **Audyt**: log operacji uprzywilejowanych bez sekretów.

## Nie

- Sprawdzania uprawnień tylko w frontendzie.
- Zaufania do identyfikatora przysłanego przez klienta bez weryfikacji własności.
- Wspólnych kont administracyjnych.

{{CARDS_TOC}}
