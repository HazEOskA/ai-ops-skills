---
name: "osa-llm-system-design"
description: "Projekt systemu opartego na LLM: dobór modelu, prompty, kontekst, wyjście strukturalne, koszt, opóźnienia, cache, fallbacki. Użyj przy budowie funkcji z LLM, optymalizacji promptów, kosztów tokenów. Triggers: LLM, prompt, context window, structured output, token cost, caching, model selection, inferencja."
---

# System oparty na LLM

## Procedura

1. **Zdefiniuj zadanie i miarę sukcesu** przed promptem (`osa-evals`): co to znaczy poprawnie, na jakich przykładach. Bez tego strojenie promptu to gadanie do ściany.
2. **Najmniejszy model, który przechodzi ewaluację**, koszt i opóźnienie zmierzone, nie zgadywane. Wybór modelu potwierdzaj pomiarem na własnym zestawie.
3. **Kontekst**: umieszczaj to, co potrzebne, w kolejności ważności; dane stałe na początku (korzysta cache promptu), zmienne na końcu. Długi kontekst nie jest darmowy ani równie dobrze wykorzystywany.
4. **Wyjście strukturalne**: schemat + walidacja + jedna próba naprawy, potem jawny błąd. Nie parsuj regexem swobodnego tekstu.
5. **Niezawodność**: timeouty, retry z backoffem, fallback na tańszy/inny model, limit kosztu na żądanie i na użytkownika.
6. **Bezpieczeństwo**: dane użytkownika i treści zewnętrzne to niezaufane wejście (`osa-ai-guardrails-sandbox`).
7. **Koszt**: policz koszt na żądanie z realnych tokenów wejścia i wyjścia i cenników, które sprawdzisz w źródle. Cen nie zgaduj: `unknown`, jeśli nie sprawdzone.
8. **Obserwowalność**: loguj prompt (bez danych wrażliwych), wersję, tokeny, opóźnienie, wynik walidacji (`osa-observability-slo`).

## Nie

- Zmian promptu bez uruchomienia zestawu ewaluacyjnego.
- Twierdzeń o jakości modelu bez pomiaru na własnych danych.
- Zależności od niedeterministycznego wyjścia tam, gdzie potrzebna jest gwarancja: użyj kodu.

{{CARDS_TOC}}
