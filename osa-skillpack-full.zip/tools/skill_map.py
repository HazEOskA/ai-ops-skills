"""Mapa: który skill jest właścicielem której karty z osa-godmode.

Każda z 215 kart ma dokładnie jednego właściciela (sprawdza to build_pack.py).
Skille bez kart są proceduralne (nie mają references/cards.md).
"""


def _r(prefix, a, b):
    return [f"{prefix}{i:02d}" for i in range(a, b + 1)]


SKILL_CARDS = {
    # --- rdzeń pracy ---
    "osa-context-lock": ["A01"],
    "osa-honesty-contract": ["A02"],
    "osa-build-gate": ["A04", "A05"],
    "osa-scope-guard": [],
    "osa-verify-run": [],
    "osa-definition-of-done": [],
    "osa-report-format": ["I09"],
    "osa-god-layer-approvals": ["Y05"],
    "osa-session-handoff": [],
    "osa-gmail-draft-log": [],
    "osa-repo-intake": ["A06", "I10"],
    "osa-architecture-lock": ["A03", "A07", "B18", "B19"],
    "osa-git-discipline": ["I05", "I06"],
    "osa-skill-authoring": [],
    # --- jakość i operacje ---
    "osa-change-review": ["I02"],
    "osa-debug-bisect": ["I11", "Q02", "N04"],
    "osa-refactor-safe": ["I03", "I04"],
    "osa-test-strategy": ["I01", "W02", "W03"],
    "osa-deploy-validation": ["J05", "F16", "B17"],
    "osa-incident-response": ["J01", "J02", "J03", "J04", "H09"],
    "osa-secrets-hygiene": ["F13", "H04"],
    "osa-security-baseline": ["H01", "H02", "H03", "H05", "H06", "H07", "H08", "S04"],
    # --- AI i agenty ---
    "osa-agent-design": ["G06", "R04"],
    "osa-agent-tools-mcp": ["G07", "G08"],
    "osa-llm-system-design": ["G01", "G02", "G10", "G11", "G12"],
    "osa-evals": ["G03", "G14", "G15"],
    "osa-rag": ["G04", "G05", "B15"],
    "osa-ai-guardrails-sandbox": ["G09", "Q05"],
    "osa-proof-governance": [],
    "osa-agent-sim-world": [],
    # --- platforma ---
    "osa-cloud-decision-finops": ["F01", "F03", "F04", "F10", "F15"],
    "osa-gcp-cloudrun": ["F02", "F17"],
    "osa-edge-vercel-cloudflare": ["F05", "F11", "F12"],
    "osa-containers-docker": ["F06", "F07", "Q01", "Q04"],
    "osa-cicd-iac": ["F08", "F09", "I07", "I08"],
    "osa-observability-slo": ["F14", "I12", "J06", "J07"],
    # --- backend i dane ---
    "osa-api-contract": ["B01", "B02", "B03", "B12", "B14", "B20"],
    "osa-backend-reliability": ["B04", "B05", "B06", "B08", "B09", "B10", "B11", "B13", "P07"],
    "osa-postgres-data": ["C01", "C02", "C03", "C04", "C10"],
    "osa-authz-multitenancy": ["B07", "B16", "C09"],
    "osa-data-pipelines-quality": ["C05", "C06", "C07", "C08"],
    "osa-distributed-systems": _r("P", 1, 6),
    # --- frontend, produkt, gry ---
    "osa-frontend-architecture": ["D01", "D02", "D03", "D04", "D05", "D10", "D17", "D18", "D19", "D20"],
    "osa-web-perf-a11y-seo": ["D07", "D08", "D09", "M06"],
    "osa-motion-3d-webgl": _r("D", 11, 16) + ["T01", "T02"],
    "osa-premium-ui-style": ["D06"],
    "osa-mvp-solo-builder": ["M01", "M02", "M03", "M04", "M05", "M07", "M08"],
    "osa-gamedev-core": _r("K", 1, 6),
    # --- specjalistyczne ---
    "osa-industrial-iot": _r("Z", 1, 5) + ["W05"],
    "osa-domain-library": [],  # karty w LIBRARY_FILES
}

LIBRARY_SKILL = "osa-domain-library"

# plik -> (tytuł domeny, [karty])
LIBRARY_FILES = {
    "e-mobile.md": ("E · Mobile (iOS, Android, cross-platform, offline, push, sklep)", _r("E", 1, 7)),
    "l-web3.md": ("L · Web3 (kontrakty, klucze, indeksowanie, integracja)", _r("L", 1, 6)),
    "n-lowlevel.md": ("N · Systemy niskopoziomowe (pamięć, wątki, I/O, embedded, protokoły)", ["N01", "N02", "N03", "N05", "N06"]),
    "o-algorithms.md": ("O · Algorytmy i teoria", _r("O", 1, 6)),
    "q-os.md": ("Q · Systemy operacyjne (pamięć wirtualna, dyski)", ["Q03", "Q06"]),
    "r-languages.md": ("R · Języki, parsery, typy, GC, WebAssembly", ["R01", "R02", "R03", "R05", "R06"]),
    "s-networking.md": ("S · Sieci zaawansowane (LB, HTTP/3, BGP, mesh, IPv6)", ["S01", "S02", "S03", "S05", "S06"]),
    "t-media.md": ("T · Kodeki, audio/DSP, obraz", ["T03", "T04", "T05"]),
    "u-data-science.md": ("U · Data science, statystyka, klasyczne ML", _r("U", 1, 5) + ["G13"]),
    "v-hpc-gpu.md": ("V · HPC i GPU", _r("V", 1, 4)),
    "w-formal.md": ("W · Metody formalne", ["W01", "W04"]),
    "x-enterprise.md": ("X · Integracja korporacyjna (ERP, EDI, gateway, iPaaS)", _r("X", 1, 5)),
    "y-legal.md": ("Y · Prawo, licencje, EU AI Act, NIS2 (orientacja, nie porada prawna)", _r("Y", 1, 4)),
}
