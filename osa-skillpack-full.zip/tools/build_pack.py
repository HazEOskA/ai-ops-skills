#!/usr/bin/env python3
"""Buduje pakiet skilli z src/skills + źródło osa-godmode.

Użycie: python3 tools/build_pack.py [--source /mnt/skills/plugins/osa-godmode/SKILL.md]
Wynik: skills/<nazwa>/ (gotowe foldery), generated/manifest.json.
Asercje: 215 kart, każda ma dokładnie jednego właściciela, EXPERT pokrywa dokładnie A–N.
"""
import argparse, hashlib, json, re, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
from skill_map import SKILL_CARDS, LIBRARY_FILES, LIBRARY_SKILL  # noqa: E402
from expert_knows import EXPERT  # noqa: E402

CARD_RE = re.compile(r"^### ([A-Z]\d\d) · (.+)$")


def die(msg):
    print("BŁĄD:", msg, file=sys.stderr)
    sys.exit(1)


def parse_cards(lines):
    cards, cur = {}, None
    for ln in lines:
        m = CARD_RE.match(ln)
        if m:
            cur = m.group(1)
            cards[cur] = {"title": m.group(2), "lines": [ln]}
            continue
        if ln.startswith("## ") or ln.startswith("### "):
            cur = None
            continue
        if cur:
            cards[cur]["lines"].append(ln)
    for c in cards.values():
        while c["lines"] and c["lines"][-1].strip() in ("", "---"):
            c["lines"].pop()
    return cards


def section(lines, start_pat, end_pats):
    s = next((i for i, l in enumerate(lines) if re.match(start_pat, l)), None)
    if s is None:
        die(f"brak sekcji {start_pat}")
    e = len(lines)
    for i in range(s + 1, len(lines)):
        if any(re.match(p, lines[i]) for p in end_pats):
            e = i
            break
    body = lines[s + 1:e]
    while body and body[-1].strip() in ("", "---"):
        body.pop()
    while body and body[0].strip() == "":
        body.pop(0)
    return body


def demote(block):
    return [("#" + l if l.startswith("###") else l) if False else re.sub(r"^### ", "## ", l) for l in block]


def add_expert(card):
    cid = card["lines"][0][4:7]
    txt = "\n".join(card["lines"])
    if "**Ekspert wie:**" in txt:
        return card["lines"]
    out, done = [], False
    for ln in card["lines"]:
        out.append(ln)
        if ln.startswith("**Twarde:**") and not done:
            out.append(f"**Ekspert wie:** {EXPERT[cid]}")
            done = True
    if not done:
        die(f"karta {cid} bez linii Twarde")
    return out


def gdy(card):
    for l in card["lines"]:
        if l.startswith("**Gdy:**"):
            return l[8:].strip().rstrip(".")
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="/mnt/skills/plugins/osa-godmode/SKILL.md")
    a = ap.parse_args()
    src = Path(a.source)
    raw = src.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    lines = raw.decode("utf-8").split("\n")

    cards = parse_cards(lines)
    if len(cards) != 215:
        die(f"oczekiwano 215 kart, jest {len(cards)}")

    # własność kart
    owner, dup = {}, []
    for sk, ids in SKILL_CARDS.items():
        for i in ids:
            if i in owner:
                dup.append(i)
            owner[i] = sk
    for f, (_, ids) in LIBRARY_FILES.items():
        for i in ids:
            if i in owner:
                dup.append(i)
            owner[i] = LIBRARY_SKILL
    missing = sorted(set(cards) - set(owner))
    extra = sorted(set(owner) - set(cards))
    if dup or missing or extra:
        die(f"własność kart: duplikaty={dup} brak={missing} obce={extra}")

    # ekspert
    need = sorted(i for i in cards if i[0] <= "N" and "**Ekspert wie:**" not in "\n".join(cards[i]["lines"]))
    if sorted(EXPERT) != need:
        die(f"EXPERT != karty A–N bez pola: brak={sorted(set(need)-set(EXPERT))} nadmiar={sorted(set(EXPERT)-set(need))}")
    added = []
    for cid, c in cards.items():
        new = add_expert(c)
        if len(new) != len(c["lines"]):
            added.append(cid)
        c["lines"] = new
    assert len(added) == 150, len(added)

    # bloki kontraktu
    s0 = section(lines, r"^## §0 ", [r"^## ", r"^---$"])
    def sub(name):
        blk, on = [], False
        for l in s0:
            if l.startswith("### "):
                on = l.startswith("### " + name)
            if on:
                blk.append(l)
        while blk and blk[-1].strip() == "":
            blk.pop()
        return demote(blk)
    inc = {
        "S0": demote(s0),
        "S0_REFLEXES": sub("Refleksy"), "S0_SAFETY": sub("Bezpiecznik"), "S0_ANCHOR": sub("Kotwica"),
        "S0_EVIDENCE": sub("Drabina"), "S0_SCOPE": sub("Granica"), "S0_BANS": sub("Zakazy"),
        "SB": section(lines, r"^## §B ", [r"^## "]),
        "SD": section(lines, r"^## §D ", [r"^## ", r"^---$"]),
        "S2": section(lines, r"^## §2 ", [r"^## \S+ · "]),
    }
    for k, v in inc.items():
        if not v:
            die(f"pusty blok {k}")

    # pakiety -> trasy
    reg = json.loads((ROOT / "src" / "registry.json").read_text(encoding="utf-8"))
    extras = reg.get("route_extras", {})
    pk = section(lines, r"^### Pakiety", [r"^---$", r"^## "])
    routes = ["| Typ zadania | Skille (w tej kolejności) | Karty |", "|---|---|---|"]
    for l in pk:
        if l.startswith("|") and not l.startswith("|---") and not l.startswith("| Typ"):
            cells = [c.strip() for c in l.strip("|").split("|")]
            ids = re.findall(r"[A-Z]\d\d", cells[1])
            sks = list(extras.get(cells[0], []))
            for i in ids:
                if owner[i] not in sks:
                    sks.append(owner[i])
            routes.append(f"| {cells[0]} | {' → '.join(sks)} | {' '.join(ids)} |")
    routes_txt = "\n".join(routes)

    out_root = ROOT / "skills"
    if out_root.exists():
        shutil.rmtree(out_root)
    out_root.mkdir()
    names = sorted(p.name for p in (ROOT / "src" / "skills").iterdir() if p.is_dir())

    for name in names:
        srcd = ROOT / "src" / "skills" / name
        dst = out_root / name
        shutil.copytree(srcd, dst, ignore=shutil.ignore_patterns("__pycache__"))
        md = (srcd / "SKILL.md").read_text(encoding="utf-8")

        def rep(m):
            key = m.group(1)
            if key not in inc:
                die(f"{name}: nieznany INCLUDE {key}")
            return "\n".join(inc[key])
        md = re.sub(r"\{\{INCLUDE:([A-Z0-9_]+)\}\}", rep, md)

        ids = SKILL_CARDS.get(name, [])
        if ids:
            ref = dst / "references"
            ref.mkdir(exist_ok=True)
            body = [f"# Karty: {name}", "", "Czytaj selektywnie: `grep -n \"^### <ID>\" references/cards.md`, potem zakres linii. Pole „Ekspert wie” z A–N dopisane 2026-09-29, niezweryfikowane wykonaniem.", ""]
            for i in ids:
                body += cards[i]["lines"] + [""]
            (ref / "cards.md").write_text("\n".join(body), encoding="utf-8")
            toc = ["## Karty (references/cards.md)", ""] + [f"- **{i}** · {cards[i]['title']} — gdy: {gdy(cards[i])}" for i in ids]
            toc += ["", "Wczytaj tylko karty pasujące do zadania (grep po ID)."]
            md = md.replace("{{CARDS_TOC}}", "\n".join(toc))
        if name == LIBRARY_SKILL:
            ref = dst / "references"
            ref.mkdir(exist_ok=True)
            tab = ["| Plik | Domena | Karty |", "|---|---|---|"]
            for f, (title, cids) in LIBRARY_FILES.items():
                body = [f"# {title}", "", "Czytaj selektywnie: grep po `^### <ID>`. Pole „Ekspert wie” w tych kartach pochodzi z osa-godmode v2 (O–Z) lub dopisane 2026-09-29 (E, L, N, Q, R, S, T, U/G13, W — te ostatnie niezweryfikowane wykonaniem).", ""]
                for i in cids:
                    body += cards[i]["lines"] + [""]
                (ref / f).write_text("\n".join(body), encoding="utf-8")
                tab.append(f"| references/{f} | {title} | " + ", ".join(f"{i} {cards[i]['title']}" for i in cids) + " |")
            md = md.replace("{{LIBRARY_TOC}}", "\n".join(tab))
        if name == "osa-orchestrator":
            md = re.sub(r"(<!-- ROUTES:START -->).*?(<!-- ROUTES:END -->)",
                        lambda m: f"{m.group(1)}\n{routes_txt}\n{m.group(2)}", md, flags=re.S)
        if "{{" in md:
            die(f"{name}: nierozwiązany placeholder: {re.findall(r'{{[^}]+}}', md)[:3]}")
        (dst / "SKILL.md").write_text(md, encoding="utf-8")

    (out_root / "registry.json").write_text((ROOT / "src" / "registry.json").read_text(encoding="utf-8"), encoding="utf-8")
    r = subprocess.run([sys.executable, str(out_root / "osa-skill-authoring" / "scripts" / "build_index.py"), str(out_root)], capture_output=True, text=True)
    print(r.stdout.strip())
    if r.returncode:
        die("build_index: " + r.stderr)

    (ROOT / "generated").mkdir(exist_ok=True)
    manifest = {
        "source": str(src), "source_sha256": sha, "cards_total": len(cards),
        "expert_added_ids": sorted(added), "skills": names, "skills_count": len(names),
        "owner": {k: owner[k] for k in sorted(owner)},
    }
    (ROOT / "generated" / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"OK: {len(names)} skilli, {len(cards)} kart, ekspert dopisany do {len(added)}, sha256 źródła {sha[:12]}")


if __name__ == "__main__":
    main()
